def add_portfolio_holding(self, crypto_symbol, crypto_name, quantity, buy_price, portfolio_id=None):
    """
    Add or update a holding in the portfolio
    """
    try:
        if portfolio_id is None:
            portfolio_id = self.get_default_portfolio_id()
        
        if not portfolio_id:
            print("No portfolio found to add holding.")
            return False
        
        quantity = float(quantity)
        buy_price = float(buy_price)
        if quantity <= 0 or buy_price <= 0:
            print("Quantity and buy price must be positive numbers.")
            return False
        
        total_invested = quantity * buy_price
        
        with self.get_db_connection() as conn:
            with conn.cursor() as cur:
                # Check if holding already exists
                cur.execute("""
                    SELECT id, quantity, total_invested 
                    FROM portfolio_holdings 
                    WHERE portfolio_id = %s AND crypto_symbol = %s
                """, (portfolio_id, crypto_symbol))
                
                existing = cur.fetchone()
                
                if existing:
                    # Update existing holding (calculate new average buy price)
                    existing_id = existing[0]
                    current_quantity = float(existing[1])
                    current_invested = float(existing[2])
                    
                    new_quantity = current_quantity + quantity
                    new_total_invested = current_invested + total_invested
                    new_avg_price = new_total_invested / new_quantity
                    
                    cur.execute("""
                        UPDATE portfolio_holdings
                        SET quantity = %s, total_invested = %s, average_buy_price = %s
                        WHERE id = %s
                    """, (new_quantity, new_total_invested, new_avg_price, existing_id))
                    
                else:
                    # Insert new holding
                    cur.execute("""
                        INSERT INTO portfolio_holdings
                        (portfolio_id, crypto_symbol, crypto_name, quantity, total_invested, average_buy_price)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (portfolio_id, crypto_symbol, crypto_name, quantity, total_invested, buy_price))
                
                conn.commit()
                return True
                
    except Exception as e:
        print(f"Error adding/updating portfolio holding: {e}")
        return False