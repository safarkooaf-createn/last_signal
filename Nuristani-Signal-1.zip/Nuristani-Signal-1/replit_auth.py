# -*- coding: utf-8 -*-
"""
Replit Auth Integration for Signal Nooristani Platform
Provides seamless Replit authentication with existing user management
"""

import os
import json
import requests
import streamlit as st
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime, timedelta
from contextlib import contextmanager
from typing import Optional, Dict, Any, Tuple

class ReplitAuth:
    """
    Replit Auth integration for Streamlit applications
    Provides zero-setup authentication with Replit's infrastructure
    """
    
    def __init__(self):
        self.db_url = os.getenv('DATABASE_URL')
        if not self.db_url:
            raise ValueError("DATABASE_URL environment variable not found")
        
        # Replit environment variables
        self.replit_user = os.getenv('REPL_OWNER', None)
        self.replit_domain = os.getenv('REPLIT_DEV_DOMAIN', None)
        self.replit_cluster = os.getenv('REPLIT_CLUSTER', None)
        
        # Initialize session state for Replit Auth
        if 'replit_authenticated' not in st.session_state:
            st.session_state.replit_authenticated = False
        if 'replit_user' not in st.session_state:
            st.session_state.replit_user = None
        if 'replit_user_data' not in st.session_state:
            st.session_state.replit_user_data = {}
        
        # SECURITY FIX: Disable auto-authentication based on REPL_OWNER
        # This was a critical vulnerability - REPL_OWNER identifies the repl owner,
        # not individual visiting users. All visitors would be authenticated as the same account.
        # Until proper signed user identity verification is implemented, disable Replit Auth.
        self.is_replit_env = False  # Disabled for security
        
        # Commented out the auto-authentication that caused the vulnerability
        # if self.is_replit_env:
        #     self._auto_authenticate_replit_user()
    
    @contextmanager
    def get_db_connection(self):
        """Get database connection with proper error handling"""
        conn = None
        try:
            conn = psycopg2.connect(self.db_url)
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                conn.close()
    
    def _auto_authenticate_replit_user(self):
        """Auto-authenticate user when running in Replit environment"""
        try:
            if not self.replit_user:
                return
            
            # Get user info from Replit environment
            user_data = {
                'username': self.replit_user,
                'email': f"{self.replit_user}@replit.com",  # Default email format
                'full_name': self.replit_user.replace('-', ' ').replace('_', ' ').title(),
                'avatar_url': f"https://replit.com/public/images/avatars/{self.replit_user}.png",
                'replit_id': self.replit_user,
                'domain': self.replit_domain,
                'cluster': self.replit_cluster
            }
            
            # Create or update user in database
            user_id = self._create_or_update_replit_user(user_data)
            
            if user_id:
                # Set authentication state
                st.session_state.replit_authenticated = True
                st.session_state.replit_user = user_data
                st.session_state.replit_user_data = user_data
                
                # Also set legacy auth state for compatibility
                st.session_state.authenticated = True
                st.session_state.user_id = user_id
                st.session_state.user_email = user_data['email']
                st.session_state.user_name = user_data['full_name']
        
        except Exception as e:
            print(f"Replit auto-authentication error: {str(e)}")
    
    def _create_or_update_replit_user(self, user_data: Dict[str, Any]) -> Optional[int]:
        """Create or update Replit user in database"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    # Check if user exists by Replit ID or email
                    cur.execute("""
                        SELECT id, email, full_name FROM users 
                        WHERE replit_id = %s OR email = %s
                    """, (user_data['username'], user_data['email']))
                    
                    existing_user = cur.fetchone()
                    
                    if existing_user:
                        # Update existing user
                        cur.execute("""
                            UPDATE users 
                            SET full_name = %s,
                                replit_id = %s,
                                last_login = CURRENT_TIMESTAMP,
                                is_active = true,
                                auth_provider = 'replit',
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = %s
                            RETURNING id
                        """, (
                            user_data['full_name'],
                            user_data['username'],
                            existing_user['id']
                        ))
                        
                        user_id = existing_user['id']
                    else:
                        # Create new user
                        cur.execute("""
                            INSERT INTO users (
                                email, full_name, replit_id, email_verified, 
                                is_active, auth_provider, created_at
                            ) VALUES (%s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                            RETURNING id
                        """, (
                            user_data['email'],
                            user_data['full_name'],
                            user_data['username'],
                            True,  # Replit users are pre-verified
                            True,
                            'replit'
                        ))
                        
                        result = cur.fetchone()
                        user_id = result['id'] if result else None
                        
                        # Create default user preferences
                        if user_id:
                            cur.execute("""
                                INSERT INTO user_preferences (user_id, preferred_language)
                                VALUES (%s, %s)
                                ON CONFLICT (user_id) DO NOTHING
                            """, (user_id, 'en'))
                    
                    conn.commit()
                    return user_id
                    
        except Exception as e:
            print(f"Database error creating/updating Replit user: {str(e)}")
            return None
    
    def is_authenticated(self) -> bool:
        """Check if user is authenticated via Replit Auth"""
        return st.session_state.get('replit_authenticated', False)
    
    def get_current_user(self) -> Optional[Dict[str, Any]]:
        """Get current authenticated user data"""
        if self.is_authenticated():
            return st.session_state.get('replit_user_data', {})
        return None
    
    def get_user_info(self) -> Optional[Dict[str, Any]]:
        """Get detailed user information for compatibility with existing system"""
        if self.is_authenticated():
            user_data = st.session_state.get('replit_user_data', {})
            return {
                'id': st.session_state.get('user_id'),
                'email': user_data.get('email'),
                'name': user_data.get('full_name'),
                'username': user_data.get('username'),
                'avatar_url': user_data.get('avatar_url'),
                'provider': 'replit',
                'replit_id': user_data.get('replit_id')
            }
        return None
    
    def logout(self):
        """Logout user (clear session state)"""
        st.session_state.replit_authenticated = False
        st.session_state.replit_user = None
        st.session_state.replit_user_data = {}
        
        # Clear legacy auth state for compatibility
        st.session_state.authenticated = False
        st.session_state.user_id = None
        st.session_state.user_email = None
        st.session_state.user_name = None
        st.session_state.session_token = None
    
    def require_authentication(self) -> bool:
        """Ensure user is authenticated, redirect to login if needed"""
        if not self.is_authenticated():
            return False
        return True
    
    def render_auth_status(self, current_lang='en'):
        """Render authentication status in UI"""
        user = self.get_user_info()
        
        if user:
            st.success(f"🔐 Authenticated as **{user['name']}** via Replit Auth")
            
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"📧 **Email:** {user['email']}")
                st.write(f"👤 **Username:** @{user['username']}")
                
                if user.get('avatar_url'):
                    st.image(user['avatar_url'], width=50, caption="Profile Picture")
            
            with col2:
                if st.button("🚪 Logout", type="secondary"):
                    self.logout()
                    st.rerun()
        else:
            if self.is_replit_env:
                st.info("🔄 Authenticating with Replit...")
                st.rerun()
            else:
                st.warning("⚠️ Not running in Replit environment. Replit Auth not available.")
    
    def render_auth_sidebar(self, current_lang='en'):
        """Render authentication info in sidebar"""
        user = self.get_user_info()
        
        if user:
            st.sidebar.markdown("---")
            st.sidebar.markdown("### 🔐 Replit Auth")
            st.sidebar.markdown(f"**{user['name']}**")
            st.sidebar.markdown(f"@{user['username']}")
            
            if st.sidebar.button("🚪 Logout"):
                self.logout()
                st.rerun()
        else:
            if self.is_replit_env:
                st.sidebar.markdown("---")
                st.sidebar.markdown("### 🔄 Authenticating...")
            else:
                st.sidebar.markdown("---")
                st.sidebar.markdown("### ⚠️ Replit Auth")
                st.sidebar.info("Not in Replit environment")

class ReplitAuthUI:
    """
    UI components for Replit Auth integration
    """
    
    def __init__(self):
        self.replit_auth = ReplitAuth()
    
    def render_auth_page(self, current_lang='en'):
        """Render authentication page with Replit Auth"""
        st.title("🔐 Signal Nooristani - Authentication")
        
        if self.replit_auth.is_replit_env:
            col1, col2, col3 = st.columns([1, 2, 1])
            
            with col2:
                st.markdown("### 🚀 Replit Auth Integration")
                
                if self.replit_auth.is_authenticated():
                    st.success("✅ You are authenticated with Replit!")
                    self.replit_auth.render_auth_status(current_lang)
                    
                    if st.button("Continue to Platform", type="primary", use_container_width=True):
                        return True
                else:
                    st.info("🔄 Authenticating with Replit...")
                    st.markdown("""
                    **Replit Auth provides:**
                    - 🔒 Zero-setup authentication
                    - 🛡️ Built-in security
                    - 👥 User management
                    - 🔄 Automatic login
                    """)
                    
                    # Auto-refresh to check authentication
                    import time
                    time.sleep(1)
                    st.rerun()
        else:
            st.warning("⚠️ Replit Auth is only available when running in Replit environment.")
            st.info("Running locally? The app will fall back to the built-in authentication system.")
            return False
        
        return self.replit_auth.is_authenticated()
    
    def check_authentication_flow(self, current_lang='en') -> bool:
        """Check authentication and handle flow"""
        if self.replit_auth.is_authenticated():
            return True
        
        # SECURITY FIX: Disabled Replit Auth due to vulnerability
        # Fall back to custom authentication system
        return False