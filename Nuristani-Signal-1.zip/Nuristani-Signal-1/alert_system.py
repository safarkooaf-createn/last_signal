import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import logging
import json
from pathlib import Path

# For future SMS integration (not implemented in this basic version)
# import twilio
# from twilio.rest import Client

class AlertSystem:
    """
    Handles email and SMS alerts for high-confidence cryptocurrency predictions
    """
    
    def __init__(self):
        # Email configuration (using environment variables for security)
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.email_username = os.getenv('EMAIL_USERNAME')
        self.email_password = os.getenv('EMAIL_PASSWORD')
        self.from_email = os.getenv('FROM_EMAIL', self.email_username)
        
        # SMS configuration (placeholder for future implementation)
        self.twilio_account_sid = os.getenv('TWILIO_ACCOUNT_SID')
        self.twilio_auth_token = os.getenv('TWILIO_AUTH_TOKEN')
        self.twilio_phone_number = os.getenv('TWILIO_PHONE_NUMBER')
        
        # Alert thresholds
        self.high_confidence_threshold = 75.0  # 75% confidence minimum
        self.probability_threshold = 0.7       # 70% probability minimum
        
        # Configure logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Check if email is configured
        self.email_enabled = bool(self.email_username and self.email_password)
        
        # Check if SMS is configured (placeholder)
        self.sms_enabled = bool(self.twilio_account_sid and self.twilio_auth_token)
        
        # Demo mode configuration (when no email/SMS is configured)
        self.demo_mode = not self.email_enabled
        self.alerts_file = Path("alerts_history.json")
        self.recent_alerts = []
        self.max_stored_alerts = 50
        
        # Initialize alert storage
        self._load_alert_history()
    
    def _load_alert_history(self):
        """Load alert history from JSON file"""
        try:
            if self.alerts_file.exists():
                with open(self.alerts_file, 'r') as f:
                    data = json.load(f)
                    self.recent_alerts = data.get('alerts', [])[-self.max_stored_alerts:]
        except Exception as e:
            self.logger.warning(f"Could not load alert history: {e}")
            self.recent_alerts = []
    
    def _save_alert_history(self):
        """Save alert history to JSON file"""
        try:
            # Keep only the most recent alerts
            alerts_to_save = self.recent_alerts[-self.max_stored_alerts:]
            
            data = {
                'alerts': alerts_to_save,
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.alerts_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Could not save alert history: {e}")
    
    def _store_demo_alert(self, crypto_symbol, crypto_name, prediction_data, current_price, time_interval, message_content):
        """Store alert in demo mode"""
        alert_record = {
            'timestamp': datetime.now().isoformat(),
            'crypto_symbol': crypto_symbol,
            'crypto_name': crypto_name,
            'time_interval': time_interval,
            'current_price': current_price,
            'prediction': {
                'direction': prediction_data.get('direction'),
                'confidence': prediction_data.get('confidence'),
                'probability': prediction_data.get('probability')
            },
            'message': {
                'subject': message_content['subject'],
                'body': message_content['body']
            },
            'alert_type': 'demo',
            'status': 'demo_stored'
        }
        
        self.recent_alerts.append(alert_record)
        self._save_alert_history()
        
        self.logger.info(f"Demo alert stored for {crypto_name} ({time_interval})")
        return True
    
    def get_recent_alerts(self, limit=10):
        """Get recent alerts for UI display"""
        return self.recent_alerts[-limit:] if self.recent_alerts else []
    
    def clear_alert_history(self):
        """Clear all stored alerts"""
        self.recent_alerts = []
        self._save_alert_history()
    
    def should_send_alert(self, prediction_data):
        """
        Determine if an alert should be sent based on prediction confidence
        
        Args:
            prediction_data (dict): Prediction data with confidence and probability
            
        Returns:
            bool: True if alert should be sent
        """
        confidence = prediction_data.get('confidence', 0)
        probability = prediction_data.get('probability', 0.5)
        direction = prediction_data.get('direction', 'sideways')
        
        # Don't alert for sideways predictions
        if direction == 'sideways':
            return False
        
        # Check if confidence and probability meet thresholds
        return (confidence >= self.high_confidence_threshold and 
                (probability >= self.probability_threshold or probability <= (1 - self.probability_threshold)))
    
    def generate_alert_message(self, crypto_symbol, crypto_name, prediction_data, current_price, time_interval):
        """
        Generate alert message content
        
        Args:
            crypto_symbol (str): Cryptocurrency symbol
            crypto_name (str): Cryptocurrency full name
            prediction_data (dict): Prediction data
            current_price (float): Current price
            time_interval (str): Time interval for prediction
            
        Returns:
            dict: Message content with subject and body
        """
        direction = prediction_data.get('direction', 'sideways')
        confidence = prediction_data.get('confidence', 0)
        probability = prediction_data.get('probability', 0.5)
        
        # Determine emoji and action
        if direction == 'up':
            emoji = '📈'
            action = 'RISE'
            trend_color = 'green'
        else:
            emoji = '📉'
            action = 'FALL'
            trend_color = 'red'
        
        # Generate subject
        subject = f"{emoji} High-Confidence Alert: {crypto_name} ({crypto_symbol.upper()}) - {action} Predicted!"
        
        # Generate body
        body = f"""
🚨 HIGH-CONFIDENCE CRYPTOCURRENCY PREDICTION ALERT 🚨

Cryptocurrency: {crypto_name} ({crypto_symbol.upper()})
Current Price: ${current_price:,.2f}
Prediction Time Frame: {time_interval}

📊 PREDICTION DETAILS:
• Direction: {direction.upper()} {emoji}
• Confidence Score: {confidence:.1f}%
• Probability: {probability:.1%}

⚡ RECOMMENDATION:
Our advanced ML models (LSTM + Random Forest) predict that {crypto_name} will {action} within the next {time_interval}.
This alert was triggered because the prediction meets our high-confidence criteria (>75% confidence).

⚠️ RISK DISCLAIMER:
This is an automated prediction based on technical analysis and machine learning models. 
Cryptocurrency investments are highly volatile and risky. This is for informational purposes only 
and should not be considered financial advice. Always do your own research and invest responsibly.

📅 Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
🤖 Source: Crypto Analysis Platform - Advanced ML Predictions

---
This alert was sent because you have enabled high-confidence prediction notifications.
To modify your alert preferences, visit the platform settings.
        """
        
        return {
            'subject': subject,
            'body': body.strip(),
            'priority': 'high' if confidence > 85 else 'normal'
        }
    
    def send_email_alert(self, to_email, message_content):
        """
        Send email alert
        
        Args:
            to_email (str): Recipient email address
            message_content (dict): Message with subject and body
            
        Returns:
            bool: True if email sent successfully
        """
        if not self.email_enabled:
            self.logger.warning("Email not configured. Cannot send email alert.")
            return False
        
        try:
            # Create message
            msg = MIMEMultipart()
            msg['From'] = self.from_email
            msg['To'] = to_email
            msg['Subject'] = message_content['subject']
            
            # Set priority if high
            if message_content.get('priority') == 'high':
                msg['X-Priority'] = '1'
                msg['Importance'] = 'high'
            
            # Attach body
            body = MIMEText(message_content['body'], 'plain')
            msg.attach(body)
            
            # Connect to server and send
            if not self.email_username or not self.email_password:
                self.logger.error("Email credentials not configured")
                return False
                
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(str(self.email_username), str(self.email_password))
                server.send_message(msg)
            
            self.logger.info(f"Email alert sent successfully to {to_email}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to send email alert: {e}")
            return False
    
    def send_sms_alert(self, to_phone, message_content):
        """
        Send SMS alert (placeholder for future implementation)
        
        Args:
            to_phone (str): Recipient phone number
            message_content (dict): Message content
            
        Returns:
            bool: True if SMS sent successfully
        """
        if not self.sms_enabled:
            self.logger.warning("SMS not configured. Cannot send SMS alert.")
            return False
        
        # Placeholder for SMS implementation
        # In a real implementation, you would use Twilio or similar service
        try:
            # Shortened message for SMS
            sms_body = (f"{message_content['subject'][:100]}... "
                       f"Check the full alert in your email or on the platform.")
            
            # TODO: Implement Twilio SMS sending
            # client = Client(self.twilio_account_sid, self.twilio_auth_token)
            # message = client.messages.create(
            #     body=sms_body,
            #     from_=self.twilio_phone_number,
            #     to=to_phone
            # )
            
            self.logger.info("SMS alerts not yet implemented")
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to send SMS alert: {e}")
            return False
    
    def process_prediction_alerts(self, crypto_symbol, crypto_name, predictions, current_price, alert_settings):
        """
        Process all predictions and send alerts for high-confidence ones
        
        Args:
            crypto_symbol (str): Cryptocurrency symbol
            crypto_name (str): Cryptocurrency name
            predictions (dict): All predictions by time interval
            current_price (float): Current price
            alert_settings (dict): User alert preferences
            
        Returns:
            dict: Summary of alerts sent
        """
        results = {
            'alerts_sent': 0,
            'email_alerts': 0,
            'sms_alerts': 0,
            'demo_alerts': 0,
            'failed_alerts': 0,
            'intervals_alerted': [],
            'demo_mode': self.demo_mode,
            'alert_details': []
        }
        
        if not alert_settings.get('enabled', False):
            return results
        
        for interval, prediction_data in predictions.items():
            if self.should_send_alert(prediction_data):
                # Generate alert message
                message = self.generate_alert_message(
                    crypto_symbol, crypto_name, prediction_data, current_price, interval
                )
                
                alert_sent = False
                
                # In demo mode, always store alerts for UI display
                if self.demo_mode:
                    success = self._store_demo_alert(
                        crypto_symbol, crypto_name, prediction_data, current_price, interval, message
                    )
                    
                    if success:
                        results['demo_alerts'] += 1
                        results['alerts_sent'] += 1
                        results['intervals_alerted'].append(interval)
                        alert_sent = True
                        
                        # Store alert details for UI display
                        results['alert_details'].append({
                            'interval': interval,
                            'direction': prediction_data.get('direction'),
                            'confidence': prediction_data.get('confidence'),
                            'subject': message['subject']
                        })
                
                # Send email alert if configured (and not in demo mode)
                elif (alert_settings.get('email_enabled', False) and 
                      alert_settings.get('email_address')):
                    
                    success = self.send_email_alert(
                        alert_settings['email_address'], message
                    )
                    
                    if success:
                        results['email_alerts'] += 1
                        results['alerts_sent'] += 1
                        results['intervals_alerted'].append(interval)
                        alert_sent = True
                        
                        results['alert_details'].append({
                            'interval': interval,
                            'direction': prediction_data.get('direction'),
                            'confidence': prediction_data.get('confidence'),
                            'subject': message['subject'],
                            'email_sent': True
                        })
                    else:
                        results['failed_alerts'] += 1
                
                # Send SMS alert if configured
                if (alert_settings.get('sms_enabled', False) and 
                    alert_settings.get('phone_number')):
                    
                    success = self.send_sms_alert(
                        alert_settings['phone_number'], message
                    )
                    
                    if success:
                        results['sms_alerts'] += 1
                        if not alert_sent:  # Don't double count
                            results['alerts_sent'] += 1
                    else:
                        results['failed_alerts'] += 1
        
        return results
    
    def get_alert_system_status(self):
        """
        Get current alert system configuration status
        
        Returns:
            dict: System status information
        """
        return {
            'email_configured': self.email_enabled,
            'sms_configured': self.sms_enabled,
            'smtp_server': self.smtp_server if self.email_enabled else None,
            'high_confidence_threshold': self.high_confidence_threshold,
            'probability_threshold': self.probability_threshold,
            'available_methods': [
                method for method in ['email', 'sms'] 
                if getattr(self, f'{method}_enabled')
            ]
        }
    
    def test_email_connection(self):
        """
        Test email server connection
        
        Returns:
            bool: True if connection successful
        """
        if not self.email_enabled:
            return False
        
        if not self.email_username or not self.email_password:
            return False
            
        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(str(self.email_username), str(self.email_password))
            return True
        except Exception as e:
            self.logger.error(f"Email connection test failed: {e}")
            return False