# Signal Nooristani API Contracts

## Authentication Endpoints

### POST /api/auth/register
Register a new user account.

**Request Body:**
```json
{
  "email": "string",
  "password": "string",
  "fullName": "string",
  "preferredLanguage": "en|fa|ps"
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "userId": "integer"
}
```

### POST /api/auth/login
Login with email and password.

**Request Body:**
```json
{
  "email": "string",
  "password": "string"
}
```

**Response (200):**
```json
{
  "success": true,
  "token": "string",
  "user": {
    "id": "integer",
    "email": "string",
    "fullName": "string",
    "preferredLanguage": "string"
  }
}
```

### POST /api/auth/logout
Logout the current user.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### GET /api/auth/me
Get current user profile.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "user": {
    "id": "integer",
    "email": "string",
    "fullName": "string",
    "preferences": {
      "preferredLanguage": "string",
      "preferredCurrency": "string",
      "emailNotifications": "boolean",
      "autoRefreshEnabled": "boolean",
      "refreshInterval": "integer",
      "theme": "string"
    }
  }
}
```

## Cryptocurrency Data Endpoints

### GET /api/crypto/prices
Get current prices for all supported cryptocurrencies.

**Response (200):**
```json
{
  "data": {
    "bitcoin": {
      "usd": "number",
      "usd_market_cap": "number",
      "usd_24h_vol": "number",
      "usd_24h_change": "number",
      "last_updated_at": "timestamp"
    },
    "ethereum": {
      ...
    },
    ...
  }
}
```

### GET /api/crypto/:symbol/historical
Get historical price data for a specific cryptocurrency.

**Parameters:**
- `:symbol` - Cryptocurrency symbol (e.g., bitcoin, ethereum)

**Query Parameters:**
- `days` - Number of days (default: 7)

**Response (200):**
```json
{
  "data": [
    {
      "timestamp": "ISO8601",
      "price": "number",
      "ma_20": "number",
      "ma_50": "number",
      "price_change": "number",
      "volatility": "number",
      "rsi": "number"
    },
    ...
  ]
}
```

### GET /api/crypto/list
Get list of supported cryptocurrencies.

**Response (200):**
```json
{
  "cryptocurrencies": [
    {
      "id": "bitcoin",
      "symbol": "BTC",
      "name": "Bitcoin"
    },
    {
      "id": "ethereum",
      "symbol": "ETH",
      "name": "Ethereum"
    },
    ...
  ]
}
```

## Prediction Endpoints

### GET /api/predictions/:symbol
Get prediction for a specific cryptocurrency.

**Parameters:**
- `:symbol` - Cryptocurrency symbol

**Query Parameters:**
- `interval` - Prediction interval (5min, 10min, 30min)
- `advanced` - Use advanced ML model (true/false, default: true)

**Response (200):**
```json
{
  "prediction": {
    "symbol": "string",
    "interval": "string",
    "direction": "up|down|sideways",
    "confidence": "number",
    "probability": "number",
    "currentPrice": "number",
    "modelType": "advanced_ml|basic_ta",
    "technicalIndicators": {
      "rsi": "number",
      "macd": "object",
      "sma": "object",
      "ema": "object"
    }
  }
}
```

### POST /api/predictions/save
Save a prediction to history.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "cryptoSymbol": "string",
  "interval": "string",
  "direction": "string",
  "confidence": "number",
  "probability": "number",
  "currentPrice": "number",
  "modelType": "string"
}
```

**Response (201):**
```json
{
  "success": true,
  "predictionId": "integer"
}
```

### GET /api/predictions/history
Get prediction history.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `symbol` - Filter by cryptocurrency (optional)
- `days` - Number of days to fetch (default: 30)
- `limit` - Max results (default: 100)

**Response (200):**
```json
{
  "predictions": [
    {
      "id": "integer",
      "cryptoSymbol": "string",
      "predictionTime": "ISO8601",
      "predictionInterval": "string",
      "predictedDirection": "string",
      "confidenceScore": "number",
      "probabilityScore": "number",
      "priceAtPrediction": "number",
      "priceAfterInterval": "number",
      "actualDirection": "string",
      "predictionAccuracy": "boolean",
      "modelType": "string"
    },
    ...
  ],
  "statistics": {
    "totalPredictions": "integer",
    "accuratePredictions": "integer",
    "accuracyPercentage": "number"
  }
}
```

## Portfolio Endpoints

### GET /api/portfolio
Get user's portfolio holdings.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "holdings": [
    {
      "id": "integer",
      "cryptoSymbol": "string",
      "cryptoName": "string",
      "quantity": "number",
      "averageBuyPrice": "number",
      "totalInvested": "number",
      "currentPrice": "number",
      "currentValue": "number",
      "profitLoss": "number",
      "profitLossPercentage": "number"
    },
    ...
  ],
  "summary": {
    "totalInvested": "number",
    "currentValue": "number",
    "totalProfitLoss": "number",
    "totalProfitLossPercentage": "number"
  }
}
```

### POST /api/portfolio/add
Add or update portfolio holding.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "cryptoSymbol": "string",
  "cryptoName": "string",
  "quantity": "number",
  "buyPrice": "number"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Holding added/updated successfully"
}
```

### DELETE /api/portfolio/:symbol
Remove a holding from portfolio.

**Headers:**
```
Authorization: Bearer <token>
```

**Parameters:**
- `:symbol` - Cryptocurrency symbol

**Response (200):**
```json
{
  "success": true,
  "message": "Holding removed successfully"
}
```

### GET /api/portfolio/performance
Get portfolio performance analytics.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `days` - Number of days (default: 30)

**Response (200):**
```json
{
  "performance": [
    {
      "date": "YYYY-MM-DD",
      "totalValue": "number",
      "dailyReturn": "number",
      "cumulativeReturn": "number",
      "accuracyRate": "number",
      "successfulPredictions": "integer",
      "totalPredictions": "integer"
    },
    ...
  ]
}
```

## Alert Endpoints

### GET /api/alerts
Get user's alert settings.

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "alerts": [
    {
      "id": "integer",
      "cryptoSymbol": "string",
      "alertType": "high_confidence|price_target|stop_loss",
      "alertCondition": "string",
      "isActive": "boolean",
      "triggeredAt": "ISO8601"
    },
    ...
  ]
}
```

### POST /api/alerts
Create a new alert.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "cryptoSymbol": "string",
  "alertType": "high_confidence|price_target|stop_loss",
  "alertCondition": "string",
  "emailEnabled": "boolean",
  "smsEnabled": "boolean"
}
```

**Response (201):**
```json
{
  "success": true,
  "alertId": "integer"
}
```

### DELETE /api/alerts/:id
Delete an alert.

**Headers:**
```
Authorization: Bearer <token>
```

**Parameters:**
- `:id` - Alert ID

**Response (200):**
```json
{
  "success": true,
  "message": "Alert deleted successfully"
}
```

## WebSocket Events

### Connection
```javascript
const socket = io('ws://localhost:5000', {
  auth: {
    token: 'Bearer <token>'
  }
});
```

### Events

#### Client -> Server

**subscribe_prices**
```json
{
  "symbols": ["bitcoin", "ethereum", ...]
}
```

**subscribe_predictions**
```json
{
  "symbol": "bitcoin",
  "interval": "5min"
}
```

#### Server -> Client

**price_update**
```json
{
  "symbol": "bitcoin",
  "price": "number",
  "change24h": "number",
  "timestamp": "ISO8601"
}
```

**prediction_update**
```json
{
  "symbol": "bitcoin",
  "prediction": {
    "direction": "up|down|sideways",
    "confidence": "number",
    "probability": "number"
  }
}
```

**alert_triggered**
```json
{
  "alertId": "integer",
  "cryptoSymbol": "string",
  "alertType": "string",
  "message": "string",
  "timestamp": "ISO8601"
}
```

## Error Response Format

All error responses follow this format:

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable error message",
    "details": {} // Optional additional details
  }
}
```

### Common Error Codes
- `AUTH_REQUIRED` - Authentication required
- `INVALID_TOKEN` - Invalid or expired token
- `USER_EXISTS` - User already exists
- `INVALID_CREDENTIALS` - Invalid email or password
- `VALIDATION_ERROR` - Request validation failed
- `NOT_FOUND` - Resource not found
- `RATE_LIMIT` - Rate limit exceeded
- `SERVER_ERROR` - Internal server error

## Rate Limiting

- Authentication endpoints: 5 requests per minute
- Public data endpoints: 60 requests per minute
- Private data endpoints: 30 requests per minute
- WebSocket connections: 1 per user

## Request/Response Headers

### Required Headers for Authenticated Endpoints
```
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

### CORS Headers (Server Response)
```
Access-Control-Allow-Origin: http://localhost:3000
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
Access-Control-Allow-Credentials: true
```