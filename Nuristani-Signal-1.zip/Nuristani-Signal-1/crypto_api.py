import requests
import pandas as pd
from datetime import datetime, timedelta
import time
import os
import numpy as np

class CryptoAPI:
    """
    Handles all API interactions with CoinGecko for cryptocurrency data
    """
    
    def __init__(self):
        self.base_url = "https://api.coingecko.com/api/v3"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'CryptoAnalysisPlatform/1.0'
        })
        self.use_fallback = False
        self.fallback_data = self._generate_fallback_data()
        
    def get_price_data(self, coin_ids):
        """
        Fetch current price data for specified cryptocurrencies
        
        Args:
            coin_ids (list): List of CoinGecko coin IDs
            
        Returns:
            dict: Price data for each cryptocurrency
        """
        try:
            if self.use_fallback:
                return self._get_fallback_price_data(coin_ids)
            
            coin_ids_str = ','.join(coin_ids)
            url = f"{self.base_url}/simple/price"
            
            params = {
                'ids': coin_ids_str,
                'vs_currencies': 'usd',
                'include_market_cap': 'true',
                'include_24hr_vol': 'true',
                'include_24hr_change': 'true',
                'include_last_updated_at': 'true'
            }
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching price data: {e}. Switching to fallback data.")
            self.use_fallback = True
            return self._get_fallback_price_data(coin_ids)
        except Exception as e:
            print(f"Unexpected error in get_price_data: {e}. Switching to fallback data.")
            self.use_fallback = True
            return self._get_fallback_price_data(coin_ids)
    
    def get_historical_data(self, coin_id, days=7):
        """
        Fetch historical price data for a cryptocurrency
        
        Args:
            coin_id (str): CoinGecko coin ID
            days (int): Number of days of historical data
            
        Returns:
            pandas.DataFrame: Historical price data with technical indicators
        """
        try:
            if self.use_fallback:
                return self._get_fallback_historical_data(coin_id, days)
            
            url = f"{self.base_url}/coins/{coin_id}/market_chart"
            
            params = {
                'vs_currency': 'usd',
                'days': days,
                'interval': 'hourly' if days <= 7 else 'daily'
            }
            
            response = self.session.get(url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            
            # Extract price data
            prices = data.get('prices', [])
            if not prices:
                return self._get_fallback_historical_data(coin_id, days)
            
            # Convert to DataFrame
            df = pd.DataFrame(prices)
            df.columns = ['timestamp', 'price']
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            # Calculate technical indicators
            df = self._calculate_technical_indicators(df)
            
            return df
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching historical data: {e}. Switching to fallback data.")
            self.use_fallback = True
            return self._get_fallback_historical_data(coin_id, days)
        except Exception as e:
            print(f"Unexpected error in get_historical_data: {e}. Switching to fallback data.")
            self.use_fallback = True
            return self._get_fallback_historical_data(coin_id, days)
    
    def _calculate_technical_indicators(self, df):
        """
        Calculate technical indicators for the price data
        
        Args:
            df (pandas.DataFrame): DataFrame with price data
            
        Returns:
            pandas.DataFrame: DataFrame with added technical indicators
        """
        try:
            if len(df) < 2:
                return df
            
            # Simple Moving Averages
            if len(df) >= 20:
                df['ma_20'] = df['price'].rolling(window=20).mean()
            
            if len(df) >= 50:
                df['ma_50'] = df['price'].rolling(window=50).mean()
            
            # Price change
            df['price_change'] = df['price'].pct_change()
            
            # Volatility (rolling standard deviation)
            if len(df) >= 10:
                df['volatility'] = df['price'].rolling(window=10).std()
            
            # RSI calculation (simplified)
            if len(df) >= 14:
                df['rsi'] = self._calculate_rsi(df['price'], 14)
            
            return df
            
        except Exception as e:
            print(f"Error calculating technical indicators: {e}")
            return df
    
    def _calculate_rsi(self, prices, period=14):
        """
        Calculate Relative Strength Index (RSI)
        
        Args:
            prices (pandas.Series): Price series
            period (int): RSI period
            
        Returns:
            pandas.Series: RSI values
        """
        try:
            delta = prices.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            
            return rsi
            
        except Exception as e:
            print(f"Error calculating RSI: {e}")
            return prices * 0  # Return zeros if calculation fails
    
    def get_market_data(self, coin_id):
        """
        Get comprehensive market data for a cryptocurrency
        
        Args:
            coin_id (str): CoinGecko coin ID
            
        Returns:
            dict: Market data including various metrics
        """
        try:
            url = f"{self.base_url}/coins/{coin_id}"
            
            params = {
                'localization': 'false',
                'tickers': 'false',
                'market_data': 'true',
                'community_data': 'false',
                'developer_data': 'false',
                'sparkline': 'false'
            }
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            market_data = data.get('market_data', {})
            
            return {
                'name': data.get('name', ''),
                'symbol': data.get('symbol', '').upper(),
                'current_price': market_data.get('current_price', {}).get('usd', 0),
                'market_cap': market_data.get('market_cap', {}).get('usd', 0),
                'total_volume': market_data.get('total_volume', {}).get('usd', 0),
                'price_change_24h': market_data.get('price_change_percentage_24h', 0),
                'price_change_7d': market_data.get('price_change_percentage_7d', 0),
                'price_change_30d': market_data.get('price_change_percentage_30d', 0),
                'circulating_supply': market_data.get('circulating_supply', 0),
                'total_supply': market_data.get('total_supply', 0),
                'max_supply': market_data.get('max_supply', 0),
                'ath': market_data.get('ath', {}).get('usd', 0),
                'atl': market_data.get('atl', {}).get('usd', 0),
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching market data: {e}")
            return {}
        except Exception as e:
            print(f"Unexpected error in get_market_data: {e}")
            return {}
    
    def _generate_fallback_data(self):
        """Generate realistic fallback data for demonstration"""
        base_prices = {
            'bitcoin': 45000,
            'ethereum': 2800,
            'binancecoin': 350,
            'cardano': 0.45,
            'solana': 95,
            'polkadot': 6.50,
            'chainlink': 12.50,
            'litecoin': 85,
            'polygon-matic-network': 0.85,
            'avalanche-2': 25
        }
        
        fallback_data = {}
        for coin_id, base_price in base_prices.items():
            # Add some random variation
            current_price = base_price * (1 + np.random.uniform(-0.05, 0.05))
            price_change_24h = np.random.uniform(-8, 8)
            
            fallback_data[coin_id] = {
                'current_price': current_price,
                'market_cap': current_price * np.random.uniform(18e6, 19.5e6),
                'total_volume': current_price * np.random.uniform(0.8e6, 1.2e6),
                'price_change_percentage_24h': price_change_24h,
                'last_updated_at': int(datetime.now().timestamp())
            }
        
        return fallback_data
    
    def _get_fallback_price_data(self, coin_ids):
        """Return fallback price data when API is unavailable"""
        result = {}
        for coin_id in coin_ids:
            if coin_id in self.fallback_data:
                # Add some minor real-time variation
                base_data = self.fallback_data[coin_id].copy()
                base_data['current_price'] *= (1 + np.random.uniform(-0.002, 0.002))
                result[coin_id] = base_data
            else:
                # Generate default fallback data for unknown coin IDs
                result[coin_id] = {
                    'current_price': 100.0,
                    'market_cap': 100.0 * 19e6,
                    'total_volume': 100.0 * 1e6,
                    'price_change_percentage_24h': np.random.uniform(-3, 3),
                    'last_updated_at': int(datetime.now().timestamp())
                }
        return result
    
    def _get_fallback_historical_data(self, coin_id, days=7):
        """Generate realistic historical data for fallback"""
        if coin_id not in self.fallback_data:
            # Generate fallback data for unknown coin IDs
            base_price = 100.0  # Default price
        else:
            base_price = self.fallback_data[coin_id]['current_price']
        
        # Generate realistic price history
        hours = days * 24
        timestamps = []
        prices = []
        
        current_time = datetime.now()
        current_price = base_price
        
        for i in range(hours):
            timestamp = current_time - timedelta(hours=hours-i-1)
            timestamps.append(timestamp)
            
            # Add realistic price movement
            change = np.random.normal(0, 0.02)  # 2% standard deviation
            current_price *= (1 + change)
            prices.append(current_price)
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': timestamps,
            'price': prices
        })
        
        # Calculate technical indicators
        df = self._calculate_technical_indicators(df)
        
        return df
