import asyncio
import websockets
import json
import threading
import time
from datetime import datetime
from crypto_api import CryptoAPI
from advanced_prediction_engine import AdvancedPredictionEngine

class RealTimeUpdater:
    """
    Provides enhanced real-time cryptocurrency data updates using efficient polling
    """
    
    def __init__(self):
        self.crypto_api = CryptoAPI()
        self.prediction_engine = AdvancedPredictionEngine()
        self.last_update_times = {}
        self.cached_data = {}
        self.update_intervals = {
            'price': 10,  # Update prices every 10 seconds
            'historical': 300,  # Update historical data every 5 minutes
            'predictions': 60  # Update predictions every minute
        }
        self.running = False
        self.update_thread = None
    
    def start_realtime_updates(self):
        """
        Start the real-time update system
        """
        if not self.running:
            self.running = True
            self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
            self.update_thread.start()
    
    def stop_realtime_updates(self):
        """
        Stop the real-time update system
        """
        self.running = False
        if self.update_thread:
            self.update_thread.join(timeout=1)
    
    def _update_loop(self):
        """
        Main update loop that runs in background thread
        """
        while self.running:
            try:
                current_time = datetime.now()
                
                # Update prices if needed
                if self._should_update('price', current_time):
                    self._update_prices()
                    self.last_update_times['price'] = current_time
                
                # Update historical data if needed
                if self._should_update('historical', current_time):
                    self._update_historical_data()
                    self.last_update_times['historical'] = current_time
                
                # Update predictions if needed
                if self._should_update('predictions', current_time):
                    self._update_predictions()
                    self.last_update_times['predictions'] = current_time
                
                # Sleep for 1 second before next check
                time.sleep(1)
                
            except Exception as e:
                print(f"Error in real-time update loop: {e}")
                time.sleep(5)  # Wait longer if there's an error
    
    def _should_update(self, update_type, current_time):
        """
        Check if a specific type of data should be updated
        """
        if update_type not in self.last_update_times:
            return True
        
        last_update = self.last_update_times[update_type]
        elapsed_seconds = (current_time - last_update).total_seconds()
        
        return elapsed_seconds >= self.update_intervals[update_type]
    
    def _update_prices(self):
        """
        Update current price data for all tracked cryptocurrencies
        """
        try:
            crypto_list = [
                'bitcoin', 'ethereum', 'binancecoin', 'cardano', 'solana',
                'polkadot', 'chainlink', 'litecoin', 'polygon-matic-network', 'avalanche-2'
            ]
            
            price_data = self.crypto_api.get_price_data(crypto_list)
            
            if price_data:
                self.cached_data['prices'] = price_data
                self.cached_data['price_timestamp'] = datetime.now()
                
        except Exception as e:
            print(f"Error updating prices: {e}")
    
    def _update_historical_data(self):
        """
        Update historical data for tracked cryptocurrencies
        """
        try:
            # Only update historical data for the most commonly viewed cryptos
            popular_cryptos = ['bitcoin', 'ethereum', 'binancecoin', 'cardano', 'solana']
            
            for crypto in popular_cryptos:
                historical_data = self.crypto_api.get_historical_data(crypto, days=7)
                
                if historical_data is not None and not historical_data.empty:
                    if 'historical' not in self.cached_data:
                        self.cached_data['historical'] = {}
                    
                    self.cached_data['historical'][crypto] = historical_data
            
            self.cached_data['historical_timestamp'] = datetime.now()
                    
        except Exception as e:
            print(f"Error updating historical data: {e}")
    
    def _update_predictions(self):
        """
        Update predictions for cryptocurrencies with recent historical data
        """
        try:
            if 'historical' not in self.cached_data:
                return
            
            for crypto_symbol, historical_data in self.cached_data['historical'].items():
                if historical_data is not None and not historical_data.empty:
                    # Generate predictions
                    predictions = self.prediction_engine.generate_advanced_predictions(
                        historical_data, crypto_symbol.upper().replace('-', '')
                    )
                    
                    if 'predictions' not in self.cached_data:
                        self.cached_data['predictions'] = {}
                    
                    self.cached_data['predictions'][crypto_symbol] = predictions
            
            self.cached_data['predictions_timestamp'] = datetime.now()
                    
        except Exception as e:
            print(f"Error updating predictions: {e}")
    
    def get_latest_data(self, crypto_symbol):
        """
        Get the latest cached data for a cryptocurrency
        """
        result = {}
        
        # Get price data
        if 'prices' in self.cached_data and crypto_symbol in self.cached_data['prices']:
            result['price_data'] = self.cached_data['prices'][crypto_symbol]
            result['price_timestamp'] = self.cached_data.get('price_timestamp')
        
        # Get historical data
        if 'historical' in self.cached_data and crypto_symbol in self.cached_data['historical']:
            result['historical_data'] = self.cached_data['historical'][crypto_symbol]
            result['historical_timestamp'] = self.cached_data.get('historical_timestamp')
        
        # Get predictions
        if 'predictions' in self.cached_data and crypto_symbol in self.cached_data['predictions']:
            result['predictions'] = self.cached_data['predictions'][crypto_symbol]
            result['predictions_timestamp'] = self.cached_data.get('predictions_timestamp')
        
        return result
    
    def get_all_prices(self):
        """
        Get all cached price data
        """
        if 'prices' in self.cached_data:
            return {
                'prices': self.cached_data['prices'],
                'timestamp': self.cached_data.get('price_timestamp')
            }
        return None
    
    def force_update(self, crypto_symbol):
        """
        Force an immediate update for a specific cryptocurrency
        """
        try:
            # Force update prices
            price_data = self.crypto_api.get_price_data([crypto_symbol])
            if price_data:
                if 'prices' not in self.cached_data:
                    self.cached_data['prices'] = {}
                self.cached_data['prices'].update(price_data)
            
            # Force update historical data
            historical_data = self.crypto_api.get_historical_data(crypto_symbol, days=7)
            if historical_data is not None and not historical_data.empty:
                if 'historical' not in self.cached_data:
                    self.cached_data['historical'] = {}
                self.cached_data['historical'][crypto_symbol] = historical_data
                
                # Update predictions based on new historical data
                predictions = self.prediction_engine.generate_advanced_predictions(
                    historical_data, crypto_symbol.upper().replace('-', '')
                )
                
                if 'predictions' not in self.cached_data:
                    self.cached_data['predictions'] = {}
                self.cached_data['predictions'][crypto_symbol] = predictions
            
            # Update timestamps
            current_time = datetime.now()
            self.cached_data['price_timestamp'] = current_time
            self.cached_data['historical_timestamp'] = current_time
            self.cached_data['predictions_timestamp'] = current_time
            
            return True
            
        except Exception as e:
            print(f"Error in force update: {e}")
            return False
    
    def get_cache_status(self):
        """
        Get information about the current cache status
        """
        status = {
            'running': self.running,
            'last_updates': self.last_update_times.copy(),
            'cached_data_types': list(self.cached_data.keys()),
            'update_intervals': self.update_intervals.copy()
        }
        
        # Add data counts
        if 'prices' in self.cached_data:
            status['cached_prices_count'] = len(self.cached_data['prices'])
        
        if 'historical' in self.cached_data:
            status['cached_historical_count'] = len(self.cached_data['historical'])
            
        if 'predictions' in self.cached_data:
            status['cached_predictions_count'] = len(self.cached_data['predictions'])
        
        return status
    
    def is_data_fresh(self, data_type, max_age_seconds=60):
        """
        Check if cached data is fresh enough
        """
        timestamp_key = f'{data_type}_timestamp'
        
        if timestamp_key not in self.cached_data:
            return False
        
        timestamp = self.cached_data[timestamp_key]
        age_seconds = (datetime.now() - timestamp).total_seconds()
        
        return age_seconds <= max_age_seconds