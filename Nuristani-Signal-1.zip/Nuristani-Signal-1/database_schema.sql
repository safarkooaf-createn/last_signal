-- Portfolio tracking database schema for crypto analysis platform

-- Authentication system tables
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255), -- Nullable for Replit Auth users
    full_name VARCHAR(255) NOT NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    failed_login_attempts INTEGER DEFAULT 0,
    last_failed_login TIMESTAMP,
    account_locked_until TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    replit_id VARCHAR(255) UNIQUE, -- For Replit Auth integration
    auth_provider VARCHAR(50) DEFAULT 'local' -- Track authentication provider
);

CREATE TABLE IF NOT EXISTS user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_preferences (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    preferred_language VARCHAR(10) DEFAULT 'en',
    preferred_currency VARCHAR(10) DEFAULT 'USD',
    email_notifications BOOLEAN DEFAULT TRUE,
    auto_refresh_enabled BOOLEAN DEFAULT TRUE,
    refresh_interval INTEGER DEFAULT 30,
    theme VARCHAR(20) DEFAULT 'default',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- Security audit log table
CREATE TABLE IF NOT EXISTS security_audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    event_type VARCHAR(50) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Authentication indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_users_replit_id ON users(replit_id) WHERE replit_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires ON user_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_security_audit_user_id ON security_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_security_audit_event_type ON security_audit_log(event_type);

-- Portfolio table to store user portfolios
CREATE TABLE IF NOT EXISTS portfolios (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Portfolio holdings table
CREATE TABLE IF NOT EXISTS portfolio_holdings (
    id SERIAL PRIMARY KEY,
    portfolio_id INTEGER REFERENCES portfolios(id) ON DELETE CASCADE,
    crypto_symbol VARCHAR(50) NOT NULL,
    crypto_name VARCHAR(255),
    quantity DECIMAL(20, 8) NOT NULL DEFAULT 0,
    average_buy_price DECIMAL(20, 8),
    total_invested DECIMAL(20, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(portfolio_id, crypto_symbol)
);

-- Prediction tracking table to store prediction history and accuracy
CREATE TABLE IF NOT EXISTS prediction_history (
    id SERIAL PRIMARY KEY,
    crypto_symbol VARCHAR(50) NOT NULL,
    prediction_time TIMESTAMP NOT NULL,
    prediction_interval VARCHAR(10) NOT NULL, -- '5min', '10min', '30min'
    predicted_direction VARCHAR(20) NOT NULL, -- 'up', 'down', 'sideways'
    confidence_score DECIMAL(5, 2) NOT NULL,
    probability_score DECIMAL(5, 4),
    price_at_prediction DECIMAL(20, 8) NOT NULL,
    price_after_interval DECIMAL(20, 8),
    actual_direction VARCHAR(20), -- 'up', 'down', 'sideways'
    prediction_accuracy BOOLEAN,
    model_type VARCHAR(50) NOT NULL, -- 'advanced_ml', 'basic_ta'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trading alerts table
CREATE TABLE IF NOT EXISTS trading_alerts (
    id SERIAL PRIMARY KEY,
    portfolio_id INTEGER REFERENCES portfolios(id) ON DELETE CASCADE,
    crypto_symbol VARCHAR(50) NOT NULL,
    alert_type VARCHAR(50) NOT NULL, -- 'high_confidence', 'price_target', 'stop_loss'
    alert_condition TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    triggered_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Performance analytics table
CREATE TABLE IF NOT EXISTS performance_analytics (
    id SERIAL PRIMARY KEY,
    portfolio_id INTEGER REFERENCES portfolios(id) ON DELETE CASCADE,
    date_calculated DATE NOT NULL,
    total_value DECIMAL(20, 2),
    daily_return DECIMAL(10, 4),
    cumulative_return DECIMAL(10, 4),
    accuracy_rate DECIMAL(5, 2), -- Prediction accuracy percentage
    successful_predictions INTEGER DEFAULT 0,
    total_predictions INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(portfolio_id, date_calculated)
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_portfolio_holdings_symbol ON portfolio_holdings(crypto_symbol);
CREATE INDEX IF NOT EXISTS idx_prediction_history_symbol_time ON prediction_history(crypto_symbol, prediction_time);
CREATE INDEX IF NOT EXISTS idx_prediction_history_interval ON prediction_history(prediction_interval);
CREATE INDEX IF NOT EXISTS idx_trading_alerts_active ON trading_alerts(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_performance_analytics_date ON performance_analytics(date_calculated);

-- Insert default portfolio
INSERT INTO portfolios (name, description) 
VALUES ('Default Portfolio', 'Default portfolio for tracking predictions and performance')
ON CONFLICT DO NOTHING;