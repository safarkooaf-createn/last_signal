#!/bin/bash

# Base URL for the API
BASE_URL="http://localhost:5000/api"

echo "🚀 Testing Signal Nooristani API Endpoints"
echo "=========================================="
echo ""

# Test prediction endpoints (no auth required for basic predictions)
echo "=== Testing Prediction Endpoints ==="
echo ""

echo "1. Testing basic prediction for bitcoin (5min)..."
curl -s "${BASE_URL}/predictions/bitcoin?interval=5min&advanced=false" | head -c 200
echo ""
echo ""

echo "2. Testing advanced prediction for ethereum (10min)..."
curl -s "${BASE_URL}/predictions/ethereum?interval=10min&advanced=true" | head -c 200
echo ""
echo ""

echo "3. Testing multi-interval predictions for bitcoin..."
curl -s "${BASE_URL}/predictions/bitcoin/multi?advanced=true" | head -c 300
echo ""
echo ""

echo "4. Testing POST basic prediction..."
curl -s -X POST "${BASE_URL}/predictions/basic" \
  -H "Content-Type: application/json" \
  -d '{"symbol":"cardano","interval":"5min"}' | head -c 200
echo ""
echo ""

echo "5. Testing POST advanced prediction..."
curl -s -X POST "${BASE_URL}/predictions/advanced" \
  -H "Content-Type: application/json" \
  -d '{"symbol":"solana","interval":"30min"}' | head -c 200
echo ""
echo ""

# Create test user and get token for authenticated endpoints
echo "=== Setting up Test User ==="
echo ""

echo "Creating test user..."
REGISTER_RESPONSE=$(curl -s -X POST "${BASE_URL}/auth/register" \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Test User","email":"test@example.com","password":"password123"}' 2>/dev/null)

echo "Logging in..."
LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}')

# Extract token from response (simple parsing)
TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ ! -z "$TOKEN" ]; then
    echo "✓ Authentication successful"
    echo ""
    
    echo "=== Testing Portfolio Endpoints (Authenticated) ==="
    echo ""
    
    echo "1. Getting current portfolio..."
    curl -s -H "Authorization: Bearer ${TOKEN}" "${BASE_URL}/portfolio" | head -c 200
    echo ""
    echo ""
    
    echo "2. Adding Bitcoin to portfolio..."
    curl -s -X POST "${BASE_URL}/portfolio/add" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H "Content-Type: application/json" \
      -d '{"cryptoSymbol":"bitcoin","cryptoName":"Bitcoin","quantity":0.5,"buyPrice":45000}' | head -c 200
    echo ""
    echo ""
    
    echo "3. Getting portfolio metrics..."
    curl -s -H "Authorization: Bearer ${TOKEN}" "${BASE_URL}/portfolio/metrics" | head -c 300
    echo ""
    echo ""
    
    echo "4. Saving a prediction to history..."
    curl -s -X POST "${BASE_URL}/predictions/save" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H "Content-Type: application/json" \
      -d '{"cryptoSymbol":"bitcoin","interval":"5min","direction":"up","confidence":75,"probability":0.75,"currentPrice":45000,"modelType":"advanced_ml"}' | head -c 200
    echo ""
    echo ""
    
    echo "5. Getting prediction history..."
    curl -s -H "Authorization: Bearer ${TOKEN}" "${BASE_URL}/predictions/history/list?days=30" | head -c 300
    echo ""
    
else
    echo "⚠ Authentication failed - skipping authenticated tests"
fi

echo ""
echo "=========================================="
echo "✅ API test completed!"