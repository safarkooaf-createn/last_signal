import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Alert,
  Grid,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguage } from '../contexts/LanguageContext';
import api from '../services/api';
import cryptoService from '../services/crypto.service';
import PortfolioChart from '../components/PortfolioChart';

const Portfolio = () => {
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingHolding, setEditingHolding] = useState(null);
  const [formData, setFormData] = useState({
    cryptoSymbol: '',
    quantity: '',
    purchasePrice: '',
    purchaseDate: new Date().toISOString().split('T')[0],
  });

  // Fetch crypto list
  const { data: cryptoList } = useQuery({
    queryKey: ['cryptoList'],
    queryFn: cryptoService.getCryptoList,
  });

  // Fetch current prices
  const { data: currentPrices } = useQuery({
    queryKey: ['prices'],
    queryFn: cryptoService.getCurrentPrices,
    refetchInterval: 30000,
  });

  // Fetch portfolio holdings
  const { data: portfolio, isLoading: loading } = useQuery({
    queryKey: ['portfolio'],
    queryFn: async () => {
      const response = await api.get('/portfolio');
      return response.data;
    },
  });

  const holdings = portfolio?.holdings || [];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">
          {t('portfolio.title')}
        </Typography>
        <Button variant="contained" startIcon={<AddIcon />}>
          {t('portfolio.addHolding')}
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>{t('portfolio.crypto')}</TableCell>
              <TableCell align="right">{t('portfolio.quantity')}</TableCell>
              <TableCell align="right">{t('portfolio.avgPrice')}</TableCell>
              <TableCell align="right">{t('portfolio.currentPrice')}</TableCell>
              <TableCell align="right">{t('portfolio.value')}</TableCell>
              <TableCell align="right">{t('portfolio.profitLoss')}</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {holdings.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center">
                  {t('portfolio.noHoldings')}
                </TableCell>
              </TableRow>
            ) : (
              holdings.map((holding) => (
                <TableRow key={holding.id}>
                  <TableCell>{holding.cryptoName}</TableCell>
                  <TableCell align="right">{holding.quantity}</TableCell>
                  <TableCell align="right">${holding.averageBuyPrice}</TableCell>
                  <TableCell align="right">${holding.currentPrice}</TableCell>
                  <TableCell align="right">${holding.currentValue}</TableCell>
                  <TableCell
                    align="right"
                    sx={{
                      color: holding.profitLoss > 0 ? 'success.main' : 'error.main'
                    }}
                  >
                    ${holding.profitLoss} ({holding.profitLossPercentage}%)
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default Portfolio;