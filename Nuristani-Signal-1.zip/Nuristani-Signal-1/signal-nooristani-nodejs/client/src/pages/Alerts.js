import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Button,
  CircularProgress,
  IconButton,
  Chip,
  Alert,
  Snackbar,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  NotificationsActive,
  NotificationsOff,
} from '@mui/icons-material';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguage } from '../contexts/LanguageContext';
import api from '../services/api';
import cryptoService from '../services/crypto.service';
import AlertDialog from '../components/AlertDialog';
import websocketService from '../services/websocket.service';

const Alerts = () => {
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', type: 'info' });

  // Fetch crypto list for alert creation
  const { data: cryptoList } = useQuery({
    queryKey: ['cryptoList'],
    queryFn: cryptoService.getCryptoList,
  });

  // Fetch user alerts
  const { data: alerts, isLoading } = useQuery({
    queryKey: ['alerts'],
    queryFn: async () => {
      const response = await api.get('/alerts');
      return response.data.alerts;
    },
  });

  // Create alert mutation
  const createAlertMutation = useMutation({
    mutationFn: async (alertData) => {
      const response = await api.post('/alerts', alertData);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alerts']);
      setNotification({ open: true, message: 'Alert created successfully', type: 'success' });
      setDialogOpen(false);
    },
    onError: (error) => {
      setNotification({ 
        open: true, 
        message: error.response?.data?.error?.message || 'Failed to create alert', 
        type: 'error' 
      });
    },
  });

  // Delete alert mutation
  const deleteAlertMutation = useMutation({
    mutationFn: async (alertId) => {
      const response = await api.delete(`/alerts/${alertId}`);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alerts']);
      setNotification({ open: true, message: 'Alert deleted successfully', type: 'success' });
    },
    onError: (error) => {
      setNotification({ 
        open: true, 
        message: error.response?.data?.error?.message || 'Failed to delete alert', 
        type: 'error' 
      });
    },
  });

  // Toggle alert status mutation
  const toggleAlertMutation = useMutation({
    mutationFn: async ({ alertId, isActive }) => {
      const response = await api.put(`/alerts/${alertId}`, { isActive });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alerts']);
      setNotification({ open: true, message: 'Alert updated successfully', type: 'success' });
    },
    onError: (error) => {
      setNotification({ 
        open: true, 
        message: error.response?.data?.error?.message || 'Failed to update alert', 
        type: 'error' 
      });
    },
  });

  // Setup WebSocket for alert notifications
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      websocketService.connect(token);
      
      // Subscribe to alert triggered events
      websocketService.subscribe('alert_triggered', (data) => {
        setNotification({
          open: true,
          message: data.message || `Alert triggered: ${data.cryptoSymbol}`,
          type: 'info'
        });
        // Refresh alerts list
        queryClient.invalidateQueries(['alerts']);
      });
    }

    return () => {
      websocketService.unsubscribe('alert_triggered');
    };
  }, [queryClient]);

  const handleCreateAlert = (alertData) => {
    createAlertMutation.mutate(alertData);
  };

  const handleDeleteAlert = (alertId) => {
    if (window.confirm('Are you sure you want to delete this alert?')) {
      deleteAlertMutation.mutate(alertId);
    }
  };

  const handleToggleAlert = (alertId, currentStatus) => {
    toggleAlertMutation.mutate({ alertId, isActive: !currentStatus });
  };

  const formatAlertCondition = (type, condition) => {
    try {
      const parsed = JSON.parse(condition);
      switch (type) {
        case 'price_above':
          return `Price > $${parsed.threshold}`;
        case 'price_below':
          return `Price < $${parsed.threshold}`;
        case 'price_change':
          return `${parsed.direction === 'up' ? '↑' : '↓'} ${parsed.percentage}%`;
        case 'volume_spike':
          return `Volume > $${(parsed.threshold / 1e6).toFixed(1)}M`;
        default:
          return condition;
      }
    } catch {
      return condition;
    }
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">
          {t('alerts.title')}
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => setDialogOpen(true)}
        >
          {t('alerts.createAlert')}
        </Button>
      </Box>

      {alerts?.length === 0 ? (
        <Paper sx={{ p: 3 }}>
          <Alert severity="info">
            <Typography variant="body1">{t('alerts.noAlerts')}</Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              {t('alerts.createFirstAlert')}
            </Typography>
          </Alert>
        </Paper>
      ) : (
        <Paper>
          <List>
            {alerts?.map((alert) => {
              const crypto = cryptoList?.find(c => c.id === alert.cryptoSymbol);
              return (
                <ListItem key={alert.id} divider>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="subtitle1">
                          {crypto?.name || alert.cryptoSymbol}
                        </Typography>
                        <Chip 
                          label={crypto?.symbol.toUpperCase() || 'N/A'} 
                          size="small" 
                          variant="outlined"
                        />
                        <Chip
                          label={alert.isActive ? 'Active' : 'Inactive'}
                          size="small"
                          color={alert.isActive ? 'success' : 'default'}
                          icon={alert.isActive ? <NotificationsActive /> : <NotificationsOff />}
                        />
                      </Box>
                    }
                    secondary={
                      <Box sx={{ mt: 1 }}>
                        <Typography variant="body2" color="text.secondary">
                          {formatAlertCondition(alert.alertType, alert.alertCondition)}
                        </Typography>
                        {alert.triggeredAt && (
                          <Typography variant="caption" color="text.secondary">
                            Triggered: {new Date(alert.triggeredAt).toLocaleString()}
                          </Typography>
                        )}
                      </Box>
                    }
                  />
                  <ListItemSecondaryAction>
                    <IconButton
                      edge="end"
                      onClick={() => handleToggleAlert(alert.id, alert.isActive)}
                      disabled={toggleAlertMutation.isLoading}
                    >
                      {alert.isActive ? <NotificationsOff /> : <NotificationsActive />}
                    </IconButton>
                    <IconButton
                      edge="end"
                      onClick={() => handleDeleteAlert(alert.id)}
                      disabled={deleteAlertMutation.isLoading}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              );
            })}
          </List>
        </Paper>
      )}

      <AlertDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSave={handleCreateAlert}
        cryptoList={cryptoList}
      />

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
      >
        <Alert 
          onClose={() => setNotification({ ...notification, open: false })} 
          severity={notification.type}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Alerts;