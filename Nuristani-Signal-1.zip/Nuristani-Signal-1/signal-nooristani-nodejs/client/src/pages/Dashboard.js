import React, { useState, useEffect } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Box,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import cryptoService from '../services/crypto.service';
import websocketService from '../services/websocket.service';
import { useLanguage } from '../contexts/LanguageContext';

const Dashboard = () => {
  const [prices, setPrices] = useState({});
  const { t } = useLanguage();

  // Fetch crypto prices
  const { data: cryptoList, isLoading: listLoading } = useQuery({
    queryKey: ['cryptoList'],
    queryFn: cryptoService.getCryptoList,
  });

  const { data: currentPrices, isLoading: pricesLoading } = useQuery({
    queryKey: ['prices'],
    queryFn: cryptoService.getCurrentPrices,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  useEffect(() => {
    if (currentPrices) {
      setPrices(currentPrices);
    }
  }, [currentPrices]);

  // Setup WebSocket for real-time updates
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token && cryptoList) {
      websocketService.connect(token);
      const symbols = cryptoList.map(c => c.id);
      
      websocketService.subscribeToPrices(symbols, (data) => {
        setPrices(prev => ({
          ...prev,
          [data.symbol]: {
            ...prev[data.symbol],
            usd: data.price,
            usd_24h_change: data.change24h,
          }
        }));
      });
    }

    return () => {
      websocketService.disconnect();
    };
  }, [cryptoList]);

  const formatPrice = (price) => {
    if (!price) return '$0.00';
    if (price >= 1) return `$${price.toFixed(2)}`;
    if (price >= 0.01) return `$${price.toFixed(4)}`;
    return `$${price.toFixed(8)}`;
  };

  const formatChange = (change) => {
    if (!change) return '0.00%';
    const sign = change > 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  if (listLoading || pricesLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('dashboard.title')}
      </Typography>

      {!cryptoList || cryptoList.length === 0 ? (
        <Alert severity="warning">{t('dashboard.noCryptos')}</Alert>
      ) : (
        <Grid container spacing={3}>
          {cryptoList.map((crypto) => {
            const price = prices[crypto.id];
            return (
              <Grid item xs={12} sm={6} md={4} key={crypto.id}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      {crypto.symbol.toUpperCase()}
                    </Typography>
                    <Typography variant="h5" component="h2">
                      {crypto.name}
                    </Typography>
                    <Typography variant="h6" sx={{ mt: 1 }}>
                      {formatPrice(price?.usd)}
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{
                        color: price?.usd_24h_change > 0 ? 'success.main' : 'error.main',
                        mt: 1
                      }}
                    >
                      {formatChange(price?.usd_24h_change)}
                    </Typography>
                    {price?.usd_market_cap && (
                      <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                        Market Cap: ${(price.usd_market_cap / 1e9).toFixed(2)}B
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      )}
    </Box>
  );
};

export default Dashboard;