import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  ToggleButton,
  ToggleButtonGroup,
  Paper,
} from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { useLanguage } from '../contexts/LanguageContext';
import api from '../services/api';
import cryptoService from '../services/crypto.service';
import websocketService from '../services/websocket.service';
import PredictionCard from '../components/PredictionCard';

const Predictions = () => {
  const { t } = useLanguage();
  const [selectedCrypto, setSelectedCrypto] = useState('bitcoin');
  const [selectedInterval, setSelectedInterval] = useState('10min');
  const [modelType, setModelType] = useState('advanced');
  const [realtimePrediction, setRealtimePrediction] = useState(null);

  // Fetch crypto list
  const { data: cryptoList } = useQuery({
    queryKey: ['cryptoList'],
    queryFn: cryptoService.getCryptoList,
  });

  // Fetch prediction for selected crypto and interval
  const { data: prediction, isLoading: loading, error } = useQuery({
    queryKey: ['prediction', selectedCrypto, selectedInterval, modelType],
    queryFn: async () => {
      const response = await api.get(`/predictions/${selectedCrypto}`, {
        params: {
          interval: selectedInterval,
          useAdvanced: modelType === 'advanced',
        },
      });
      return response.data.prediction;
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: !!selectedCrypto,
  });

  const predictions = prediction ? [prediction] : [];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('predictions.title')}
      </Typography>

      {predictions.length === 0 ? (
        <Typography variant="body1" color="textSecondary">
          {t('predictions.noPredictions')}
        </Typography>
      ) : (
        <Grid container spacing={3}>
          {predictions.map((prediction, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Card>
                <CardContent>
                  <Typography variant="h6">
                    {prediction.cryptoSymbol}
                  </Typography>
                  <Typography color="textSecondary">
                    {prediction.interval}
                  </Typography>
                  <Typography variant="h5" sx={{ mt: 1 }}>
                    {prediction.direction}
                  </Typography>
                  <Typography>
                    Confidence: {prediction.confidence}%
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default Predictions;