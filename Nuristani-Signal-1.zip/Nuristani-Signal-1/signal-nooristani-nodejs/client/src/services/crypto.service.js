import api from './api';

class CryptoService {
  async getCryptoList() {
    const response = await api.get('/crypto/list');
    return response.data.cryptocurrencies;
  }

  async getCurrentPrices() {
    const response = await api.get('/crypto/prices');
    return response.data.data;
  }

  async getHistoricalData(symbol, days = 7) {
    const response = await api.get(`/crypto/${symbol}/historical`, {
      params: { days }
    });
    return response.data.data;
  }

  async getCryptoDetails(symbol) {
    const response = await api.get(`/crypto/${symbol}/details`);
    return response.data.data;
  }
}

export default new CryptoService();