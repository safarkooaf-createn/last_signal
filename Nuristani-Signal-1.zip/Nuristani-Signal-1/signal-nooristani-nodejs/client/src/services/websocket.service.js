import io from 'socket.io-client';

class WebSocketService {
  constructor() {
    this.socket = null;
    this.subscribers = new Map();
  }

  connect(token) {
    if (this.socket) {
      return this.socket;
    }

    const WS_URL = process.env.REACT_APP_WS_URL || 'http://localhost:5000';
    
    this.socket = io(WS_URL, {
      auth: {
        token: `Bearer ${token}`
      },
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    this.socket.on('connect', () => {
      console.log('WebSocket connected');
    });

    this.socket.on('disconnect', () => {
      console.log('WebSocket disconnected');
    });

    this.socket.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    // Setup event listeners
    this.setupEventListeners();

    return this.socket;
  }

  setupEventListeners() {
    if (!this.socket) return;

    // Price updates
    this.socket.on('price_update', (data) => {
      this.notifySubscribers('price_update', data);
    });

    // Prediction updates
    this.socket.on('prediction_update', (data) => {
      this.notifySubscribers('prediction_update', data);
    });

    // Alert triggered
    this.socket.on('alert_triggered', (data) => {
      this.notifySubscribers('alert_triggered', data);
    });
  }

  subscribeToPrices(symbols, callback) {
    if (!this.socket) return;

    this.socket.emit('subscribe_prices', { symbols });
    this.subscribe('price_update', callback);
  }

  subscribeToPredictions(symbol, interval, callback) {
    if (!this.socket) return;

    this.socket.emit('subscribe_predictions', { symbol, interval });
    this.subscribe('prediction_update', callback);
  }

  subscribe(event, callback) {
    if (!this.subscribers.has(event)) {
      this.subscribers.set(event, []);
    }
    this.subscribers.get(event).push(callback);
  }

  unsubscribe(event, callback) {
    if (!this.subscribers.has(event)) return;
    
    const callbacks = this.subscribers.get(event);
    const index = callbacks.indexOf(callback);
    
    if (index > -1) {
      callbacks.splice(index, 1);
    }
  }

  notifySubscribers(event, data) {
    if (!this.subscribers.has(event)) return;
    
    this.subscribers.get(event).forEach(callback => {
      callback(data);
    });
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.subscribers.clear();
    }
  }
}

export default new WebSocketService();