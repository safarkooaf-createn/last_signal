import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Typography,
} from '@mui/material';
import { useLanguage } from '../contexts/LanguageContext';

const AlertDialog = ({ open, onClose, onSave, cryptoList }) => {
  const { t } = useLanguage();
  const [alertData, setAlertData] = useState({
    cryptoSymbol: '',
    alertType: 'price_above',
    threshold: '',
    percentage: '',
    direction: 'up',
  });

  const handleChange = (field, value) => {
    setAlertData({ ...alertData, [field]: value });
  };

  const handleSave = () => {
    const alertCondition = {};
    
    switch (alertData.alertType) {
      case 'price_above':
      case 'price_below':
        alertCondition.threshold = parseFloat(alertData.threshold);
        break;
      case 'price_change':
        alertCondition.percentage = parseFloat(alertData.percentage);
        alertCondition.direction = alertData.direction;
        break;
      case 'volume_spike':
        alertCondition.threshold = parseFloat(alertData.threshold);
        break;
    }

    onSave({
      cryptoSymbol: alertData.cryptoSymbol,
      alertType: alertData.alertType,
      alertCondition: JSON.stringify(alertCondition),
    });

    // Reset form
    setAlertData({
      cryptoSymbol: '',
      alertType: 'price_above',
      threshold: '',
      percentage: '',
      direction: 'up',
    });
  };

  const isValid = () => {
    if (!alertData.cryptoSymbol) return false;
    
    switch (alertData.alertType) {
      case 'price_above':
      case 'price_below':
      case 'volume_spike':
        return alertData.threshold && !isNaN(alertData.threshold);
      case 'price_change':
        return alertData.percentage && !isNaN(alertData.percentage);
      default:
        return false;
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Create New Alert</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
          <FormControl fullWidth>
            <InputLabel>Cryptocurrency</InputLabel>
            <Select
              value={alertData.cryptoSymbol}
              onChange={(e) => handleChange('cryptoSymbol', e.target.value)}
              label="Cryptocurrency"
            >
              {cryptoList?.map((crypto) => (
                <MenuItem key={crypto.id} value={crypto.id}>
                  {crypto.name} ({crypto.symbol.toUpperCase()})
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth>
            <InputLabel>Alert Type</InputLabel>
            <Select
              value={alertData.alertType}
              onChange={(e) => handleChange('alertType', e.target.value)}
              label="Alert Type"
            >
              <MenuItem value="price_above">Price Above</MenuItem>
              <MenuItem value="price_below">Price Below</MenuItem>
              <MenuItem value="price_change">Price Change %</MenuItem>
              <MenuItem value="volume_spike">Volume Spike</MenuItem>
            </Select>
          </FormControl>

          {(alertData.alertType === 'price_above' || 
            alertData.alertType === 'price_below' ||
            alertData.alertType === 'volume_spike') && (
            <TextField
              fullWidth
              label="Threshold"
              type="number"
              value={alertData.threshold}
              onChange={(e) => handleChange('threshold', e.target.value)}
              helperText={
                alertData.alertType === 'volume_spike' 
                  ? "Volume threshold in USD"
                  : "Price threshold in USD"
              }
            />
          )}

          {alertData.alertType === 'price_change' && (
            <>
              <FormControl fullWidth>
                <InputLabel>Direction</InputLabel>
                <Select
                  value={alertData.direction}
                  onChange={(e) => handleChange('direction', e.target.value)}
                  label="Direction"
                >
                  <MenuItem value="up">Increase</MenuItem>
                  <MenuItem value="down">Decrease</MenuItem>
                </Select>
              </FormControl>
              <TextField
                fullWidth
                label="Percentage"
                type="number"
                value={alertData.percentage}
                onChange={(e) => handleChange('percentage', e.target.value)}
                helperText="Percentage change threshold"
              />
            </>
          )}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={!isValid()}>
          Create Alert
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AlertDialog;