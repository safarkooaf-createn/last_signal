import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  LinearProgress,
} from '@mui/material';
import {
  TrendingUp,
  TrendingDown,
  TrendingFlat,
} from '@mui/icons-material';

const CryptoCard = ({ crypto, price, prediction }) => {
  const formatPrice = (value) => {
    if (!value) return '$0.00';
    if (value >= 1) return `$${value.toFixed(2)}`;
    if (value >= 0.01) return `$${value.toFixed(4)}`;
    return `$${value.toFixed(8)}`;
  };

  const formatChange = (change) => {
    if (!change) return '0.00%';
    const sign = change > 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  const getDirectionIcon = (direction) => {
    switch (direction) {
      case 'up':
        return <TrendingUp sx={{ color: 'success.main' }} />;
      case 'down':
        return <TrendingDown sx={{ color: 'error.main' }} />;
      default:
        return <TrendingFlat sx={{ color: 'text.secondary' }} />;
    }
  };

  const getDirectionColor = (direction) => {
    switch (direction) {
      case 'up':
        return 'success';
      case 'down':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Box>
            <Typography variant="h6" component="div">
              {crypto.name}
            </Typography>
            <Typography color="text.secondary" variant="body2">
              {crypto.symbol.toUpperCase()}
            </Typography>
          </Box>
          {prediction && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              {getDirectionIcon(prediction.direction)}
              <Chip
                label={`${prediction.confidence}%`}
                size="small"
                color={getDirectionColor(prediction.direction)}
              />
            </Box>
          )}
        </Box>

        <Typography variant="h4" sx={{ mb: 1 }}>
          {formatPrice(price?.usd)}
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography
            variant="body1"
            sx={{
              color: price?.usd_24h_change > 0 ? 'success.main' : 'error.main'
            }}
          >
            {formatChange(price?.usd_24h_change)}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            24h
          </Typography>
        </Box>

        {price?.usd_market_cap && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" color="text.secondary">
              Market Cap
            </Typography>
            <Typography variant="body2">
              ${(price.usd_market_cap / 1e9).toFixed(2)}B
            </Typography>
          </Box>
        )}

        {price?.usd_24h_vol && (
          <Box sx={{ mt: 1 }}>
            <Typography variant="caption" color="text.secondary">
              24h Volume
            </Typography>
            <Typography variant="body2">
              ${(price.usd_24h_vol / 1e6).toFixed(2)}M
            </Typography>
          </Box>
        )}

        {prediction && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" color="text.secondary">
              Prediction Confidence
            </Typography>
            <LinearProgress
              variant="determinate"
              value={prediction.confidence}
              sx={{ mt: 0.5 }}
              color={getDirectionColor(prediction.direction)}
            />
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default CryptoCard;