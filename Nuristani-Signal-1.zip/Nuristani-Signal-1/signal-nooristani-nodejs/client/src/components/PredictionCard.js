import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  LinearProgress,
  Divider,
} from '@mui/material';
import {
  TrendingUp,
  TrendingDown,
  TrendingFlat,
  ShowChart,
  Speed,
} from '@mui/icons-material';

const PredictionCard = ({ prediction }) => {
  if (!prediction) return null;

  const getDirectionIcon = (direction) => {
    switch (direction) {
      case 'up':
        return <TrendingUp sx={{ fontSize: 40, color: 'success.main' }} />;
      case 'down':
        return <TrendingDown sx={{ fontSize: 40, color: 'error.main' }} />;
      default:
        return <TrendingFlat sx={{ fontSize: 40, color: 'text.secondary' }} />;
    }
  };

  const getDirectionColor = (direction) => {
    switch (direction) {
      case 'up':
        return 'success';
      case 'down':
        return 'error';
      default:
        return 'default';
    }
  };

  const getConfidenceLevel = (confidence) => {
    if (confidence >= 80) return { label: 'Very High', color: 'success' };
    if (confidence >= 65) return { label: 'High', color: 'info' };
    if (confidence >= 50) return { label: 'Moderate', color: 'warning' };
    return { label: 'Low', color: 'error' };
  };

  const confidenceLevel = getConfidenceLevel(prediction.confidence);

  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6">
            {prediction.symbol.toUpperCase()}
          </Typography>
          <Chip
            label={prediction.interval}
            size="small"
            icon={<ShowChart />}
          />
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
          {getDirectionIcon(prediction.direction)}
          <Box>
            <Typography variant="h5" textTransform="capitalize">
              {prediction.direction}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Expected Direction
            </Typography>
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Confidence Score
            </Typography>
            <Typography variant="body2" fontWeight="bold">
              {prediction.confidence}%
            </Typography>
          </Box>
          <LinearProgress
            variant="determinate"
            value={prediction.confidence}
            color={getDirectionColor(prediction.direction)}
            sx={{ height: 8, borderRadius: 4 }}
          />
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
            <Chip
              label={confidenceLevel.label}
              size="small"
              color={confidenceLevel.color}
              icon={<Speed />}
            />
            <Typography variant="caption" color="text.secondary">
              Model: {prediction.modelType || 'ML'}
            </Typography>
          </Box>
        </Box>

        {prediction.technicalIndicators && (
          <>
            <Divider sx={{ my: 2 }} />
            <Typography variant="subtitle2" gutterBottom>
              Technical Indicators
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
              {prediction.technicalIndicators.rsi && (
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    RSI
                  </Typography>
                  <Typography variant="body2">
                    {prediction.technicalIndicators.rsi.toFixed(1)}
                  </Typography>
                </Box>
              )}
              {prediction.technicalIndicators.macd?.value && (
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    MACD
                  </Typography>
                  <Typography variant="body2">
                    {prediction.technicalIndicators.macd.value.toFixed(2)}
                  </Typography>
                </Box>
              )}
              {prediction.technicalIndicators.bollingerBands?.pb && (
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    BB %
                  </Typography>
                  <Typography variant="body2">
                    {(prediction.technicalIndicators.bollingerBands.pb * 100).toFixed(1)}%
                  </Typography>
                </Box>
              )}
              {prediction.technicalIndicators.stochastic?.k && (
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Stoch K
                  </Typography>
                  <Typography variant="body2">
                    {prediction.technicalIndicators.stochastic.k.toFixed(1)}
                  </Typography>
                </Box>
              )}
            </Box>
          </>
        )}

        {prediction.currentPrice && (
          <>
            <Divider sx={{ my: 2 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="caption" color="text.secondary">
                Current Price
              </Typography>
              <Typography variant="body2" fontWeight="bold">
                ${prediction.currentPrice.toFixed(2)}
              </Typography>
            </Box>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default PredictionCard;