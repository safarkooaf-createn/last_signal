import React from 'react';
import {
  FormControl,
  Select,
  MenuItem,
  Box,
  Typography,
} from '@mui/material';
import { Language } from '@mui/icons-material';
import { useLanguage } from '../contexts/LanguageContext';

const LanguageSelector = () => {
  const { language, setLanguage, t } = useLanguage();

  const languages = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'fa', name: 'فارسی', flag: '🇮🇷', rtl: true },
    { code: 'ps', name: 'پښتو', flag: '🇦🇫', rtl: true },
  ];

  const handleChange = (event) => {
    const newLang = event.target.value;
    setLanguage(newLang);
    
    // Update document direction for RTL languages
    const selectedLang = languages.find(l => l.code === newLang);
    document.dir = selectedLang?.rtl ? 'rtl' : 'ltr';
  };

  return (
    <FormControl size="small" sx={{ minWidth: 120 }}>
      <Select
        value={language}
        onChange={handleChange}
        displayEmpty
        startAdornment={<Language sx={{ mr: 1, color: 'action.active' }} />}
        sx={{
          '& .MuiSelect-select': {
            display: 'flex',
            alignItems: 'center',
          },
        }}
      >
        {languages.map((lang) => (
          <MenuItem key={lang.code} value={lang.code}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography>{lang.flag}</Typography>
              <Typography>{lang.name}</Typography>
            </Box>
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default LanguageSelector;