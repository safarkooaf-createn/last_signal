const axios = require('axios');

const BASE_URL = 'http://localhost:5000/api';

// Test user credentials
const testUser = {
  email: 'testuser@example.com',
  password: 'testpass123'
};

// Helper function for making API requests
async function makeRequest(method, endpoint, data = null, token = null) {
  const config = {
    method,
    url: `${BASE_URL}${endpoint}`,
    headers: {}
  };

  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }

  if (data) {
    config.data = data;
  }

  try {
    const response = await axios(config);
    return response.data;
  } catch (error) {
    console.error(`Error in ${method} ${endpoint}:`, error.response?.data || error.message);
    throw error;
  }
}

// Test functions
async function testPredictions(token) {
  console.log('\n=== Testing Prediction Endpoints ===\n');

  // Test 1: Get basic prediction for Bitcoin
  console.log('1. Testing basic prediction for Bitcoin...');
  try {
    const basicPrediction = await makeRequest('GET', '/predictions/bitcoin?interval=5min&advanced=false', null, token);
    console.log('✓ Basic prediction:', {
      symbol: basicPrediction.prediction.symbol,
      direction: basicPrediction.prediction.direction,
      confidence: basicPrediction.prediction.confidence,
      modelType: basicPrediction.prediction.modelType
    });
  } catch (error) {
    console.log('✗ Basic prediction failed');
  }

  // Test 2: Get advanced prediction for Ethereum
  console.log('\n2. Testing advanced prediction for Ethereum...');
  try {
    const advancedPrediction = await makeRequest('GET', '/predictions/ethereum?interval=10min&advanced=true', null, token);
    console.log('✓ Advanced prediction:', {
      symbol: advancedPrediction.prediction.symbol,
      direction: advancedPrediction.prediction.direction,
      confidence: advancedPrediction.prediction.confidence,
      modelType: advancedPrediction.prediction.modelType
    });
  } catch (error) {
    console.log('✗ Advanced prediction failed');
  }

  // Test 3: Get multi-interval predictions
  console.log('\n3. Testing multi-interval predictions for Bitcoin...');
  try {
    const multiPredictions = await makeRequest('GET', '/predictions/bitcoin/multi?advanced=true', null, token);
    console.log('✓ Multi-interval predictions:');
    Object.entries(multiPredictions.predictions).forEach(([interval, pred]) => {
      console.log(`  ${interval}: ${pred.direction} (${pred.confidence.toFixed(1)}% confidence)`);
    });
  } catch (error) {
    console.log('✗ Multi-interval predictions failed');
  }

  // Test 4: Test POST endpoints for basic and advanced predictions
  console.log('\n4. Testing POST endpoints...');
  try {
    const basicPost = await makeRequest('POST', '/predictions/basic', { symbol: 'cardano', interval: '5min' }, token);
    console.log('✓ Basic POST prediction:', basicPost.prediction.direction);

    const advancedPost = await makeRequest('POST', '/predictions/advanced', { symbol: 'solana', interval: '30min' }, token);
    console.log('✓ Advanced POST prediction:', advancedPost.prediction.direction);
  } catch (error) {
    console.log('✗ POST predictions failed');
  }

  // Test 5: Save prediction to history (authenticated)
  if (token) {
    console.log('\n5. Testing save prediction...');
    try {
      const saveResult = await makeRequest('POST', '/predictions/save', {
        cryptoSymbol: 'bitcoin',
        interval: '5min',
        direction: 'up',
        confidence: 75,
        probability: 0.75,
        currentPrice: 45000,
        modelType: 'advanced_ml'
      }, token);
      console.log('✓ Prediction saved with ID:', saveResult.predictionId);
    } catch (error) {
      console.log('✗ Save prediction failed');
    }
  }

  // Test 6: Get prediction history (authenticated)
  if (token) {
    console.log('\n6. Testing prediction history...');
    try {
      const history = await makeRequest('GET', '/predictions/history/list?days=30&limit=10', null, token);
      console.log('✓ Prediction history:', {
        totalPredictions: history.statistics.totalPredictions,
        accuracyPercentage: history.statistics.accuracyPercentage
      });
    } catch (error) {
      console.log('✗ Get prediction history failed');
    }
  }
}

async function testPortfolio(token) {
  console.log('\n=== Testing Portfolio Endpoints ===\n');

  if (!token) {
    console.log('Skipping portfolio tests (authentication required)');
    return;
  }

  // Test 1: Get current portfolio
  console.log('1. Testing get portfolio...');
  try {
    const portfolio = await makeRequest('GET', '/portfolio', null, token);
    console.log('✓ Current portfolio:', {
      holdings: portfolio.holdings.length,
      totalInvested: portfolio.summary.totalInvested,
      currentValue: portfolio.summary.currentValue
    });
  } catch (error) {
    console.log('✗ Get portfolio failed');
  }

  // Test 2: Add a holding to portfolio
  console.log('\n2. Testing add holding...');
  let holdingAdded = false;
  try {
    const addResult = await makeRequest('POST', '/portfolio/add', {
      cryptoSymbol: 'bitcoin',
      cryptoName: 'Bitcoin',
      quantity: 0.5,
      buyPrice: 45000
    }, token);
    console.log('✓ Holding added:', addResult.message);
    holdingAdded = true;
  } catch (error) {
    console.log('✗ Add holding failed');
  }

  // Test 3: Add another holding
  console.log('\n3. Testing add another holding...');
  try {
    const addResult = await makeRequest('POST', '/portfolio/add', {
      cryptoSymbol: 'ethereum',
      cryptoName: 'Ethereum',
      quantity: 5,
      buyPrice: 2500
    }, token);
    console.log('✓ Second holding added:', addResult.message);
  } catch (error) {
    console.log('✗ Add second holding failed');
  }

  // Test 4: Get portfolio performance metrics
  console.log('\n4. Testing portfolio metrics...');
  try {
    const metrics = await makeRequest('GET', '/portfolio/metrics', null, token);
    console.log('✓ Portfolio metrics:', {
      numberOfHoldings: metrics.metrics.numberOfHoldings,
      totalValue: metrics.metrics.summary.currentValue,
      totalProfitLoss: metrics.metrics.summary.totalProfitLoss
    });
    if (metrics.metrics.bestPerformer) {
      console.log('  Best performer:', metrics.metrics.bestPerformer.symbol);
    }
  } catch (error) {
    console.log('✗ Get portfolio metrics failed');
  }

  // Test 5: Get performance history
  console.log('\n5. Testing performance history...');
  try {
    const performance = await makeRequest('GET', '/portfolio/performance?days=30', null, token);
    console.log('✓ Performance history entries:', performance.performance.length);
  } catch (error) {
    console.log('✗ Get performance history failed');
  }

  // Test 6: Get transactions
  console.log('\n6. Testing transaction history...');
  try {
    const transactions = await makeRequest('GET', '/portfolio/transactions?days=30', null, token);
    console.log('✓ Transaction history entries:', transactions.transactions.length);
  } catch (error) {
    console.log('✗ Get transactions failed');
  }

  // Test 7: Remove a holding
  if (holdingAdded) {
    console.log('\n7. Testing remove holding...');
    try {
      const removeResult = await makeRequest('DELETE', '/portfolio/bitcoin', null, token);
      console.log('✓ Holding removed:', removeResult.message);
    } catch (error) {
      console.log('✗ Remove holding failed');
    }
  }

  // Test 8: Create a new portfolio
  console.log('\n8. Testing create new portfolio...');
  try {
    const newPortfolio = await makeRequest('POST', '/portfolio/create', {
      name: 'Test Portfolio',
      description: 'Portfolio for testing'
    }, token);
    console.log('✓ New portfolio created:', newPortfolio.portfolio.name);
  } catch (error) {
    console.log('✗ Create portfolio failed');
  }

  // Test 9: List all portfolios
  console.log('\n9. Testing list portfolios...');
  try {
    const portfolios = await makeRequest('GET', '/portfolio/list', null, token);
    console.log('✓ Total portfolios:', portfolios.portfolios.length);
  } catch (error) {
    console.log('✗ List portfolios failed');
  }
}

async function runTests() {
  console.log('🚀 Starting Signal Nooristani API Tests\n');
  console.log('================================\n');

  // First, try to create a test user
  let token = null;
  
  console.log('Setting up test user...');
  try {
    // Try to register
    await makeRequest('POST', '/auth/register', {
      username: 'testuser',
      email: testUser.email,
      password: testUser.password
    });
    console.log('✓ User registered');
  } catch (error) {
    // User might already exist, try to login
  }

  // Try to login
  try {
    const loginResult = await makeRequest('POST', '/auth/login', {
      email: testUser.email,
      password: testUser.password
    });
    token = loginResult.token;
    console.log('✓ User logged in successfully\n');
  } catch (error) {
    console.log('⚠ Running tests without authentication\n');
  }

  // Run prediction tests
  await testPredictions(token);

  // Run portfolio tests
  await testPortfolio(token);

  console.log('\n================================');
  console.log('✅ All tests completed!\n');
}

// Run the tests
runTests().catch(error => {
  console.error('Test suite failed:', error);
  process.exit(1);
});