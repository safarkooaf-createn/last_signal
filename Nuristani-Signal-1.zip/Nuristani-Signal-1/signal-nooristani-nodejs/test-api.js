const axios = require('axios');

const BASE_URL = 'http://localhost:5000/api';

// Test user credentials
const testUser = {
  email: 'test@example.com',
  password: 'TestPassword123',
  fullName: 'Test User',
  username: 'testuser',
  preferredLanguage: 'en'
};

let accessToken = null;
let refreshToken = null;

// Helper function to make API calls
async function apiCall(method, endpoint, data = null, token = null) {
  try {
    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {}
    };

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (data) {
      config.data = data;
    }

    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data || error.message,
      status: error.response?.status
    };
  }
}

async function runTests() {
  console.log('🚀 Starting API tests...\n');

  // Test 1: Register new user
  console.log('📝 Test 1: Register new user');
  const registerResult = await apiCall('POST', '/auth/register', testUser);
  
  if (registerResult.success) {
    console.log('✅ Registration successful:', registerResult.data);
  } else {
    if (registerResult.status === 409) {
      console.log('⚠️  User already exists, continuing with login test...');
    } else {
      console.log('❌ Registration failed:', registerResult.error);
    }
  }

  // Test 2: Login
  console.log('\n🔐 Test 2: Login');
  const loginResult = await apiCall('POST', '/auth/login', {
    email: testUser.email,
    password: testUser.password
  });

  if (loginResult.success) {
    console.log('✅ Login successful');
    console.log('   User:', loginResult.data.user);
    accessToken = loginResult.data.accessToken;
    refreshToken = loginResult.data.refreshToken;
  } else {
    console.log('❌ Login failed:', loginResult.error);
    return;
  }

  // Test 3: Get current user
  console.log('\n👤 Test 3: Get current user');
  const userResult = await apiCall('GET', '/auth/me', null, accessToken);

  if (userResult.success) {
    console.log('✅ Get user successful:', userResult.data.user);
  } else {
    console.log('❌ Get user failed:', userResult.error);
  }

  // Test 4: Refresh token
  console.log('\n🔄 Test 4: Refresh token');
  const refreshResult = await apiCall('POST', '/auth/refresh', {
    refreshToken: refreshToken
  });

  if (refreshResult.success) {
    console.log('✅ Token refresh successful');
    accessToken = refreshResult.data.accessToken;
    refreshToken = refreshResult.data.refreshToken;
  } else {
    console.log('❌ Token refresh failed:', refreshResult.error);
  }

  // Test 5: Get crypto prices
  console.log('\n💰 Test 5: Get crypto prices');
  const pricesResult = await apiCall('GET', '/crypto/prices');

  if (pricesResult.success) {
    console.log('✅ Get prices successful');
    const prices = pricesResult.data.data;
    console.log('   BTC:', prices.bitcoin?.usd, 'USD');
    console.log('   ETH:', prices.ethereum?.usd, 'USD');
  } else {
    console.log('❌ Get prices failed:', pricesResult.error);
  }

  // Test 6: Get trending cryptocurrencies
  console.log('\n📈 Test 6: Get trending cryptocurrencies');
  const trendingResult = await apiCall('GET', '/crypto/trending');

  if (trendingResult.success) {
    console.log('✅ Get trending successful');
    const trending = trendingResult.data.data.coins;
    console.log(`   Found ${trending.length} trending coins`);
    if (trending.length > 0) {
      console.log('   Top trending:', trending.slice(0, 3).map(c => c.name).join(', '));
    }
  } else {
    console.log('❌ Get trending failed:', trendingResult.error);
  }

  // Test 7: Get historical data
  console.log('\n📊 Test 7: Get historical data for Bitcoin');
  const historyResult = await apiCall('GET', '/crypto/bitcoin/historical?days=7');

  if (historyResult.success) {
    console.log('✅ Get historical data successful');
    const history = historyResult.data.data;
    console.log(`   Received ${history.length} data points`);
    if (history.length > 0) {
      console.log('   Latest price:', history[history.length - 1].price);
    }
  } else {
    console.log('❌ Get historical data failed:', historyResult.error);
  }

  // Test 8: Get crypto details
  console.log('\n📋 Test 8: Get crypto details for Ethereum');
  const detailsResult = await apiCall('GET', '/crypto/ethereum/details');

  if (detailsResult.success) {
    console.log('✅ Get details successful');
    const details = detailsResult.data.data;
    console.log('   Name:', details.name);
    console.log('   Current Price:', details.current_price, 'USD');
    console.log('   Market Cap:', details.market_cap, 'USD');
    console.log('   24h Change:', details.price_change_24h + '%');
  } else {
    console.log('❌ Get details failed:', detailsResult.error);
  }

  // Test 9: Update user preferences
  console.log('\n⚙️  Test 9: Update user preferences');
  const prefsResult = await apiCall('PATCH', '/auth/preferences', {
    preferredCurrency: 'EUR',
    theme: 'dark',
    refreshInterval: 60
  }, accessToken);

  if (prefsResult.success) {
    console.log('✅ Preferences updated successfully');
  } else {
    console.log('❌ Preferences update failed:', prefsResult.error);
  }

  // Test 10: Logout
  console.log('\n🚪 Test 10: Logout');
  const logoutResult = await apiCall('POST', '/auth/logout', {
    refreshToken: refreshToken
  }, accessToken);

  if (logoutResult.success) {
    console.log('✅ Logout successful');
  } else {
    console.log('❌ Logout failed:', logoutResult.error);
  }

  console.log('\n✨ API tests completed!');
}

// Run the tests
runTests().catch(console.error);