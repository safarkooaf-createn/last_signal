# Signal Nooristani - Node.js/React Platform

## Overview

Signal Nooristani is a professional cryptocurrency analysis and prediction platform, migrated from Python/Streamlit to a modern Node.js/Express backend with React frontend architecture.

## Project Structure

```
signal-nooristani-nodejs/
├── server/                  # Express backend API
│   ├── src/
│   │   ├── index.js        # Main server entry point
│   │   ├── routes/         # API route definitions
│   │   ├── services/       # Business logic services
│   │   ├── middleware/     # Auth & error handling
│   │   ├── config/         # Database configuration
│   │   └── utils/          # Helper utilities
├── client/                  # React frontend application
│   ├── src/
│   │   ├── App.js          # Root React component
│   │   ├── pages/          # Page components
│   │   ├── components/     # Reusable UI components
│   │   ├── contexts/       # React contexts
│   │   ├── services/       # API client services
│   │   └── translations.js # i18n translations
├── shared/                  # Shared types and constants
└── database_schema.sql      # PostgreSQL database schema
```

## Features

- **Real-time Cryptocurrency Tracking**: Monitor 10 major cryptocurrencies
- **ML-Based Predictions**: Advanced prediction engine with confidence scoring
- **Multi-language Support**: English, Persian (Farsi), and Pashto with RTL support
- **Portfolio Management**: Track holdings and performance
- **User Authentication**: JWT-based authentication system
- **WebSocket Support**: Real-time price updates
- **Alert System**: Configurable price and prediction alerts

## Prerequisites

- Node.js 18.x or higher
- PostgreSQL database
- npm or yarn package manager

## Installation

### 1. Clone the repository
```bash
cd signal-nooristani-nodejs
```

### 2. Install dependencies
```bash
# Install all dependencies
npm run install:all

# Or install separately:
cd server && npm install
cd ../client && npm install
```

### 3. Configure environment variables

Copy the `.env.example` file to `.env` in the server directory:
```bash
cp server/.env.example server/.env
```

Update the `.env` file with your configuration:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/signal_nooristani
JWT_SECRET=your-jwt-secret-key
PORT=5000
CLIENT_URL=http://localhost:3000
```

### 4. Set up the database

Ensure PostgreSQL is running and create the database:
```bash
createdb signal_nooristani
```

Run the schema file to create tables:
```bash
psql -d signal_nooristani -f database_schema.sql
```

## Running the Application

### Development Mode

Run both server and client concurrently:
```bash
# From root directory
npm run dev
```

Or run separately:

**Backend Server:**
```bash
cd server
npm run dev
# Server runs on http://localhost:5000
```

**Frontend Client:**
```bash
cd client
npm start
# Client runs on http://localhost:3000
```

### Production Mode

Build the client:
```bash
cd client
npm run build
```

Start the server:
```bash
cd server
npm start
```

## API Documentation

API endpoints are documented in `api_contracts.md`. Main endpoints include:

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user

### Cryptocurrency Data
- `GET /api/crypto/list` - List supported cryptocurrencies
- `GET /api/crypto/prices` - Get current prices
- `GET /api/crypto/:symbol/historical` - Get historical data

### Portfolio
- `GET /api/portfolio` - Get user holdings
- `POST /api/portfolio/add` - Add/update holding
- `DELETE /api/portfolio/:symbol` - Remove holding

### Predictions
- `GET /api/predictions/:symbol` - Get prediction
- `POST /api/predictions/save` - Save prediction
- `GET /api/predictions/history` - Get prediction history

### Alerts
- `GET /api/alerts` - Get user alerts
- `POST /api/alerts` - Create alert
- `DELETE /api/alerts/:id` - Delete alert

## WebSocket Events

The platform supports real-time updates via WebSocket:

- `price_update` - Real-time price updates
- `prediction_update` - Prediction updates
- `alert_triggered` - Alert notifications

## Database Schema

The platform uses PostgreSQL with the following main tables:

- **users** - User authentication and profile
- **user_preferences** - User settings and preferences
- **portfolios** - Portfolio containers
- **portfolio_holdings** - Cryptocurrency holdings
- **prediction_history** - Historical predictions
- **trading_alerts** - User-configured alerts
- **performance_analytics** - Performance metrics

See `database_schema.sql` for complete schema definition.

## Technology Stack

### Backend
- **Express.js** - Web framework
- **PostgreSQL** - Database
- **Socket.io** - WebSocket support
- **JWT** - Authentication
- **bcrypt** - Password hashing
- **CoinGecko API** - Cryptocurrency data

### Frontend
- **React** - UI framework
- **Material-UI** - Component library
- **React Query** - Data fetching
- **React Router** - Routing
- **i18next** - Internationalization
- **Socket.io-client** - WebSocket client

## Supported Cryptocurrencies

1. Bitcoin (BTC)
2. Ethereum (ETH)
3. Binance Coin (BNB)
4. Cardano (ADA)
5. Solana (SOL)
6. Polkadot (DOT)
7. Chainlink (LINK)
8. Litecoin (LTC)
9. Polygon (MATIC)
10. Avalanche (AVAX)

## Language Support

The platform supports three languages with automatic RTL layout:

- **English** (en)
- **Persian/Farsi** (fa) - RTL
- **Pashto** (ps) - RTL

## Development Guidelines

1. **API First**: All features should be API-driven
2. **Type Safety**: Use TypeScript where possible
3. **Error Handling**: Comprehensive error handling on both client and server
4. **Security**: Follow security best practices (helmet, rate limiting, input validation)
5. **Testing**: Write unit and integration tests
6. **Documentation**: Keep API documentation up to date

## Migration Status

This project has been migrated from Python/Streamlit to Node.js/React:

- ✅ Phase 0: Discovery & API Contracts
- ✅ Phase 1: Project Skeleton
- ⏳ Phase 2: Core Features (Next)
- ⏳ Phase 3: Advanced Features (Future)
- ⏳ Phase 4: Testing & Optimization (Future)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License

## Support

For issues or questions, please open an issue on GitHub.

---

**Note**: This is a development version. Ensure all security configurations are properly set before deploying to production.