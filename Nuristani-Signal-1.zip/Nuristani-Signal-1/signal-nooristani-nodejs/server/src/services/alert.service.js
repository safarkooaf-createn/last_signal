const { query, getClient } = require('../config/database');
const { AppError } = require('../middleware/errorHandler');

class AlertService {
  async getUserAlerts(userId) {
    // Get default portfolio ID for simplicity
    const portfolioResult = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    if (portfolioResult.rows.length === 0) {
      return [];
    }
    
    const portfolioId = portfolioResult.rows[0].id;
    
    const result = await query(
      `SELECT * FROM trading_alerts 
       WHERE portfolio_id = $1 
       ORDER BY created_at DESC`,
      [portfolioId]
    );
    
    return result.rows.map(alert => ({
      id: alert.id,
      cryptoSymbol: alert.crypto_symbol,
      alertType: alert.alert_type,
      alertCondition: alert.alert_condition,
      isActive: alert.is_active,
      triggeredAt: alert.triggered_at
    }));
  }

  async createAlert(data) {
    // Get default portfolio ID
    const portfolioResult = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    let portfolioId;
    if (portfolioResult.rows.length === 0) {
      // Create default portfolio if it doesn't exist
      const newPortfolio = await query(
        "INSERT INTO portfolios (name, description) VALUES ($1, $2) RETURNING id",
        ['Default Portfolio', 'Default portfolio for tracking']
      );
      portfolioId = newPortfolio.rows[0].id;
    } else {
      portfolioId = portfolioResult.rows[0].id;
    }
    
    const result = await query(
      `INSERT INTO trading_alerts 
       (portfolio_id, crypto_symbol, alert_type, alert_condition, is_active)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id`,
      [portfolioId, data.cryptoSymbol, data.alertType, data.alertCondition, true]
    );
    
    return result.rows[0].id;
  }

  async updateAlert(userId, alertId, updates) {
    // Get default portfolio ID to verify ownership
    const portfolioResult = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    if (portfolioResult.rows.length === 0) {
      throw new AppError('Portfolio not found', 404, 'NOT_FOUND');
    }
    
    const portfolioId = portfolioResult.rows[0].id;
    
    // Build update query dynamically
    const updateFields = [];
    const values = [];
    let paramCount = 1;
    
    if (updates.alertCondition !== undefined) {
      updateFields.push(`alert_condition = $${paramCount++}`);
      values.push(updates.alertCondition);
    }
    
    if (updates.isActive !== undefined) {
      updateFields.push(`is_active = $${paramCount++}`);
      values.push(updates.isActive);
    }
    
    if (updateFields.length === 0) {
      throw new AppError('No valid fields to update', 400, 'VALIDATION_ERROR');
    }
    
    values.push(alertId, portfolioId);
    
    const result = await query(
      `UPDATE trading_alerts 
       SET ${updateFields.join(', ')}
       WHERE id = $${paramCount++} AND portfolio_id = $${paramCount}`,
      values
    );
    
    if (result.rowCount === 0) {
      throw new AppError('Alert not found', 404, 'NOT_FOUND');
    }
    
    return true;
  }

  async deleteAlert(userId, alertId) {
    // Get default portfolio ID to verify ownership
    const portfolioResult = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    if (portfolioResult.rows.length === 0) {
      throw new AppError('Portfolio not found', 404, 'NOT_FOUND');
    }
    
    const portfolioId = portfolioResult.rows[0].id;
    
    const result = await query(
      `DELETE FROM trading_alerts 
       WHERE id = $1 AND portfolio_id = $2`,
      [alertId, portfolioId]
    );
    
    if (result.rowCount === 0) {
      throw new AppError('Alert not found', 404, 'NOT_FOUND');
    }
    
    return true;
  }

  async getAlertHistory(userId, days) {
    // Get default portfolio ID
    const portfolioResult = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    if (portfolioResult.rows.length === 0) {
      return [];
    }
    
    const portfolioId = portfolioResult.rows[0].id;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const result = await query(
      `SELECT * FROM trading_alerts 
       WHERE portfolio_id = $1 AND triggered_at >= $2
       ORDER BY triggered_at DESC`,
      [portfolioId, startDate]
    );
    
    return result.rows.map(alert => ({
      id: alert.id,
      cryptoSymbol: alert.crypto_symbol,
      alertType: alert.alert_type,
      alertCondition: alert.alert_condition,
      triggeredAt: alert.triggered_at
    }));
  }

  // Method to check and trigger alerts based on conditions
  async checkAlerts() {
    try {
      // Get all active alerts
      const result = await query(
        `SELECT ta.*, p.id as portfolio_id
         FROM trading_alerts ta
         JOIN portfolios p ON ta.portfolio_id = p.id
         WHERE ta.is_active = true`
      );
      
      if (result.rows.length === 0) return;
      
      // Get current prices
      const cryptoService = require('./crypto.service');
      const prices = await cryptoService.getCurrentPrices();
      
      // Check each alert condition
      for (const alert of result.rows) {
        const currentPrice = prices[alert.crypto_symbol]?.usd;
        if (!currentPrice) continue;
        
        let triggered = false;
        const condition = JSON.parse(alert.alert_condition || '{}');
        
        switch (alert.alert_type) {
          case 'price_above':
            triggered = currentPrice > condition.threshold;
            break;
          case 'price_below':
            triggered = currentPrice < condition.threshold;
            break;
          case 'price_change':
            const change = prices[alert.crypto_symbol]?.usd_24h_change;
            if (condition.direction === 'up') {
              triggered = change > condition.percentage;
            } else {
              triggered = change < -condition.percentage;
            }
            break;
          case 'volume_spike':
            const volume = prices[alert.crypto_symbol]?.usd_24h_vol;
            triggered = volume > condition.threshold;
            break;
        }
        
        if (triggered && !alert.triggered_at) {
          await this.triggerAlert(alert, currentPrice);
        }
      }
    } catch (error) {
      console.error('Error checking alerts:', error);
    }
  }
  
  async triggerAlert(alert, currentPrice) {
    // Update alert as triggered
    await query(
      `UPDATE trading_alerts 
       SET triggered_at = NOW(), is_active = false
       WHERE id = $1`,
      [alert.id]
    );
    
    // Broadcast alert via WebSocket
    const websocketService = require('./websocket.service');
    websocketService.broadcastAlert(alert.portfolio_id, {
      id: alert.id,
      cryptoSymbol: alert.crypto_symbol,
      alertType: alert.alert_type,
      alertCondition: alert.alert_condition,
      currentPrice,
      message: `Alert triggered: ${alert.crypto_symbol.toUpperCase()} ${alert.alert_type}`,
      timestamp: new Date().toISOString()
    });
    
    console.log(`Alert triggered: ${alert.crypto_symbol} ${alert.alert_type}`);
  }
  
  // Start periodic alert monitoring
  startMonitoring(interval = 60000) {
    // Check alerts every minute
    setInterval(() => {
      this.checkAlerts();
    }, interval);
    
    // Initial check
    this.checkAlerts();
    console.log('Alert monitoring started');
  }
}

module.exports = new AlertService();