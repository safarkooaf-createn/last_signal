const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { query, getClient } = require('../config/database');
const { AppError } = require('../middleware/errorHandler');

class AuthService {
  constructor() {
    this.JWT_SECRET = process.env.JWT_SECRET || 'default-secret-change-this';
    this.ACCESS_TOKEN_EXPIRE = '1h';
    this.REFRESH_TOKEN_EXPIRE = '7d';
    this.REFRESH_TOKEN_EXPIRE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds
  }

  // Register new user
  async register(userData) {
    const { email, password, fullName, preferredLanguage = 'en' } = userData;
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if user exists
      const existingUser = await client.query(
        'SELECT id FROM users WHERE email = $1',
        [email.toLowerCase()]
      );
      
      if (existingUser.rows.length > 0) {
        throw new AppError('User with this email or username already exists', 409, 'USER_EXISTS');
      }
      
      // Hash password
      const passwordHash = await bcrypt.hash(password, 12);
      
      // Create user
      const newUser = await client.query(
        `INSERT INTO users (email, password_hash, full_name, email_verified, auth_provider, is_active)
         VALUES ($1, $2, $3, $4, $5, $6) 
         RETURNING id, email, full_name`,
        [
          email.toLowerCase(),
          passwordHash,
          fullName,
          false, // email_verified
          'local',
          true // is_active
        ]
      );
      
      const user = newUser.rows[0];
      
      // Create user preferences
      await client.query(
        `INSERT INTO user_preferences (user_id, preferred_language, theme, refresh_interval, auto_refresh_enabled)
         VALUES ($1, $2, $3, $4, $5)`,
        [user.id, preferredLanguage, 'default', 30, true]
      );
      
      await client.query('COMMIT');
      
      return {
        id: user.id,
        email: user.email,
        fullName: user.full_name
      };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  // User login
  async login(email, password) {
    // Get user
    const userResult = await query(
      `SELECT u.*, p.preferred_language, p.theme, p.refresh_interval, p.auto_refresh_enabled
       FROM users u
       LEFT JOIN user_preferences p ON u.id = p.user_id
       WHERE u.email = $1 AND u.auth_provider = 'local'`,
      [email.toLowerCase()]
    );
    
    if (userResult.rows.length === 0) {
      throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
    }
    
    const user = userResult.rows[0];
    
    // Check if user is active
    if (!user.is_active) {
      throw new AppError('Account is deactivated', 401, 'ACCOUNT_DEACTIVATED');
    }
    
    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    if (!isValidPassword) {
      throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
    }
    
    // Generate tokens
    const { accessToken, refreshToken } = await this.generateTokens(user.id);
    
    // Save refresh token to database
    await this.saveRefreshToken(user.id, refreshToken);
    
    // Update last login
    await query(
      'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1',
      [user.id]
    );
    
    return {
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        preferences: {
          preferredLanguage: user.preferred_language || 'en',
          theme: user.theme || 'default',
          refreshInterval: user.refresh_interval || 30,
          autoRefreshEnabled: user.auto_refresh_enabled !== false
        }
      },
      accessToken,
      refreshToken
    };
  }

  // Generate JWT tokens
  async generateTokens(userId) {
    const payload = { userId, type: 'access' };
    
    const accessToken = jwt.sign(
      payload,
      this.JWT_SECRET,
      { expiresIn: this.ACCESS_TOKEN_EXPIRE }
    );
    
    const refreshPayload = { userId, type: 'refresh', tokenId: crypto.randomBytes(16).toString('hex') };
    const refreshToken = jwt.sign(
      refreshPayload,
      this.JWT_SECRET,
      { expiresIn: this.REFRESH_TOKEN_EXPIRE }
    );
    
    return { accessToken, refreshToken };
  }

  // Save refresh token to database
  async saveRefreshToken(userId, refreshToken, ipAddress = null, userAgent = null) {
    const expiresAt = new Date(Date.now() + this.REFRESH_TOKEN_EXPIRE_MS);
    
    // Delete old tokens for this user
    await query(
      'DELETE FROM user_sessions WHERE user_id = $1',
      [userId]
    );
    
    // Insert new token - store the full token in session_token
    await query(
      `INSERT INTO user_sessions (user_id, session_token, expires_at, created_at, ip_address, user_agent)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP, $4, $5)`,
      [userId, refreshToken, expiresAt, ipAddress, userAgent]
    );
  }

  // Refresh access token
  async refreshAccessToken(refreshToken) {
    try {
      // Verify refresh token
      const decoded = jwt.verify(refreshToken, this.JWT_SECRET);
      
      if (decoded.type !== 'refresh') {
        throw new AppError('Invalid refresh token', 401, 'INVALID_TOKEN');
      }
      
      // Check if refresh token exists in database
      const sessionResult = await query(
        `SELECT s.*, u.email, u.full_name, u.is_active
         FROM user_sessions s
         JOIN users u ON s.user_id = u.id
         WHERE s.session_token = $1 AND s.expires_at > CURRENT_TIMESTAMP`,
        [refreshToken]
      );
      
      if (sessionResult.rows.length === 0) {
        throw new AppError('Invalid or expired refresh token', 401, 'TOKEN_EXPIRED');
      }
      
      const session = sessionResult.rows[0];
      
      if (!session.is_active) {
        throw new AppError('Account is deactivated', 401, 'ACCOUNT_DEACTIVATED');
      }
      
      // Generate new tokens
      const { accessToken, refreshToken: newRefreshToken } = await this.generateTokens(session.user_id);
      
      // Update refresh token in database
      await this.saveRefreshToken(session.user_id, newRefreshToken);
      
      return {
        accessToken,
        refreshToken: newRefreshToken,
        user: {
          id: session.user_id,
          email: session.email,
          fullName: session.full_name
        }
      };
    } catch (error) {
      if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
        throw new AppError('Invalid or expired refresh token', 401, 'TOKEN_EXPIRED');
      }
      throw error;
    }
  }

  // Logout user
  async logout(userId, refreshToken = null) {
    if (refreshToken) {
      // Delete specific session
      await query(
        'DELETE FROM user_sessions WHERE user_id = $1 AND session_token = $2',
        [userId, refreshToken]
      );
    } else {
      // Delete all sessions for user
      await query(
        'DELETE FROM user_sessions WHERE user_id = $1',
        [userId]
      );
    }
  }

  // Verify access token
  async verifyAccessToken(token) {
    try {
      const decoded = jwt.verify(token, this.JWT_SECRET);
      
      if (decoded.type === 'refresh') {
        throw new AppError('Invalid access token', 401, 'INVALID_TOKEN');
      }
      
      // Get user
      const userResult = await query(
        'SELECT id, email, full_name FROM users WHERE id = $1 AND is_active = true',
        [decoded.userId]
      );
      
      if (userResult.rows.length === 0) {
        throw new AppError('User not found or inactive', 401, 'USER_NOT_FOUND');
      }
      
      return userResult.rows[0];
    } catch (error) {
      if (error.name === 'JsonWebTokenError') {
        throw new AppError('Invalid token', 401, 'INVALID_TOKEN');
      } else if (error.name === 'TokenExpiredError') {
        throw new AppError('Token expired', 401, 'TOKEN_EXPIRED');
      }
      throw error;
    }
  }

  // Get user by ID
  async getUserById(userId) {
    const userResult = await query(
      `SELECT u.*, p.*
       FROM users u
       LEFT JOIN user_preferences p ON u.id = p.user_id
       WHERE u.id = $1`,
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      throw new AppError('User not found', 404, 'USER_NOT_FOUND');
    }
    
    const user = userResult.rows[0];
    
    return {
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      emailVerified: user.email_verified,
      isActive: user.is_active,
      createdAt: user.created_at,
      lastLogin: user.last_login,
      preferences: {
        preferredLanguage: user.preferred_language || 'en',
        preferredCurrency: user.preferred_currency || 'USD',
        theme: user.theme || 'default',
        emailNotifications: user.email_notifications !== false,
        autoRefreshEnabled: user.auto_refresh_enabled !== false,
        refreshInterval: user.refresh_interval || 30
      }
    };
  }

  // Clean expired sessions
  async cleanExpiredSessions() {
    const result = await query(
      'DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP'
    );
    return result.rowCount;
  }

  // Update user preferences
  async updateUserPreferences(userId, preferences) {
    const allowedFields = [
      'preferred_language', 'preferred_currency', 'theme',
      'email_notifications', 'auto_refresh_enabled', 'refresh_interval'
    ];
    
    const updates = [];
    const values = [];
    let paramCount = 1;
    
    for (const [key, value] of Object.entries(preferences)) {
      const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
      if (allowedFields.includes(dbKey)) {
        updates.push(`${dbKey} = $${paramCount++}`);
        values.push(value);
      }
    }
    
    if (updates.length === 0) {
      return null;
    }
    
    values.push(userId);
    
    const result = await query(
      `UPDATE user_preferences SET ${updates.join(', ')} 
       WHERE user_id = $${paramCount}
       RETURNING *`,
      values
    );
    
    return result.rows[0];
  }

  // Change password
  async changePassword(userId, currentPassword, newPassword) {
    const userResult = await query(
      'SELECT password_hash FROM users WHERE id = $1',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      throw new AppError('User not found', 404, 'USER_NOT_FOUND');
    }
    
    // Verify current password
    const isValid = await bcrypt.compare(currentPassword, userResult.rows[0].password_hash);
    if (!isValid) {
      throw new AppError('Current password is incorrect', 401, 'INVALID_PASSWORD');
    }
    
    // Hash new password
    const newPasswordHash = await bcrypt.hash(newPassword, 12);
    
    // Update password
    await query(
      'UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      [newPasswordHash, userId]
    );
    
    // Invalidate all sessions
    await this.logout(userId);
  }
}

module.exports = new AuthService();