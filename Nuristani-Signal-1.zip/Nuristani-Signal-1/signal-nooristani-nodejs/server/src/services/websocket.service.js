const jwt = require('jsonwebtoken');
const cryptoService = require('./crypto.service');

let io = null;
const connectedClients = new Map();

const initializeWebSocket = (socketIO) => {
  io = socketIO;
  
  // Authentication middleware for WebSocket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      
      if (!token) {
        return next(new Error('Authentication required'));
      }
      
      // Remove 'Bearer ' prefix if present
      const cleanToken = token.replace('Bearer ', '');
      
      // Verify JWT token
      const decoded = jwt.verify(cleanToken, process.env.JWT_SECRET || 'default-secret-change-this');
      socket.userId = decoded.userId;
      
      next();
    } catch (err) {
      next(new Error('Authentication failed'));
    }
  });
  
  io.on('connection', (socket) => {
    console.log(`Client connected: ${socket.id}, User: ${socket.userId}`);
    
    // Store client connection
    connectedClients.set(socket.id, {
      userId: socket.userId,
      socket,
      subscriptions: new Set()
    });
    
    // Handle price subscriptions
    socket.on('subscribe_prices', (data) => {
      const client = connectedClients.get(socket.id);
      if (client && data.symbols) {
        data.symbols.forEach(symbol => client.subscriptions.add(symbol));
        console.log(`Client ${socket.id} subscribed to prices:`, data.symbols);
      }
    });
    
    // Handle prediction subscriptions
    socket.on('subscribe_predictions', (data) => {
      const client = connectedClients.get(socket.id);
      if (client && data.symbol) {
        client.subscriptions.add(`prediction_${data.symbol}_${data.interval}`);
        console.log(`Client ${socket.id} subscribed to predictions:`, data.symbol, data.interval);
      }
    });
    
    // Handle unsubscribe
    socket.on('unsubscribe', (data) => {
      const client = connectedClients.get(socket.id);
      if (client) {
        if (data.type === 'prices' && data.symbols) {
          data.symbols.forEach(symbol => client.subscriptions.delete(symbol));
        } else if (data.type === 'predictions' && data.symbol) {
          client.subscriptions.delete(`prediction_${data.symbol}_${data.interval}`);
        }
      }
    });
    
    // Handle disconnect
    socket.on('disconnect', () => {
      console.log(`Client disconnected: ${socket.id}`);
      connectedClients.delete(socket.id);
    });
  });
  
  // Start price update interval
  startPriceUpdates();
};

const startPriceUpdates = () => {
  // Update prices every 30 seconds
  setInterval(async () => {
    try {
      if (connectedClients.size === 0) return;
      
      const prices = await cryptoService.getCurrentPrices();
      
      // Send updates to subscribed clients
      connectedClients.forEach((client) => {
        client.subscriptions.forEach(symbol => {
          if (prices[symbol]) {
            client.socket.emit('price_update', {
              symbol,
              price: prices[symbol].usd,
              change24h: prices[symbol].usd_24h_change,
              timestamp: new Date().toISOString()
            });
          }
        });
      });
    } catch (error) {
      console.error('Error updating prices:', error);
    }
  }, 30000);
};

const broadcastAlert = (userId, alert) => {
  // Send alert to specific user
  connectedClients.forEach((client) => {
    if (client.userId === userId) {
      client.socket.emit('alert_triggered', {
        alertId: alert.id,
        cryptoSymbol: alert.cryptoSymbol,
        alertType: alert.alertType,
        message: alert.message,
        timestamp: new Date().toISOString()
      });
    }
  });
};

const broadcastPredictionUpdate = (symbol, prediction) => {
  // Broadcast prediction update to subscribed clients
  const subscriptionKey = `prediction_${symbol}_${prediction.interval}`;
  
  connectedClients.forEach((client) => {
    if (client.subscriptions.has(subscriptionKey)) {
      client.socket.emit('prediction_update', {
        symbol,
        prediction: {
          direction: prediction.direction,
          confidence: prediction.confidence,
          probability: prediction.probability
        }
      });
    }
  });
};

module.exports = {
  initializeWebSocket,
  broadcastAlert,
  broadcastPredictionUpdate
};