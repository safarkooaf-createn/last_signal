const { query } = require('../config/database');
const { AppError } = require('../middleware/errorHandler');
const cryptoService = require('./crypto.service');
const tf = require('@tensorflow/tfjs-node');
const { 
  RSI, 
  MACD, 
  BollingerBands, 
  SMA, 
  EMA, 
  Stochastic,
  ATR,
  ADX,
  OBV,
  CCI
} = require('technicalindicators');
const ss = require('simple-statistics');

class PredictionService {
  constructor() {
    this.lstmModel = null;
    this.modelInitialized = false;
    this.scaler = { min: 0, max: 1 };
  }

  // Initialize LSTM model
  async initializeLSTMModel() {
    if (this.modelInitialized) return;
    
    try {
      // Create a sequential model
      this.lstmModel = tf.sequential({
        layers: [
          tf.layers.lstm({ 
            units: 50, 
            returnSequences: true, 
            inputShape: [10, 5] // 10 time steps, 5 features
          }),
          tf.layers.dropout({ rate: 0.2 }),
          tf.layers.lstm({ units: 50, returnSequences: false }),
          tf.layers.dropout({ rate: 0.2 }),
          tf.layers.dense({ units: 25, activation: 'relu' }),
          tf.layers.dense({ units: 3, activation: 'softmax' }) // 3 classes: up, down, sideways
        ]
      });

      // Compile the model
      this.lstmModel.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'categoricalCrossentropy',
        metrics: ['accuracy']
      });

      this.modelInitialized = true;
      console.log('LSTM model initialized successfully');
    } catch (error) {
      console.error('Failed to initialize LSTM model:', error);
      this.modelInitialized = false;
    }
  }

  // Calculate technical indicators
  calculateTechnicalIndicators(prices, volumes = null) {
    if (!prices || prices.length < 20) {
      return this.getDefaultIndicators();
    }

    try {
      const indicators = {};

      // RSI (Relative Strength Index)
      const rsiValues = RSI.calculate({
        values: prices,
        period: 14
      });
      indicators.rsi = rsiValues.length > 0 ? rsiValues[rsiValues.length - 1] : 50;

      // MACD (Moving Average Convergence Divergence)
      const macdValues = MACD.calculate({
        values: prices,
        fastPeriod: 12,
        slowPeriod: 26,
        signalPeriod: 9,
        SimpleMAOscillator: false,
        SimpleMASignal: false
      });
      if (macdValues.length > 0) {
        const lastMACD = macdValues[macdValues.length - 1];
        indicators.macd = {
          value: lastMACD.MACD || 0,
          signal: lastMACD.signal || 0,
          histogram: lastMACD.histogram || 0
        };
      } else {
        indicators.macd = { value: 0, signal: 0, histogram: 0 };
      }

      // Bollinger Bands
      const bbValues = BollingerBands.calculate({
        period: 20,
        values: prices,
        stdDev: 2
      });
      if (bbValues.length > 0) {
        const lastBB = bbValues[bbValues.length - 1];
        indicators.bollingerBands = {
          upper: lastBB.upper,
          middle: lastBB.middle,
          lower: lastBB.lower,
          pb: (prices[prices.length - 1] - lastBB.lower) / (lastBB.upper - lastBB.lower)
        };
      } else {
        const currentPrice = prices[prices.length - 1];
        indicators.bollingerBands = {
          upper: currentPrice * 1.02,
          middle: currentPrice,
          lower: currentPrice * 0.98,
          pb: 0.5
        };
      }

      // Moving Averages
      const sma20 = SMA.calculate({ period: 20, values: prices });
      const sma50 = prices.length >= 50 ? SMA.calculate({ period: 50, values: prices }) : [];
      const ema12 = EMA.calculate({ period: 12, values: prices });
      const ema26 = EMA.calculate({ period: 26, values: prices });

      indicators.sma = {
        sma20: sma20.length > 0 ? sma20[sma20.length - 1] : prices[prices.length - 1],
        sma50: sma50.length > 0 ? sma50[sma50.length - 1] : prices[prices.length - 1]
      };

      indicators.ema = {
        ema12: ema12.length > 0 ? ema12[ema12.length - 1] : prices[prices.length - 1],
        ema26: ema26.length > 0 ? ema26[ema26.length - 1] : prices[prices.length - 1]
      };

      // Stochastic Oscillator
      const stochValues = Stochastic.calculate({
        high: prices,
        low: prices.map(p => p * 0.98),
        close: prices,
        period: 14,
        signalPeriod: 3
      });
      if (stochValues.length > 0) {
        const lastStoch = stochValues[stochValues.length - 1];
        indicators.stochastic = {
          k: lastStoch.k,
          d: lastStoch.d
        };
      } else {
        indicators.stochastic = { k: 50, d: 50 };
      }

      // ATR (Average True Range) for volatility
      const atrValues = ATR.calculate({
        high: prices.map(p => p * 1.01),
        low: prices.map(p => p * 0.99),
        close: prices,
        period: 14
      });
      indicators.atr = atrValues.length > 0 ? atrValues[atrValues.length - 1] : 0;

      // Volume indicators if volume data is available
      if (volumes && volumes.length === prices.length) {
        const obvValues = OBV.calculate({
          close: prices,
          volume: volumes
        });
        indicators.obv = obvValues.length > 0 ? obvValues[obvValues.length - 1] : 0;
      }

      return indicators;
    } catch (error) {
      console.error('Error calculating technical indicators:', error);
      return this.getDefaultIndicators();
    }
  }

  getDefaultIndicators() {
    return {
      rsi: 50,
      macd: { value: 0, signal: 0, histogram: 0 },
      bollingerBands: { upper: 0, middle: 0, lower: 0, pb: 0.5 },
      sma: { sma20: 0, sma50: 0 },
      ema: { ema12: 0, ema26: 0 },
      stochastic: { k: 50, d: 50 },
      atr: 0,
      obv: 0
    };
  }

  // Generate prediction based on technical indicators
  generateBasicPrediction(indicators, currentPrice, interval) {
    let signals = [];
    let confidence = 50;

    // RSI Signal
    if (indicators.rsi < 30) {
      signals.push({ type: 'RSI', signal: 'buy', strength: (30 - indicators.rsi) / 30 });
    } else if (indicators.rsi > 70) {
      signals.push({ type: 'RSI', signal: 'sell', strength: (indicators.rsi - 70) / 30 });
    } else {
      signals.push({ type: 'RSI', signal: 'neutral', strength: 0 });
    }

    // MACD Signal
    if (indicators.macd.histogram > 0 && indicators.macd.value > indicators.macd.signal) {
      signals.push({ type: 'MACD', signal: 'buy', strength: Math.min(Math.abs(indicators.macd.histogram) / 100, 1) });
    } else if (indicators.macd.histogram < 0 && indicators.macd.value < indicators.macd.signal) {
      signals.push({ type: 'MACD', signal: 'sell', strength: Math.min(Math.abs(indicators.macd.histogram) / 100, 1) });
    } else {
      signals.push({ type: 'MACD', signal: 'neutral', strength: 0 });
    }

    // Bollinger Bands Signal
    if (indicators.bollingerBands.pb < 0.2) {
      signals.push({ type: 'BB', signal: 'buy', strength: (0.2 - indicators.bollingerBands.pb) / 0.2 });
    } else if (indicators.bollingerBands.pb > 0.8) {
      signals.push({ type: 'BB', signal: 'sell', strength: (indicators.bollingerBands.pb - 0.8) / 0.2 });
    } else {
      signals.push({ type: 'BB', signal: 'neutral', strength: 0 });
    }

    // Moving Average Signal
    if (currentPrice > indicators.sma.sma20 && indicators.ema.ema12 > indicators.ema.ema26) {
      signals.push({ type: 'MA', signal: 'buy', strength: 0.7 });
    } else if (currentPrice < indicators.sma.sma20 && indicators.ema.ema12 < indicators.ema.ema26) {
      signals.push({ type: 'MA', signal: 'sell', strength: 0.7 });
    } else {
      signals.push({ type: 'MA', signal: 'neutral', strength: 0 });
    }

    // Stochastic Signal
    if (indicators.stochastic.k < 20) {
      signals.push({ type: 'Stoch', signal: 'buy', strength: (20 - indicators.stochastic.k) / 20 });
    } else if (indicators.stochastic.k > 80) {
      signals.push({ type: 'Stoch', signal: 'sell', strength: (indicators.stochastic.k - 80) / 20 });
    } else {
      signals.push({ type: 'Stoch', signal: 'neutral', strength: 0 });
    }

    // Calculate overall direction and confidence
    let buySignals = signals.filter(s => s.signal === 'buy');
    let sellSignals = signals.filter(s => s.signal === 'sell');
    
    let buyStrength = buySignals.reduce((sum, s) => sum + s.strength, 0);
    let sellStrength = sellSignals.reduce((sum, s) => sum + s.strength, 0);
    
    let direction = 'sideways';
    if (buyStrength > sellStrength * 1.2) {
      direction = 'up';
      confidence = Math.min(50 + buyStrength * 15, 85);
    } else if (sellStrength > buyStrength * 1.2) {
      direction = 'down';
      confidence = Math.min(50 + sellStrength * 15, 85);
    } else {
      confidence = 50 + Math.abs(buyStrength - sellStrength) * 5;
    }

    // Adjust confidence based on interval
    if (interval === '5min') {
      confidence *= 0.9; // Lower confidence for shorter intervals
    } else if (interval === '30min') {
      confidence *= 1.1; // Higher confidence for longer intervals
    }

    confidence = Math.min(Math.max(confidence, 20), 90);

    return {
      direction,
      confidence,
      probability: confidence / 100,
      signals,
      buyStrength,
      sellStrength
    };
  }

  // Generate advanced prediction using LSTM
  async generateAdvancedPrediction(historicalData, indicators, interval) {
    if (!this.modelInitialized) {
      await this.initializeLSTMModel();
    }

    if (!this.lstmModel || historicalData.length < 10) {
      // Fallback to enhanced basic prediction
      return this.generateEnhancedBasicPrediction(indicators, interval);
    }

    try {
      // Prepare features for LSTM
      const features = this.prepareFeaturesForLSTM(historicalData, indicators);
      
      // Make prediction
      const prediction = await this.lstmModel.predict(features).array();
      
      // Interpret prediction [up_prob, down_prob, sideways_prob]
      const [upProb, downProb, sidewaysProb] = prediction[0];
      
      let direction = 'sideways';
      let confidence = sidewaysProb * 100;
      
      if (upProb > downProb && upProb > sidewaysProb) {
        direction = 'up';
        confidence = upProb * 100;
      } else if (downProb > upProb && downProb > sidewaysProb) {
        direction = 'down';
        confidence = downProb * 100;
      }

      // Adjust for interval
      const intervalMultiplier = {
        '5min': 0.85,
        '10min': 1.0,
        '30min': 1.15
      }[interval] || 1.0;

      confidence = Math.min(Math.max(confidence * intervalMultiplier, 30), 95);

      return {
        direction,
        confidence,
        probability: confidence / 100,
        modelType: 'LSTM',
        probabilities: {
          up: upProb,
          down: downProb,
          sideways: sidewaysProb
        }
      };
    } catch (error) {
      console.error('LSTM prediction error:', error);
      return this.generateEnhancedBasicPrediction(indicators, interval);
    }
  }

  // Enhanced basic prediction (fallback for LSTM)
  generateEnhancedBasicPrediction(indicators, interval) {
    const basicPred = this.generateBasicPrediction(indicators, 0, interval);
    
    // Add some ML-like enhancements
    let confidence = basicPred.confidence;
    
    // Boost confidence if multiple indicators agree
    if (basicPred.signals.filter(s => s.signal === basicPred.direction || 
        (s.signal === 'buy' && basicPred.direction === 'up') || 
        (s.signal === 'sell' && basicPred.direction === 'down')).length >= 3) {
      confidence = Math.min(confidence * 1.2, 90);
    }

    return {
      ...basicPred,
      confidence,
      probability: confidence / 100,
      modelType: 'Enhanced_TA'
    };
  }

  // Prepare features for LSTM model
  prepareFeaturesForLSTM(historicalData, indicators) {
    // Take last 10 data points and create features
    const data = historicalData.slice(-10);
    
    // Normalize features
    const features = data.map(d => [
      this.normalize(d.price, this.scaler.min, this.scaler.max),
      this.normalize(d.volume || 0, 0, 1000000),
      this.normalize(indicators.rsi, 0, 100),
      this.normalize(indicators.macd.histogram, -100, 100),
      this.normalize(indicators.bollingerBands.pb, 0, 1)
    ]);

    // Pad if necessary
    while (features.length < 10) {
      features.unshift([0.5, 0.5, 0.5, 0.5, 0.5]);
    }

    return tf.tensor3d([features]);
  }

  normalize(value, min, max) {
    if (max === min) return 0.5;
    return (value - min) / (max - min);
  }

  // Main prediction methods
  async getPrediction(symbol, interval, useAdvanced = true) {
    // Get historical data for analysis
    const historicalData = await cryptoService.getHistoricalData(symbol, 7);
    
    if (!historicalData || historicalData.length === 0) {
      return this.getDefaultPrediction(symbol, interval, useAdvanced);
    }
    
    const currentPrice = historicalData[historicalData.length - 1]?.price || 0;
    const prices = historicalData.map(d => d.price);
    const volumes = historicalData.map(d => d.volume || 0);
    
    // Calculate technical indicators
    const technicalIndicators = this.calculateTechnicalIndicators(prices, volumes);
    
    // Generate prediction
    let prediction;
    if (useAdvanced) {
      prediction = await this.generateAdvancedPrediction(historicalData, technicalIndicators, interval);
    } else {
      prediction = this.generateBasicPrediction(technicalIndicators, currentPrice, interval);
    }
    
    return {
      symbol,
      interval,
      direction: prediction.direction,
      confidence: prediction.confidence,
      probability: prediction.probability,
      currentPrice,
      modelType: useAdvanced ? (prediction.modelType || 'advanced_ml') : 'basic_ta',
      technicalIndicators,
      signals: prediction.signals,
      probabilities: prediction.probabilities
    };
  }

  getDefaultPrediction(symbol, interval, useAdvanced) {
    return {
      symbol,
      interval,
      direction: 'sideways',
      confidence: 50,
      probability: 0.5,
      currentPrice: 0,
      modelType: useAdvanced ? 'advanced_ml' : 'basic_ta',
      technicalIndicators: this.getDefaultIndicators()
    };
  }

  // Batch predictions for multiple intervals
  async getMultiIntervalPredictions(symbol, useAdvanced = true) {
    const intervals = ['5min', '10min', '30min'];
    const predictions = {};
    
    for (const interval of intervals) {
      predictions[interval] = await this.getPrediction(symbol, interval, useAdvanced);
    }
    
    return predictions;
  }

  // Database operations
  async savePrediction(data) {
    const result = await query(
      `INSERT INTO prediction_history 
       (crypto_symbol, prediction_time, prediction_interval, predicted_direction,
        confidence_score, probability_score, price_at_prediction, model_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [
        data.cryptoSymbol,
        new Date(),
        data.interval,
        data.direction,
        data.confidence,
        data.probability,
        data.currentPrice,
        data.modelType
      ]
    );
    
    return result.rows[0].id;
  }

  async getHistory(userId, symbol, days, limit) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    let queryStr = `
      SELECT * FROM prediction_history 
      WHERE prediction_time >= $1
    `;
    
    const params = [startDate];
    
    if (symbol) {
      queryStr += ' AND crypto_symbol = $2';
      params.push(symbol);
    }
    
    queryStr += ` ORDER BY prediction_time DESC LIMIT ${limit}`;
    
    const result = await query(queryStr, params);
    
    return result.rows.map(row => ({
      id: row.id,
      cryptoSymbol: row.crypto_symbol,
      predictionTime: row.prediction_time,
      predictionInterval: row.prediction_interval,
      predictedDirection: row.predicted_direction,
      confidenceScore: parseFloat(row.confidence_score),
      probabilityScore: parseFloat(row.probability_score),
      priceAtPrediction: parseFloat(row.price_at_prediction),
      priceAfterInterval: row.price_after_interval ? parseFloat(row.price_after_interval) : null,
      actualDirection: row.actual_direction,
      predictionAccuracy: row.prediction_accuracy,
      modelType: row.model_type
    }));
  }

  async getAccuracyStats(userId, symbol, days) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    let queryStr = `
      SELECT 
        COUNT(*) as total_predictions,
        COUNT(*) FILTER (WHERE prediction_accuracy = TRUE) as accurate_predictions,
        AVG(confidence_score) as avg_confidence,
        AVG(CASE WHEN prediction_accuracy = TRUE THEN confidence_score ELSE NULL END) as avg_accurate_confidence
      FROM prediction_history 
      WHERE prediction_time >= $1 AND prediction_accuracy IS NOT NULL
    `;
    
    const params = [startDate];
    
    if (symbol) {
      queryStr += ' AND crypto_symbol = $2';
      params.push(symbol);
    }
    
    const result = await query(queryStr, params);
    
    const stats = result.rows[0];
    const totalPredictions = parseInt(stats.total_predictions) || 0;
    const accuratePredictions = parseInt(stats.accurate_predictions) || 0;
    const accuracyPercentage = totalPredictions > 0 
      ? (accuratePredictions / totalPredictions) * 100 
      : 0;
    
    return {
      totalPredictions,
      accuratePredictions,
      accuracyPercentage,
      avgConfidence: parseFloat(stats.avg_confidence) || 0,
      avgAccurateConfidence: parseFloat(stats.avg_accurate_confidence) || 0
    };
  }

  async updateAccuracy(predictionId, actualPrice, actualDirection) {
    const result = await query(
      `UPDATE prediction_history 
       SET price_after_interval = $1, actual_direction = $2, 
           prediction_accuracy = (predicted_direction = $2)
       WHERE id = $3`,
      [actualPrice, actualDirection, predictionId]
    );
    
    if (result.rowCount === 0) {
      throw new AppError('Prediction not found', 404, 'NOT_FOUND');
    }
    
    return true;
  }
}

module.exports = new PredictionService();