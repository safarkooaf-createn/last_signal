const { query, getClient } = require('../config/database');
const { AppError } = require('../middleware/errorHandler');
const cryptoService = require('./crypto.service');

class PortfolioService {
  async getDefaultPortfolioId(userId) {
    // For simplicity, using the default portfolio for now
    const result = await query(
      "SELECT id FROM portfolios WHERE name = 'Default Portfolio' LIMIT 1"
    );
    
    if (result.rows.length === 0) {
      // Create default portfolio if it doesn't exist
      const newPortfolio = await query(
        "INSERT INTO portfolios (name, description) VALUES ($1, $2) RETURNING id",
        ['Default Portfolio', 'Default portfolio for tracking']
      );
      return newPortfolio.rows[0].id;
    }
    
    return result.rows[0].id;
  }

  async getHoldings(userId) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    
    const result = await query(
      `SELECT * FROM portfolio_holdings 
       WHERE portfolio_id = $1 
       ORDER BY crypto_symbol`,
      [portfolioId]
    );
    
    // Get current prices
    const prices = await cryptoService.getCurrentPrices();
    
    // Calculate current values
    const holdings = result.rows.map(holding => {
      const currentPrice = prices[holding.crypto_symbol]?.usd || 0;
      const currentValue = parseFloat(holding.quantity) * currentPrice;
      const profitLoss = currentValue - parseFloat(holding.total_invested);
      const profitLossPercentage = holding.total_invested > 0 
        ? (profitLoss / parseFloat(holding.total_invested)) * 100 
        : 0;
      
      return {
        id: holding.id,
        cryptoSymbol: holding.crypto_symbol,
        cryptoName: holding.crypto_name,
        quantity: parseFloat(holding.quantity),
        averageBuyPrice: parseFloat(holding.average_buy_price),
        totalInvested: parseFloat(holding.total_invested),
        currentPrice,
        currentValue,
        profitLoss,
        profitLossPercentage
      };
    });
    
    return holdings;
  }

  async getPortfolioSummary(userId) {
    const holdings = await this.getHoldings(userId);
    
    const totalInvested = holdings.reduce((sum, h) => sum + h.totalInvested, 0);
    const currentValue = holdings.reduce((sum, h) => sum + h.currentValue, 0);
    const totalProfitLoss = currentValue - totalInvested;
    const totalProfitLossPercentage = totalInvested > 0 
      ? (totalProfitLoss / totalInvested) * 100 
      : 0;
    
    return {
      totalInvested,
      currentValue,
      totalProfitLoss,
      totalProfitLossPercentage
    };
  }

  async addHolding(userId, cryptoSymbol, cryptoName, quantity, buyPrice) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    const totalInvested = quantity * buyPrice;
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if holding exists
      const existing = await client.query(
        `SELECT id, quantity, total_invested 
         FROM portfolio_holdings 
         WHERE portfolio_id = $1 AND crypto_symbol = $2`,
        [portfolioId, cryptoSymbol]
      );
      
      let isNew = false;
      
      if (existing.rows.length > 0) {
        // Update existing holding
        const currentQuantity = parseFloat(existing.rows[0].quantity);
        const currentInvested = parseFloat(existing.rows[0].total_invested);
        
        const newQuantity = currentQuantity + quantity;
        const newTotalInvested = currentInvested + totalInvested;
        const newAvgPrice = newTotalInvested / newQuantity;
        
        await client.query(
          `UPDATE portfolio_holdings 
           SET quantity = $1, average_buy_price = $2, total_invested = $3, 
               updated_at = CURRENT_TIMESTAMP
           WHERE id = $4`,
          [newQuantity, newAvgPrice, newTotalInvested, existing.rows[0].id]
        );
      } else {
        // Insert new holding
        await client.query(
          `INSERT INTO portfolio_holdings 
           (portfolio_id, crypto_symbol, crypto_name, quantity, average_buy_price, total_invested)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [portfolioId, cryptoSymbol, cryptoName, quantity, buyPrice, totalInvested]
        );
        isNew = true;
      }
      
      await client.query('COMMIT');
      return { success: true, isNew };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async removeHolding(userId, cryptoSymbol) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    
    const result = await query(
      `DELETE FROM portfolio_holdings 
       WHERE portfolio_id = $1 AND crypto_symbol = $2`,
      [portfolioId, cryptoSymbol]
    );
    
    if (result.rowCount === 0) {
      throw new AppError('Holding not found', 404, 'NOT_FOUND');
    }
    
    return true;
  }

  async getPerformanceHistory(userId, days = 30) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const result = await query(
      `SELECT * FROM performance_analytics 
       WHERE portfolio_id = $1 AND date_calculated >= $2
       ORDER BY date_calculated DESC`,
      [portfolioId, startDate]
    );
    
    return result.rows.map(row => ({
      date: row.date_calculated,
      totalValue: parseFloat(row.total_value),
      dailyReturn: parseFloat(row.daily_return),
      cumulativeReturn: parseFloat(row.cumulative_return),
      accuracyRate: parseFloat(row.accuracy_rate),
      successfulPredictions: row.successful_predictions,
      totalPredictions: row.total_predictions
    }));
  }

  async updateHolding(userId, holdingId, quantity, sellPrice) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Get current holding
      const existing = await client.query(
        `SELECT * FROM portfolio_holdings 
         WHERE id = $1 AND portfolio_id = $2`,
        [holdingId, portfolioId]
      );
      
      if (existing.rows.length === 0) {
        throw new AppError('Holding not found', 404, 'NOT_FOUND');
      }
      
      const currentHolding = existing.rows[0];
      const currentQuantity = parseFloat(currentHolding.quantity);
      
      if (quantity > currentQuantity) {
        throw new AppError('Cannot sell more than current quantity', 400, 'INVALID_QUANTITY');
      }
      
      const remainingQuantity = currentQuantity - quantity;
      
      if (remainingQuantity === 0) {
        // Delete holding if all sold
        await client.query(
          `DELETE FROM portfolio_holdings WHERE id = $1`,
          [holdingId]
        );
      } else {
        // Update holding with remaining quantity
        const soldValue = quantity * parseFloat(currentHolding.average_buy_price);
        const remainingInvested = parseFloat(currentHolding.total_invested) - soldValue;
        
        await client.query(
          `UPDATE portfolio_holdings 
           SET quantity = $1, total_invested = $2, 
               updated_at = CURRENT_TIMESTAMP
           WHERE id = $3`,
          [remainingQuantity, remainingInvested, holdingId]
        );
      }
      
      // Record transaction
      await client.query(
        `INSERT INTO portfolio_transactions 
         (portfolio_id, crypto_symbol, transaction_type, quantity, price, total_amount)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [portfolioId, currentHolding.crypto_symbol, 'SELL', quantity, sellPrice, quantity * sellPrice]
      );
      
      await client.query('COMMIT');
      return { success: true, remainingQuantity };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getTransactions(userId, days = 30) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const result = await query(
      `SELECT * FROM portfolio_transactions 
       WHERE portfolio_id = $1 AND transaction_date >= $2
       ORDER BY transaction_date DESC`,
      [portfolioId, startDate]
    );
    
    return result.rows.map(row => ({
      id: row.id,
      cryptoSymbol: row.crypto_symbol,
      transactionType: row.transaction_type,
      quantity: parseFloat(row.quantity),
      price: parseFloat(row.price),
      totalAmount: parseFloat(row.total_amount),
      transactionDate: row.transaction_date
    }));
  }

  async calculatePerformanceMetrics(userId) {
    const holdings = await this.getHoldings(userId);
    const portfolioSummary = await this.getPortfolioSummary(userId);
    
    // Calculate diversification
    const totalValue = portfolioSummary.currentValue;
    const diversification = holdings.map(h => ({
      symbol: h.cryptoSymbol,
      percentage: totalValue > 0 ? (h.currentValue / totalValue) * 100 : 0
    }));
    
    // Find best and worst performers
    const sortedByPerformance = [...holdings].sort((a, b) => 
      b.profitLossPercentage - a.profitLossPercentage
    );
    
    const bestPerformer = sortedByPerformance[0] || null;
    const worstPerformer = sortedByPerformance[sortedByPerformance.length - 1] || null;
    
    // Calculate volatility (simplified)
    const avgVolatility = holdings.reduce((sum, h) => sum + Math.abs(h.profitLossPercentage), 0) / 
      (holdings.length || 1);
    
    return {
      summary: portfolioSummary,
      diversification,
      bestPerformer: bestPerformer ? {
        symbol: bestPerformer.cryptoSymbol,
        profitLossPercentage: bestPerformer.profitLossPercentage
      } : null,
      worstPerformer: worstPerformer ? {
        symbol: worstPerformer.cryptoSymbol,
        profitLossPercentage: worstPerformer.profitLossPercentage
      } : null,
      averageVolatility: avgVolatility,
      numberOfHoldings: holdings.length
    };
  }

  async getPortfolioById(portfolioId) {
    const result = await query(
      `SELECT * FROM portfolios WHERE id = $1`,
      [portfolioId]
    );
    
    if (result.rows.length === 0) {
      throw new AppError('Portfolio not found', 404, 'NOT_FOUND');
    }
    
    return result.rows[0];
  }

  async createPortfolio(userId, name, description) {
    const result = await query(
      `INSERT INTO portfolios (user_id, name, description) 
       VALUES ($1, $2, $3) RETURNING *`,
      [userId, name, description]
    );
    
    return result.rows[0];
  }

  async updatePortfolio(portfolioId, name, description) {
    const result = await query(
      `UPDATE portfolios 
       SET name = $1, description = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 RETURNING *`,
      [name, description, portfolioId]
    );
    
    if (result.rows.length === 0) {
      throw new AppError('Portfolio not found', 404, 'NOT_FOUND');
    }
    
    return result.rows[0];
  }

  async deletePortfolio(portfolioId) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Delete related holdings
      await client.query(
        `DELETE FROM portfolio_holdings WHERE portfolio_id = $1`,
        [portfolioId]
      );
      
      // Delete related transactions
      await client.query(
        `DELETE FROM portfolio_transactions WHERE portfolio_id = $1`,
        [portfolioId]
      );
      
      // Delete related performance analytics
      await client.query(
        `DELETE FROM performance_analytics WHERE portfolio_id = $1`,
        [portfolioId]
      );
      
      // Delete portfolio
      const result = await client.query(
        `DELETE FROM portfolios WHERE id = $1`,
        [portfolioId]
      );
      
      if (result.rowCount === 0) {
        throw new AppError('Portfolio not found', 404, 'NOT_FOUND');
      }
      
      await client.query('COMMIT');
      return { success: true };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getUserPortfolios(userId) {
    const result = await query(
      `SELECT * FROM portfolios WHERE user_id = $1 ORDER BY created_at DESC`,
      [userId]
    );
    
    return result.rows;
  }

  async getHoldingDetails(userId, holdingId) {
    const portfolioId = await this.getDefaultPortfolioId(userId);
    
    const result = await query(
      `SELECT * FROM portfolio_holdings 
       WHERE id = $1 AND portfolio_id = $2`,
      [holdingId, portfolioId]
    );
    
    if (result.rows.length === 0) {
      throw new AppError('Holding not found', 404, 'NOT_FOUND');
    }
    
    const holding = result.rows[0];
    const prices = await cryptoService.getCurrentPrices();
    const currentPrice = prices[holding.crypto_symbol]?.usd || 0;
    const currentValue = parseFloat(holding.quantity) * currentPrice;
    const profitLoss = currentValue - parseFloat(holding.total_invested);
    const profitLossPercentage = holding.total_invested > 0 
      ? (profitLoss / parseFloat(holding.total_invested)) * 100 
      : 0;
    
    return {
      id: holding.id,
      cryptoSymbol: holding.crypto_symbol,
      cryptoName: holding.crypto_name,
      quantity: parseFloat(holding.quantity),
      averageBuyPrice: parseFloat(holding.average_buy_price),
      totalInvested: parseFloat(holding.total_invested),
      currentPrice,
      currentValue,
      profitLoss,
      profitLossPercentage,
      createdAt: holding.created_at,
      updatedAt: holding.updated_at
    };
  }
}

module.exports = new PortfolioService();