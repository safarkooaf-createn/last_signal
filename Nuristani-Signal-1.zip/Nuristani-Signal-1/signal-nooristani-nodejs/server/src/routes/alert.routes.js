const express = require('express');
const router = express.Router();
const { asyncHandler, AppError } = require('../middleware/errorHandler');
const { authMiddleware } = require('../middleware/auth');
const alertService = require('../services/alert.service');

// Get user's alerts
router.get('/', authMiddleware, asyncHandler(async (req, res) => {
  const alerts = await alertService.getUserAlerts(req.user.id);
  
  res.json({ alerts });
}));

// Create new alert
router.post('/', authMiddleware, asyncHandler(async (req, res) => {
  const {
    cryptoSymbol,
    alertType,
    alertCondition,
    emailEnabled,
    smsEnabled
  } = req.body;
  
  if (!cryptoSymbol || !alertType || !alertCondition) {
    throw new AppError('Missing required fields', 400, 'VALIDATION_ERROR');
  }
  
  const alertId = await alertService.createAlert({
    userId: req.user.id,
    cryptoSymbol,
    alertType,
    alertCondition,
    emailEnabled,
    smsEnabled
  });
  
  res.status(201).json({
    success: true,
    alertId
  });
}));

// Update alert
router.put('/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  await alertService.updateAlert(req.user.id, id, updates);
  
  res.json({
    success: true,
    message: 'Alert updated successfully'
  });
}));

// Delete alert
router.delete('/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  
  await alertService.deleteAlert(req.user.id, id);
  
  res.json({
    success: true,
    message: 'Alert deleted successfully'
  });
}));

// Get triggered alerts history
router.get('/history', authMiddleware, asyncHandler(async (req, res) => {
  const { days = 7 } = req.query;
  
  const history = await alertService.getAlertHistory(req.user.id, parseInt(days));
  
  res.json({ history });
}));

module.exports = router;