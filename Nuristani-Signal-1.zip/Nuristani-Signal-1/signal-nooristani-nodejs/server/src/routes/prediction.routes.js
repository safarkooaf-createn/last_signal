const express = require('express');
const router = express.Router();
const { asyncHandler, AppError } = require('../middleware/errorHandler');
const { authMiddleware, optionalAuth } = require('../middleware/auth');
const predictionService = require('../services/prediction.service');

// Get prediction for a cryptocurrency
router.get('/:symbol', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol } = req.params;
  const { interval = '5min', advanced = 'true' } = req.query;
  
  const useAdvanced = advanced === 'true';
  const prediction = await predictionService.getPrediction(symbol, interval, useAdvanced);
  
  res.json({ prediction });
}));

// Get multi-interval predictions for a cryptocurrency
router.get('/:symbol/multi', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol } = req.params;
  const { advanced = 'true' } = req.query;
  
  const useAdvanced = advanced === 'true';
  const predictions = await predictionService.getMultiIntervalPredictions(symbol, useAdvanced);
  
  res.json({ predictions });
}));

// Get basic technical analysis predictions
router.post('/basic', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol, interval = '5min' } = req.body;
  
  if (!symbol) {
    throw new AppError('Symbol is required', 400, 'VALIDATION_ERROR');
  }
  
  const prediction = await predictionService.getPrediction(symbol, interval, false);
  
  res.json({ prediction });
}));

// Get advanced ML-based predictions
router.post('/advanced', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol, interval = '5min' } = req.body;
  
  if (!symbol) {
    throw new AppError('Symbol is required', 400, 'VALIDATION_ERROR');
  }
  
  const prediction = await predictionService.getPrediction(symbol, interval, true);
  
  res.json({ prediction });
}))

// Save prediction to history (requires auth)
router.post('/save', authMiddleware, asyncHandler(async (req, res) => {
  const {
    cryptoSymbol,
    interval,
    direction,
    confidence,
    probability,
    currentPrice,
    modelType
  } = req.body;
  
  const predictionId = await predictionService.savePrediction({
    cryptoSymbol,
    interval,
    direction,
    confidence,
    probability,
    currentPrice,
    modelType,
    userId: req.user.id
  });
  
  res.status(201).json({
    success: true,
    predictionId
  });
}));

// Get prediction history
router.get('/history/list', authMiddleware, asyncHandler(async (req, res) => {
  const { symbol, days = 30, limit = 100 } = req.query;
  
  const predictions = await predictionService.getHistory(
    req.user.id,
    symbol,
    parseInt(days),
    parseInt(limit)
  );
  
  const statistics = await predictionService.getAccuracyStats(
    req.user.id,
    symbol,
    parseInt(days)
  );
  
  res.json({
    predictions,
    statistics
  });
}));

// Update prediction accuracy (internal endpoint)
router.put('/:id/accuracy', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { actualPrice, actualDirection } = req.body;
  
  await predictionService.updateAccuracy(id, actualPrice, actualDirection);
  
  res.json({
    success: true,
    message: 'Prediction accuracy updated'
  });
}));

module.exports = router;