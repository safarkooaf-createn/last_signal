const express = require('express');
const router = express.Router();
const { asyncHandler, AppError } = require('../middleware/errorHandler');
const { authMiddleware } = require('../middleware/auth');
const portfolioService = require('../services/portfolio.service');

// Get user's portfolio holdings
router.get('/', authMiddleware, asyncHandler(async (req, res) => {
  const holdings = await portfolioService.getHoldings(req.user.id);
  const summary = await portfolioService.getPortfolioSummary(req.user.id);
  
  res.json({
    holdings,
    summary
  });
}));

// Add or update portfolio holding
router.post('/add', authMiddleware, asyncHandler(async (req, res) => {
  const { cryptoSymbol, cryptoName, quantity, buyPrice } = req.body;
  
  if (!cryptoSymbol || !cryptoName || !quantity || !buyPrice) {
    throw new AppError('Missing required fields', 400, 'VALIDATION_ERROR');
  }
  
  const result = await portfolioService.addHolding(
    req.user.id,
    cryptoSymbol,
    cryptoName,
    quantity,
    buyPrice
  );
  
  res.json({
    success: true,
    message: result.isNew ? 'Holding added successfully' : 'Holding updated successfully'
  });
}));

// Remove a holding from portfolio
router.delete('/:symbol', authMiddleware, asyncHandler(async (req, res) => {
  const { symbol } = req.params;
  
  await portfolioService.removeHolding(req.user.id, symbol);
  
  res.json({
    success: true,
    message: 'Holding removed successfully'
  });
}));

// Get portfolio performance
router.get('/performance', authMiddleware, asyncHandler(async (req, res) => {
  const { days = 30 } = req.query;
  
  const performance = await portfolioService.getPerformanceHistory(
    req.user.id,
    parseInt(days)
  );
  
  res.json({ performance });
}));

// Get portfolio performance metrics
router.get('/metrics', authMiddleware, asyncHandler(async (req, res) => {
  const metrics = await portfolioService.calculatePerformanceMetrics(req.user.id);
  
  res.json({ metrics });
}));

// Update a holding (sell partial or full)
router.put('/holdings/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { quantity, sellPrice } = req.body;
  
  if (!quantity || !sellPrice) {
    throw new AppError('Missing required fields', 400, 'VALIDATION_ERROR');
  }
  
  const result = await portfolioService.updateHolding(
    req.user.id,
    parseInt(id),
    quantity,
    sellPrice
  );
  
  res.json({
    success: true,
    message: result.remainingQuantity === 0 ? 'Holding sold completely' : 'Holding partially sold',
    remainingQuantity: result.remainingQuantity
  });
}));

// Get transaction history
router.get('/transactions', authMiddleware, asyncHandler(async (req, res) => {
  const { days = 30 } = req.query;
  
  const transactions = await portfolioService.getTransactions(
    req.user.id,
    parseInt(days)
  );
  
  res.json({ transactions });
}));

// Get specific holding details
router.get('/holdings/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  
  const holding = await portfolioService.getHoldingDetails(
    req.user.id,
    parseInt(id)
  );
  
  res.json({ holding });
}));

// Get portfolio history
router.get('/history', authMiddleware, asyncHandler(async (req, res) => {
  const { days = 30 } = req.query;
  
  const history = await portfolioService.getPerformanceHistory(
    req.user.id,
    parseInt(days)
  );
  
  res.json({ history });
}));

// Create new portfolio
router.post('/create', authMiddleware, asyncHandler(async (req, res) => {
  const { name, description } = req.body;
  
  if (!name) {
    throw new AppError('Portfolio name is required', 400, 'VALIDATION_ERROR');
  }
  
  const portfolio = await portfolioService.createPortfolio(
    req.user.id,
    name,
    description || ''
  );
  
  res.status(201).json({
    success: true,
    portfolio
  });
}));

// Get all user portfolios
router.get('/list', authMiddleware, asyncHandler(async (req, res) => {
  const portfolios = await portfolioService.getUserPortfolios(req.user.id);
  
  res.json({ portfolios });
}));

// Update portfolio details
router.put('/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, description } = req.body;
  
  if (!name) {
    throw new AppError('Portfolio name is required', 400, 'VALIDATION_ERROR');
  }
  
  const portfolio = await portfolioService.updatePortfolio(
    parseInt(id),
    name,
    description
  );
  
  res.json({
    success: true,
    portfolio
  });
}));

// Delete portfolio
router.delete('/:id', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  
  await portfolioService.deletePortfolio(parseInt(id));
  
  res.json({
    success: true,
    message: 'Portfolio deleted successfully'
  });
}));

module.exports = router;