const express = require('express');
const router = express.Router();
const authService = require('../services/auth.service');
const { asyncHandler, AppError } = require('../middleware/errorHandler');
const { authMiddleware } = require('../middleware/auth');
const { validateRegister, validateLogin } = require('../utils/validators');

// Register new user
router.post('/register', asyncHandler(async (req, res) => {
  const { email, password, fullName, preferredLanguage = 'en' } = req.body;
  
  // Validate input
  const validation = validateRegister(req.body);
  if (!validation.valid) {
    throw new AppError(validation.message, 400, 'VALIDATION_ERROR');
  }
  
  // Register user using auth service
  const user = await authService.register({
    email,
    password,
    fullName,
    preferredLanguage
  });
  
  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName
    }
  });
}));

// Login
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  
  // Validate input
  const validation = validateLogin(req.body);
  if (!validation.valid) {
    throw new AppError(validation.message, 400, 'VALIDATION_ERROR');
  }
  
  // Login using auth service
  const result = await authService.login(email, password);
  
  res.json({
    success: true,
    accessToken: result.accessToken,
    refreshToken: result.refreshToken,
    user: result.user
  });
}));

// Refresh access token
router.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  
  if (!refreshToken) {
    throw new AppError('Refresh token required', 400, 'VALIDATION_ERROR');
  }
  
  // Refresh token using auth service
  const result = await authService.refreshAccessToken(refreshToken);
  
  res.json({
    success: true,
    accessToken: result.accessToken,
    refreshToken: result.refreshToken,
    user: result.user
  });
}));

// Get current user profile
router.get('/me', authMiddleware, asyncHandler(async (req, res) => {
  const user = await authService.getUserById(req.user.id);
  
  res.json({
    success: true,
    user
  });
}));

// Alias for /me endpoint - Get current authenticated user
router.get('/user', authMiddleware, asyncHandler(async (req, res) => {
  const user = await authService.getUserById(req.user.id);
  
  res.json({
    success: true,
    user
  });
}));

// Update user preferences
router.patch('/preferences', authMiddleware, asyncHandler(async (req, res) => {
  const preferences = await authService.updateUserPreferences(req.user.id, req.body);
  
  if (!preferences) {
    throw new AppError('No valid preferences to update', 400, 'VALIDATION_ERROR');
  }
  
  res.json({
    success: true,
    message: 'Preferences updated successfully',
    preferences
  });
}));

// Change password
router.post('/change-password', authMiddleware, asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  
  if (!currentPassword || !newPassword) {
    throw new AppError('Current and new passwords are required', 400, 'VALIDATION_ERROR');
  }
  
  if (newPassword.length < 8) {
    throw new AppError('New password must be at least 8 characters long', 400, 'VALIDATION_ERROR');
  }
  
  await authService.changePassword(req.user.id, currentPassword, newPassword);
  
  res.json({
    success: true,
    message: 'Password changed successfully. Please login again with your new password.'
  });
}));

// Logout
router.post('/logout', authMiddleware, asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  
  // Logout using auth service (will invalidate sessions)
  await authService.logout(req.user.id, refreshToken);
  
  res.json({
    success: true,
    message: 'Logged out successfully'
  });
}));

// Logout from all devices
router.post('/logout-all', authMiddleware, asyncHandler(async (req, res) => {
  // Logout from all devices (invalidate all sessions)
  await authService.logout(req.user.id);
  
  res.json({
    success: true,
    message: 'Logged out from all devices successfully'
  });
}));

module.exports = router;