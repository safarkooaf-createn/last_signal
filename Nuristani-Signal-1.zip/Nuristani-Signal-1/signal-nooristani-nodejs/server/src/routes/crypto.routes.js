const express = require('express');
const router = express.Router();
const { asyncHandler } = require('../middleware/errorHandler');
const { optionalAuth } = require('../middleware/auth');
const cryptoService = require('../services/crypto.service');

// Get list of supported cryptocurrencies
router.get('/list', asyncHandler(async (req, res) => {
  const cryptocurrencies = [
    { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin' },
    { id: 'ethereum', symbol: 'ETH', name: 'Ethereum' },
    { id: 'binancecoin', symbol: 'BNB', name: 'Binance Coin' },
    { id: 'cardano', symbol: 'ADA', name: 'Cardano' },
    { id: 'solana', symbol: 'SOL', name: 'Solana' },
    { id: 'polkadot', symbol: 'DOT', name: 'Polkadot' },
    { id: 'chainlink', symbol: 'LINK', name: 'Chainlink' },
    { id: 'litecoin', symbol: 'LTC', name: 'Litecoin' },
    { id: 'matic-network', symbol: 'MATIC', name: 'Polygon' },
    { id: 'avalanche-2', symbol: 'AVAX', name: 'Avalanche' }
  ];
  
  res.json({ cryptocurrencies });
}));

// Get current prices for all cryptocurrencies
router.get('/prices', optionalAuth, asyncHandler(async (req, res) => {
  const { ids } = req.query;
  
  let prices;
  if (ids) {
    // Get prices for specific coins
    const coinIds = ids.split(',').map(id => id.trim());
    prices = await cryptoService.getPrices(coinIds);
  } else {
    // Get prices for default supported coins
    prices = await cryptoService.getCurrentPrices();
  }
  
  res.json({ 
    success: true,
    data: prices 
  });
}));

// Get trending cryptocurrencies - MUST be before :id routes
router.get('/trending', optionalAuth, asyncHandler(async (req, res) => {
  const trending = await cryptoService.getTrending();
  
  res.json({ 
    success: true,
    data: trending 
  });
}));

// Get historical data for a specific cryptocurrency
router.get('/:symbol/historical', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol } = req.params;
  const { days = 7 } = req.query;
  
  const historicalData = await cryptoService.getHistoricalData(symbol, parseInt(days));
  
  res.json({ 
    success: true,
    data: historicalData 
  });
}));

// Alias for historical data with different path
router.get('/:id/history', optionalAuth, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { days = 7 } = req.query;
  
  const historicalData = await cryptoService.getHistoricalData(id, parseInt(days));
  
  res.json({ 
    success: true,
    data: historicalData 
  });
}));

// Get detailed info for a specific cryptocurrency
router.get('/:symbol/details', optionalAuth, asyncHandler(async (req, res) => {
  const { symbol } = req.params;
  
  const details = await cryptoService.getCryptoDetails(symbol);
  
  res.json({ 
    success: true,
    data: details 
  });
}));

module.exports = router;