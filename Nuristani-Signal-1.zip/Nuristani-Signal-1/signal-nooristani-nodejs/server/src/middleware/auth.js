const authService = require('../services/auth.service');
const { AppError } = require('./errorHandler');

const authMiddleware = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('No token provided', 401, 'AUTH_REQUIRED');
    }
    
    const token = authHeader.split(' ')[1];
    
    // Verify token using auth service
    const user = await authService.verifyAccessToken(token);
    
    // Attach user to request
    req.user = {
      id: user.id,
      email: user.email,
      fullName: user.full_name
    };
    
    next();
  } catch (error) {
    next(error);
  }
};

// Optional auth middleware - doesn't fail if no token
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      
      try {
        // Try to verify token using auth service
        const user = await authService.verifyAccessToken(token);
        
        // Attach user to request
        req.user = {
          id: user.id,
          email: user.email,
          fullName: user.full_name
        };
      } catch (error) {
        // Ignore token errors for optional auth
        // User remains undefined
      }
    }
    
    next();
  } catch (error) {
    // Ignore all errors for optional auth
    next();
  }
};

// Alias for authMiddleware
const requireAuth = authMiddleware;

// Alias for authMiddleware
const authenticateToken = authMiddleware;

module.exports = {
  authMiddleware,
  optionalAuth,
  requireAuth,
  authenticateToken
};