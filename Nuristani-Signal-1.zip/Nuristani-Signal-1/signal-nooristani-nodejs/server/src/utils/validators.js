const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePassword = (password) => {
  // At least 8 characters, one letter and one number
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }
  if (!/[a-zA-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one letter' };
  }
  if (!/\d/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  return { valid: true };
};

const validateRegister = (data) => {
  if (!data.email || !data.password || !data.fullName) {
    return { valid: false, message: 'All fields are required' };
  }
  
  if (!validateEmail(data.email)) {
    return { valid: false, message: 'Invalid email format' };
  }
  
  const passwordValidation = validatePassword(data.password);
  if (!passwordValidation.valid) {
    return passwordValidation;
  }
  
  if (data.fullName.length < 2) {
    return { valid: false, message: 'Full name must be at least 2 characters' };
  }
  
  return { valid: true };
};

const validateLogin = (data) => {
  if (!data.email || !data.password) {
    return { valid: false, message: 'Email and password are required' };
  }
  
  if (!validateEmail(data.email)) {
    return { valid: false, message: 'Invalid email format' };
  }
  
  return { valid: true };
};

module.exports = {
  validateEmail,
  validatePassword,
  validateRegister,
  validateLogin
};