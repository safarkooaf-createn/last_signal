# -*- coding: utf-8 -*-
"""
User Authentication System for Signal Nooristani Platform
Provides secure user registration, login, session management, and user preferences
"""

import os
import hashlib
import secrets
import bcrypt
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime, timedelta
from contextlib import contextmanager
import streamlit as st
import re

class AuthenticationSystem:
    """
    Comprehensive authentication system with secure password hashing,
    session management, and user preferences
    """
    
    def __init__(self):
        self.db_url = os.getenv('DATABASE_URL')
        if not self.db_url:
            raise ValueError("DATABASE_URL environment variable not found")
        
        # Initialize session state for authentication
        if 'authenticated' not in st.session_state:
            st.session_state.authenticated = False
        if 'user_id' not in st.session_state:
            st.session_state.user_id = None
        if 'user_email' not in st.session_state:
            st.session_state.user_email = None
        if 'user_name' not in st.session_state:
            st.session_state.user_name = None
        if 'session_token' not in st.session_state:
            st.session_state.session_token = None
    
    @contextmanager
    def get_db_connection(self):
        """Get database connection with proper error handling"""
        conn = None
        try:
            conn = psycopg2.connect(self.db_url)
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                conn.close()
    
    def hash_password(self, password):
        """Hash password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def verify_password(self, password, hashed_password):
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
    
    def generate_session_token(self):
        """Generate secure session token"""
        return secrets.token_urlsafe(32)
    
    def validate_email(self, email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def validate_password(self, password):
        """Validate password strength"""
        if len(password) < 8:
            return False, "Password must be at least 8 characters long"
        if not re.search(r'[A-Za-z]', password):
            return False, "Password must contain at least one letter"
        if not re.search(r'\d', password):
            return False, "Password must contain at least one number"
        return True, "Password is valid"
    
    def register_user(self, email, password, full_name, preferred_language='en'):
        """Register a new user"""
        try:
            # Validate input
            if not self.validate_email(email):
                return False, "Invalid email format"
            
            is_valid, password_msg = self.validate_password(password)
            if not is_valid:
                return False, password_msg
            
            if not full_name or len(full_name.strip()) < 2:
                return False, "Full name must be at least 2 characters"
            
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    # Check if user already exists
                    cur.execute("SELECT id FROM users WHERE email = %s", (email.lower(),))
                    if cur.fetchone():
                        return False, "User with this email already exists"
                    
                    # Hash password
                    password_hash = self.hash_password(password)
                    
                    # Insert user
                    cur.execute("""
                        INSERT INTO users (email, password_hash, full_name, email_verified)
                        VALUES (%s, %s, %s, %s)
                        RETURNING id
                    """, (email.lower(), password_hash, full_name.strip(), True))
                    
                    result = cur.fetchone()
                    if not result:
                        return False, "Failed to create user account"
                    user_id = result['id']
                    
                    # Create user preferences
                    cur.execute("""
                        INSERT INTO user_preferences (user_id, preferred_language)
                        VALUES (%s, %s)
                    """, (user_id, preferred_language))
                    
                    conn.commit()
                    return True, "User registered successfully"
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Registration error (internal): {str(e)}")
            return False, "Registration failed. Please try again or contact support."
    
    def _check_rate_limit(self, email):
        """Check if account is locked due to failed attempts"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    cur.execute("""
                        SELECT failed_login_attempts, account_locked_until
                        FROM users 
                        WHERE email = %s
                    """, (email.lower(),))
                    
                    result = cur.fetchone()
                    if not result:
                        return True  # User doesn't exist, allow attempt
                    
                    # Check if account is locked
                    if result['account_locked_until'] and result['account_locked_until'] > datetime.now():
                        return False
                    
                    return True
                    
        except Exception as e:
            print(f"Rate limit check error (internal): {str(e)}")
            return True  # Allow attempt on error
    
    def _record_failed_login(self, email, ip_address=None):
        """Record failed login attempt and lock account if necessary"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor() as cur:
                    # Update failed attempts
                    cur.execute("""
                        UPDATE users 
                        SET failed_login_attempts = failed_login_attempts + 1,
                            last_failed_login = CURRENT_TIMESTAMP,
                            account_locked_until = CASE 
                                WHEN failed_login_attempts >= 4 THEN CURRENT_TIMESTAMP + INTERVAL '15 minutes'
                                ELSE account_locked_until
                            END
                        WHERE email = %s
                    """, (email.lower(),))
                    
                    # Log security event
                    cur.execute("""
                        INSERT INTO security_audit_log (user_id, event_type, ip_address, details)
                        VALUES ((SELECT id FROM users WHERE email = %s), 'failed_login', %s, %s)
                    """, (email.lower(), ip_address, '{"reason": "invalid_credentials"}'))
                    
                    conn.commit()
                    
        except Exception as e:
            print(f"Failed login recording error (internal): {str(e)}")
    
    def _reset_failed_attempts(self, user_id):
        """Reset failed login attempts on successful login"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE users 
                        SET failed_login_attempts = 0,
                            account_locked_until = NULL
                        WHERE id = %s
                    """, (user_id,))
                    conn.commit()
                    
        except Exception as e:
            print(f"Reset failed attempts error (internal): {str(e)}")
    
    def login_user(self, email, password, ip_address=None, user_agent=None):
        """Authenticate user and create session with rate limiting"""
        try:
            if not self.validate_email(email):
                return False, "Invalid email format", None
            
            # Check rate limiting
            if not self._check_rate_limit(email):
                return False, "Account is temporarily locked due to multiple failed attempts. Please try again later.", None
            
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    # Get user data
                    cur.execute("""
                        SELECT id, email, password_hash, full_name, is_active, failed_login_attempts
                        FROM users 
                        WHERE email = %s
                    """, (email.lower(),))
                    
                    user = cur.fetchone()
                    if not user:
                        self._record_failed_login(email, ip_address)
                        return False, "Invalid email or password", None
                    
                    if not user['is_active']:
                        return False, "Account is deactivated", None
                    
                    # Verify password
                    if not self.verify_password(password, user['password_hash']):
                        self._record_failed_login(email, ip_address)
                        return False, "Invalid email or password", None
                    
                    # Reset failed attempts on successful login
                    self._reset_failed_attempts(user['id'])
                    
                    # Create session
                    session_token = self.generate_session_token()
                    expires_at = datetime.now() + timedelta(days=7)  # 7 day session
                    
                    cur.execute("""
                        INSERT INTO user_sessions (user_id, session_token, expires_at, ip_address, user_agent)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (user['id'], session_token, expires_at, ip_address, user_agent))
                    
                    # Update last login
                    cur.execute("""
                        UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = %s
                    """, (user['id'],))
                    
                    conn.commit()
                    
                    # Set session state
                    st.session_state.authenticated = True
                    st.session_state.user_id = user['id']
                    st.session_state.user_email = user['email']
                    st.session_state.user_name = user['full_name']
                    st.session_state.session_token = session_token
                    
                    return True, "Login successful", session_token
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Login error (internal): {str(e)}")
            return False, "Login failed. Please try again.", None
    
    def validate_session(self, session_token):
        """Validate session token and refresh session"""
        try:
            if not session_token:
                return False, None
            
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    # Get session and user data
                    cur.execute("""
                        SELECT s.user_id, s.expires_at, u.email, u.full_name, u.is_active
                        FROM user_sessions s
                        JOIN users u ON s.user_id = u.id
                        WHERE s.session_token = %s AND s.expires_at > CURRENT_TIMESTAMP
                    """, (session_token,))
                    
                    session = cur.fetchone()
                    if not session:
                        return False, None
                    
                    if not session['is_active']:
                        return False, None
                    
                    # Extend session if it expires within 24 hours
                    if session['expires_at'] < datetime.now() + timedelta(hours=24):
                        new_expires = datetime.now() + timedelta(days=7)
                        cur.execute("""
                            UPDATE user_sessions 
                            SET expires_at = %s 
                            WHERE session_token = %s
                        """, (new_expires, session_token))
                        conn.commit()
                    
                    # Set session state
                    st.session_state.authenticated = True
                    st.session_state.user_id = session['user_id']
                    st.session_state.user_email = session['email']
                    st.session_state.user_name = session['full_name']
                    st.session_state.session_token = session_token
                    
                    return True, session
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Session validation error (internal): {str(e)}")
            return False, None
    
    def logout_user(self, session_token=None):
        """Logout user and invalidate session"""
        try:
            if session_token:
                with self.get_db_connection() as conn:
                    with conn.cursor() as cur:
                        # Delete session
                        cur.execute("""
                            DELETE FROM user_sessions WHERE session_token = %s
                        """, (session_token,))
                        conn.commit()
            
            # Clear session state
            st.session_state.authenticated = False
            st.session_state.user_id = None
            st.session_state.user_email = None
            st.session_state.user_name = None
            st.session_state.session_token = None
            
            return True, "Logged out successfully"
            
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Logout error (internal): {str(e)}")
            return False, "Logout failed. Please try again."
    
    def get_user_preferences(self, user_id):
        """Get user preferences"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    cur.execute("""
                        SELECT * FROM user_preferences WHERE user_id = %s
                    """, (user_id,))
                    
                    prefs = cur.fetchone()
                    if not prefs:
                        # Create default preferences
                        cur.execute("""
                            INSERT INTO user_preferences (user_id) VALUES (%s)
                            RETURNING *
                        """, (user_id,))
                        prefs = cur.fetchone()
                        conn.commit()
                    
                    return prefs
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Preferences error (internal): {str(e)}")
            return {}
    
    def update_user_preferences(self, user_id, preferences):
        """Update user preferences"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE user_preferences 
                        SET preferred_language = %s,
                            preferred_currency = %s,
                            email_notifications = %s,
                            auto_refresh_enabled = %s,
                            refresh_interval = %s,
                            theme = %s,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE user_id = %s
                    """, (
                        preferences.get('preferred_language', 'en'),
                        preferences.get('preferred_currency', 'USD'),
                        preferences.get('email_notifications', True),
                        preferences.get('auto_refresh_enabled', True),
                        preferences.get('refresh_interval', 30),
                        preferences.get('theme', 'default'),
                        user_id
                    ))
                    conn.commit()
                    return True, "Preferences updated successfully"
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Preferences update error (internal): {str(e)}")
            return False, "Error updating preferences. Please try again."
    
    def cleanup_expired_sessions(self):
        """Clean up expired sessions"""
        try:
            with self.get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP
                    """)
                    conn.commit()
                    
        except Exception as e:
            # Log the actual error for debugging (not exposed to user)
            print(f"Session cleanup error (internal): {str(e)}")
    
    def is_authenticated(self):
        """Check if user is authenticated"""
        return st.session_state.get('authenticated', False)
    
    def get_current_user(self):
        """Get current user data"""
        if self.is_authenticated():
            return {
                'id': st.session_state.get('user_id'),
                'email': st.session_state.get('user_email'),
                'name': st.session_state.get('user_name'),
                'session_token': st.session_state.get('session_token')
            }
        return None
    
    def require_authentication(self):
        """Decorator-like method to require authentication"""
        if not self.is_authenticated():
            return False
        
        # Validate current session
        session_token = st.session_state.get('session_token')
        if session_token:
            is_valid, _ = self.validate_session(session_token)
            if not is_valid:
                self.logout_user()
                return False
        
        return True