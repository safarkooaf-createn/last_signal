# -*- coding: utf-8 -*-
"""
Authentication UI Components for Signal Nooristani Platform
Provides login, registration, and user management interfaces
"""

import streamlit as st
from auth_system import AuthenticationSystem
from translations import get_translation, LANGUAGES, apply_rtl_style

class AuthenticationUI:
    """
    User interface components for authentication system
    """
    
    def __init__(self):
        self.auth_system = AuthenticationSystem()
    
    def render_login_form(self, current_lang='en'):
        """Render login form"""
        st.markdown(f"### 🔐 {get_translation('login_title', current_lang)}")
        
        with st.form("login_form", clear_on_submit=False):
            email = st.text_input(
                get_translation('email_label', current_lang),
                placeholder=get_translation('email_placeholder', current_lang),
                key="login_email"
            )
            
            password = st.text_input(
                get_translation('password_label', current_lang),
                type="password",
                placeholder=get_translation('password_placeholder', current_lang),
                key="login_password"
            )
            
            col1, col2 = st.columns(2)
            with col1:
                login_submitted = st.form_submit_button(
                    get_translation('login_button', current_lang),
                    use_container_width=True,
                    type="primary"
                )
            with col2:
                register_link = st.form_submit_button(
                    get_translation('register_link', current_lang),
                    use_container_width=True
                )
        
        if login_submitted:
            if email and password:
                success, message, session_token = self.auth_system.login_user(
                    email, password, 
                    ip_address='127.0.0.1',  # Safe fallback for production
                    user_agent='Streamlit App'  # Safe fallback for production
                )
                
                if success:
                    st.success(get_translation('login_success', current_lang))
                    st.rerun()
                else:
                    st.error(f"{get_translation('login_error', current_lang)}: {message}")
            else:
                st.error(get_translation('fill_all_fields', current_lang))
        
        if register_link:
            st.session_state.show_register_form = True
            st.rerun()
    
    def render_registration_form(self, current_lang='en'):
        """Render registration form"""
        st.markdown(f"### 📝 {get_translation('register_title', current_lang)}")
        
        with st.form("registration_form", clear_on_submit=False):
            full_name = st.text_input(
                get_translation('full_name_label', current_lang),
                placeholder=get_translation('full_name_placeholder', current_lang),
                key="register_name"
            )
            
            email = st.text_input(
                get_translation('email_label', current_lang),
                placeholder=get_translation('email_placeholder', current_lang),
                key="register_email"
            )
            
            password = st.text_input(
                get_translation('password_label', current_lang),
                type="password",
                placeholder=get_translation('password_placeholder', current_lang),
                help=get_translation('password_requirements', current_lang),
                key="register_password"
            )
            
            confirm_password = st.text_input(
                get_translation('confirm_password_label', current_lang),
                type="password",
                placeholder=get_translation('confirm_password_placeholder', current_lang),
                key="register_confirm_password"
            )
            
            preferred_language = st.selectbox(
                get_translation('preferred_language_label', current_lang),
                options=list(LANGUAGES.keys()),
                format_func=lambda x: f"{LANGUAGES[x]['flag']} {LANGUAGES[x]['name']}",
                index=list(LANGUAGES.keys()).index(current_lang) if current_lang in LANGUAGES else 0,
                key="register_language"
            )
            
            col1, col2 = st.columns(2)
            with col1:
                register_submitted = st.form_submit_button(
                    get_translation('register_button', current_lang),
                    use_container_width=True,
                    type="primary"
                )
            with col2:
                back_to_login = st.form_submit_button(
                    get_translation('back_to_login', current_lang),
                    use_container_width=True
                )
        
        if register_submitted:
            if full_name and email and password and confirm_password:
                if password != confirm_password:
                    st.error(get_translation('password_mismatch', current_lang))
                else:
                    success, message = self.auth_system.register_user(
                        email, password, full_name, preferred_language
                    )
                    
                    if success:
                        st.success(get_translation('registration_success', current_lang))
                        st.session_state.show_register_form = False
                        st.rerun()
                    else:
                        st.error(f"{get_translation('registration_error', current_lang)}: {message}")
            else:
                st.error(get_translation('fill_all_fields', current_lang))
        
        if back_to_login:
            st.session_state.show_register_form = False
            st.rerun()
    
    def render_user_dashboard(self, current_lang='en'):
        """Render user dashboard for authenticated users"""
        user = self.auth_system.get_current_user()
        if not user:
            return
        
        st.markdown(f"### 👤 {get_translation('user_dashboard', current_lang)}")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.markdown(f"**{get_translation('welcome_message', current_lang)}** {user['name']}")
            st.markdown(f"📧 {user['email']}")
        
        with col2:
            if st.button(get_translation('logout_button', current_lang), type="secondary"):
                success, message = self.auth_system.logout_user(user['session_token'])
                if success:
                    st.success(get_translation('logout_success', current_lang))
                    st.rerun()
                else:
                    st.error(f"{get_translation('logout_error', current_lang)}: {message}")
        
        # User preferences section
        with st.expander(get_translation('user_preferences', current_lang)):
            preferences = self.auth_system.get_user_preferences(user['id']) or {}
            
            with st.form("preferences_form"):
                pref_language = st.selectbox(
                    get_translation('preferred_language_label', current_lang),
                    options=list(LANGUAGES.keys()),
                    format_func=lambda x: f"{LANGUAGES[x]['flag']} {LANGUAGES[x]['name']}",
                    index=list(LANGUAGES.keys()).index(preferences.get('preferred_language', 'en')),
                    key="pref_language"
                )
                
                email_notifications = st.checkbox(
                    get_translation('email_notifications_label', current_lang),
                    value=preferences.get('email_notifications', True),
                    key="pref_email_notifications"
                )
                
                auto_refresh = st.checkbox(
                    get_translation('auto_refresh', current_lang),
                    value=preferences.get('auto_refresh_enabled', True),
                    key="pref_auto_refresh"
                )
                
                refresh_interval = st.slider(
                    get_translation('refresh_interval', current_lang),
                    min_value=10,
                    max_value=300,
                    value=preferences.get('refresh_interval', 30),
                    step=10,
                    key="pref_refresh_interval"
                )
                
                if st.form_submit_button(get_translation('save_preferences', current_lang)):
                    new_preferences = {
                        'preferred_language': pref_language,
                        'email_notifications': email_notifications,
                        'auto_refresh_enabled': auto_refresh,
                        'refresh_interval': refresh_interval
                    }
                    
                    success, message = self.auth_system.update_user_preferences(user['id'], new_preferences)
                    if success:
                        st.success(get_translation('preferences_saved', current_lang))
                        # Update current language if changed
                        if pref_language != current_lang:
                            st.session_state.selected_language = pref_language
                            st.rerun()
                    else:
                        st.error(f"{get_translation('preferences_error', current_lang)}: {message}")
    
    def render_authentication_sidebar(self, current_lang='en'):
        """Render authentication section in sidebar"""
        if self.auth_system.is_authenticated():
            user = self.auth_system.get_current_user()
            if user:
                st.sidebar.markdown("---")
                st.sidebar.markdown(f"### 👤 {get_translation('logged_in_as', current_lang)}")
                st.sidebar.markdown(f"**{user['name']}**")
                st.sidebar.markdown(f"📧 {user['email']}")
                
                if st.sidebar.button(get_translation('logout_button', current_lang)):
                    success, message = self.auth_system.logout_user(user['session_token'])
                    if success:
                        st.success(get_translation('logout_success', current_lang))
                        st.rerun()
        else:
            st.sidebar.markdown("---")
            st.sidebar.markdown(f"### 🔐 {get_translation('authentication', current_lang)}")
            st.sidebar.info(get_translation('login_required_message', current_lang))
    
    def check_authentication_flow(self, current_lang='en'):
        """Handle authentication flow and return whether user is authenticated"""
        # Initialize show_register_form state
        if 'show_register_form' not in st.session_state:
            st.session_state.show_register_form = False
        
        # Check if user is already authenticated
        if self.auth_system.is_authenticated():
            # Validate session
            session_token = st.session_state.get('session_token')
            if session_token:
                is_valid, _ = self.auth_system.validate_session(session_token)
                if not is_valid:
                    self.auth_system.logout_user()
                    st.rerun()
                else:
                    return True
        
        # Show authentication forms
        if st.session_state.show_register_form:
            self.render_registration_form(current_lang)
        else:
            self.render_login_form(current_lang)
        
        return False
    
    def require_authentication_page(self, current_lang='en'):
        """Create a full page authentication requirement"""
        st.title(f"🔐 {get_translation('authentication_required', current_lang)}")
        
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown(f"### {get_translation('login_to_continue', current_lang)}")
            
            tab1, tab2 = st.tabs([
                get_translation('login_tab', current_lang),
                get_translation('register_tab', current_lang)
            ])
            
            with tab1:
                self.render_login_form(current_lang)
            
            with tab2:
                self.render_registration_form(current_lang)
        
        return False