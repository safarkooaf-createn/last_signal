import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class PredictionEngine:
    """
    Generates cryptocurrency price predictions using technical analysis and machine learning
    """
    
    def __init__(self):
        self.models = {}
        self.feature_columns = []
        
    def generate_predictions(self, historical_data):
        """
        Generate price direction predictions for 5, 10, and 30-minute intervals
        
        Args:
            historical_data (pandas.DataFrame): Historical price data with technical indicators
            
        Returns:
            dict: Predictions for different time intervals
        """
        try:
            if historical_data.empty or len(historical_data) < 10:
                return self._default_predictions()
            
            # Prepare features for prediction
            features_df = self._prepare_features(historical_data)
            
            if features_df.empty:
                return self._default_predictions()
            
            predictions = {}
            
            # Generate predictions for each time interval
            for interval in ['5min', '10min', '30min']:
                prediction = self._predict_direction(features_df, interval)
                predictions[interval] = prediction
            
            return predictions
            
        except Exception as e:
            print(f"Error generating predictions: {e}")
            return self._default_predictions()
    
    def _prepare_features(self, df):
        """
        Prepare features for machine learning models
        
        Args:
            df (pandas.DataFrame): Historical data
            
        Returns:
            pandas.DataFrame: Features for prediction
        """
        try:
            features_df = df.copy()
            
            if len(features_df) < 5:
                return pd.DataFrame()
            
            # Price-based features
            features_df['price_momentum_1'] = features_df['price'].pct_change(1)
            features_df['price_momentum_3'] = features_df['price'].pct_change(3)
            features_df['price_momentum_5'] = features_df['price'].pct_change(5)
            
            # Moving average ratios
            if 'ma_20' in features_df.columns:
                features_df['price_to_ma20'] = features_df['price'] / features_df['ma_20']
            else:
                features_df['price_to_ma20'] = 1.0
                
            if 'ma_50' in features_df.columns:
                features_df['price_to_ma50'] = features_df['price'] / features_df['ma_50']
            else:
                features_df['price_to_ma50'] = 1.0
            
            # Volatility features
            if 'volatility' in features_df.columns:
                features_df['volatility_norm'] = features_df['volatility'] / features_df['price']
            else:
                features_df['volatility_norm'] = 0.01
            
            # RSI feature
            if 'rsi' in features_df.columns:
                features_df['rsi_norm'] = features_df['rsi'] / 100.0
            else:
                features_df['rsi_norm'] = 0.5
            
            # Price position in recent range
            if len(features_df) >= 10:
                rolling_min = features_df['price'].rolling(window=10).min()
                rolling_max = features_df['price'].rolling(window=10).max()
                features_df['price_position'] = (features_df['price'] - rolling_min) / (rolling_max - rolling_min + 1e-8)
            else:
                features_df['price_position'] = 0.5
            
            # Trend strength
            if len(features_df) >= 5:
                features_df['trend_strength'] = features_df['price'].rolling(window=5).apply(
                    lambda x: np.corrcoef(range(len(x)), x)[0, 1] if len(x) > 1 else 0
                )
            else:
                features_df['trend_strength'] = 0.0
            
            # Fill NaN values
            features_df = features_df.ffill().fillna(0)
            
            return features_df
            
        except Exception as e:
            print(f"Error preparing features: {e}")
            return pd.DataFrame()
    
    def _predict_direction(self, features_df, interval):
        """
        Predict price direction for a specific time interval
        
        Args:
            features_df (pandas.DataFrame): Features for prediction
            interval (str): Time interval ('5min', '10min', '30min')
            
        Returns:
            dict: Prediction with direction and confidence
        """
        try:
            if len(features_df) < 10:
                return {'direction': 'sideways', 'confidence': 50.0}
            
            # Select relevant features
            feature_cols = [
                'price_momentum_1', 'price_momentum_3', 'price_momentum_5',
                'price_to_ma20', 'price_to_ma50', 'volatility_norm',
                'rsi_norm', 'price_position', 'trend_strength'
            ]
            
            # Ensure all feature columns exist
            for col in feature_cols:
                if col not in features_df.columns:
                    features_df[col] = 0.0
            
            # Get recent data for prediction
            recent_data = features_df[feature_cols].tail(20)
            latest_features = recent_data.iloc[-1].values
            
            # Simple ensemble approach
            predictions = []
            
            # Technical Analysis Prediction
            ta_prediction = self._technical_analysis_prediction(features_df)
            predictions.append(ta_prediction)
            
            # Momentum-based prediction
            momentum_prediction = self._momentum_prediction(features_df)
            predictions.append(momentum_prediction)
            
            # Moving average prediction
            ma_prediction = self._moving_average_prediction(features_df)
            predictions.append(ma_prediction)
            
            # Volatility-based prediction
            volatility_prediction = self._volatility_prediction(features_df, interval)
            predictions.append(volatility_prediction)
            
            # Combine predictions
            direction, confidence = self._combine_predictions(predictions)
            
            return {
                'direction': direction,
                'confidence': confidence
            }
            
        except Exception as e:
            print(f"Error in direction prediction: {e}")
            return {'direction': 'sideways', 'confidence': 50.0}
    
    def _technical_analysis_prediction(self, df):
        """Technical analysis based prediction"""
        try:
            latest = df.iloc[-1]
            
            score = 0
            factors = 0
            
            # Price vs moving averages
            if 'price_to_ma20' in latest:
                if latest['price_to_ma20'] > 1.02:
                    score += 1
                elif latest['price_to_ma20'] < 0.98:
                    score -= 1
                factors += 1
            
            if 'price_to_ma50' in latest:
                if latest['price_to_ma50'] > 1.01:
                    score += 1
                elif latest['price_to_ma50'] < 0.99:
                    score -= 1
                factors += 1
            
            # RSI analysis
            if 'rsi_norm' in latest:
                rsi = latest['rsi_norm'] * 100
                if rsi < 30:  # Oversold
                    score += 1
                elif rsi > 70:  # Overbought
                    score -= 1
                factors += 1
            
            # Trend strength
            if 'trend_strength' in latest:
                trend = latest['trend_strength']
                if trend > 0.3:
                    score += 1
                elif trend < -0.3:
                    score -= 1
                factors += 1
            
            if factors == 0:
                return 0
            
            return score / factors
            
        except Exception as e:
            print(f"Error in technical analysis prediction: {e}")
            return 0
    
    def _momentum_prediction(self, df):
        """Momentum-based prediction"""
        try:
            if len(df) < 5:
                return 0
            
            recent_momentum = df['price_momentum_1'].tail(5).mean()
            medium_momentum = df['price_momentum_3'].tail(3).mean()
            
            if recent_momentum > 0.005 and medium_momentum > 0.002:
                return 1  # Strong upward momentum
            elif recent_momentum < -0.005 and medium_momentum < -0.002:
                return -1  # Strong downward momentum
            elif recent_momentum > 0.001:
                return 0.5  # Mild upward momentum
            elif recent_momentum < -0.001:
                return -0.5  # Mild downward momentum
            else:
                return 0  # Sideways
                
        except Exception as e:
            print(f"Error in momentum prediction: {e}")
            return 0
    
    def _moving_average_prediction(self, df):
        """Moving average crossover prediction"""
        try:
            if 'ma_20' not in df.columns or len(df) < 20:
                return 0
            
            current_price = df['price'].iloc[-1]
            ma_20_current = df['ma_20'].iloc[-1]
            
            if len(df) >= 2:
                prev_price = df['price'].iloc[-2]
                ma_20_prev = df['ma_20'].iloc[-2]
                
                # Check for crossover
                if prev_price <= ma_20_prev and current_price > ma_20_current:
                    return 1  # Bullish crossover
                elif prev_price >= ma_20_prev and current_price < ma_20_current:
                    return -1  # Bearish crossover
            
            # Check price position relative to MA
            if current_price > ma_20_current * 1.01:
                return 0.5
            elif current_price < ma_20_current * 0.99:
                return -0.5
            else:
                return 0
                
        except Exception as e:
            print(f"Error in moving average prediction: {e}")
            return 0
    
    def _volatility_prediction(self, df, interval):
        """Volatility-based prediction"""
        try:
            if 'volatility_norm' not in df.columns or len(df) < 5:
                return 0
            
            current_vol = df['volatility_norm'].iloc[-1]
            avg_vol = df['volatility_norm'].tail(10).mean()
            
            # High volatility might indicate direction change
            if current_vol > avg_vol * 1.5:
                # Look at recent momentum to determine direction
                recent_momentum = df['price_momentum_1'].tail(3).mean()
                if recent_momentum > 0:
                    return 0.3
                elif recent_momentum < 0:
                    return -0.3
                else:
                    return 0
            else:
                return 0
                
        except Exception as e:
            print(f"Error in volatility prediction: {e}")
            return 0
    
    def _combine_predictions(self, predictions):
        """Combine multiple predictions into final direction and confidence"""
        try:
            if not predictions:
                return 'sideways', 50.0
            
            # Calculate weighted average
            weights = [1.0, 1.2, 1.1, 0.8]  # Technical, Momentum, MA, Volatility
            weighted_sum = sum(p * w for p, w in zip(predictions, weights))
            total_weight = sum(weights)
            
            avg_prediction = weighted_sum / total_weight
            
            # Determine direction
            if avg_prediction > 0.1:
                direction = 'up'
                confidence = min(85.0, 50.0 + abs(avg_prediction) * 40)
            elif avg_prediction < -0.1:
                direction = 'down'
                confidence = min(85.0, 50.0 + abs(avg_prediction) * 40)
            else:
                direction = 'sideways'
                confidence = 50.0 + abs(avg_prediction) * 20
            
            return direction, confidence
            
        except Exception as e:
            print(f"Error combining predictions: {e}")
            return 'sideways', 50.0
    
    def _default_predictions(self):
        """Return default predictions when data is insufficient"""
        return {
            '5min': {'direction': 'sideways', 'confidence': 50.0},
            '10min': {'direction': 'sideways', 'confidence': 50.0},
            '30min': {'direction': 'sideways', 'confidence': 50.0}
        }
