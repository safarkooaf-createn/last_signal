import streamlit as st
from datetime import datetime
import pandas as pd

def format_currency(value, decimals=2):
    """
    Format a number as currency with proper decimal places
    
    Args:
        value (float): The value to format
        decimals (int): Number of decimal places
        
    Returns:
        str: Formatted currency string
    """
    try:
        if value >= 1:
            return f"${value:,.{decimals}f}"
        elif value >= 0.01:
            return f"${value:.4f}"
        elif value >= 0.0001:
            return f"${value:.6f}"
        else:
            return f"${value:.8f}"
    except (TypeError, ValueError):
        return "$0.00"

def format_percentage(value):
    """
    Format a number as a percentage
    
    Args:
        value (float): The percentage value
        
    Returns:
        str: Formatted percentage string
    """
    try:
        return f"{value:+.2f}%"
    except (TypeError, ValueError):
        return "0.00%"

def format_large_number(value):
    """
    Format large numbers with appropriate suffixes (K, M, B, T)
    
    Args:
        value (float): The number to format
        
    Returns:
        str: Formatted number string
    """
    try:
        if value >= 1e12:
            return f"${value/1e12:.2f}T"
        elif value >= 1e9:
            return f"${value/1e9:.2f}B"
        elif value >= 1e6:
            return f"${value/1e6:.2f}M"
        elif value >= 1e3:
            return f"${value/1e3:.2f}K"
        else:
            return f"${value:.2f}"
    except (TypeError, ValueError):
        return "$0.00"

def get_trend_color(direction):
    """
    Get color based on trend direction
    
    Args:
        direction (str): Direction ('up', 'down', 'sideways')
        
    Returns:
        str: Color code
    """
    color_map = {
        'up': '#00d4aa',      # Green
        'down': '#ff6b6b',    # Red
        'sideways': '#ffa726', # Orange
        'unknown': '#9e9e9e'   # Gray
    }
    
    return color_map.get(direction.lower(), color_map['unknown'])

def get_trend_emoji(direction):
    """
    Get emoji based on trend direction
    
    Args:
        direction (str): Direction ('up', 'down', 'sideways')
        
    Returns:
        str: Emoji
    """
    emoji_map = {
        'up': '📈',
        'down': '📉',
        'sideways': '➡️',
        'unknown': '❓'
    }
    
    return emoji_map.get(direction.lower(), emoji_map['unknown'])

def calculate_price_change(current_price, previous_price):
    """
    Calculate percentage change between two prices
    
    Args:
        current_price (float): Current price
        previous_price (float): Previous price
        
    Returns:
        float: Percentage change
    """
    try:
        if previous_price == 0:
            return 0.0
        return ((current_price - previous_price) / previous_price) * 100
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0

def validate_data(data, required_fields):
    """
    Validate that data contains required fields
    
    Args:
        data (dict): Data to validate
        required_fields (list): List of required field names
        
    Returns:
        bool: True if all required fields are present
    """
    try:
        if not isinstance(data, dict):
            return False
        
        for field in required_fields:
            if field not in data:
                return False
        
        return True
    except Exception:
        return False

def safe_get(dictionary, key, default=None):
    """
    Safely get a value from a dictionary
    
    Args:
        dictionary (dict): Dictionary to get value from
        key (str): Key to look for
        default: Default value if key not found
        
    Returns:
        Any: Value from dictionary or default
    """
    try:
        return dictionary.get(key, default)
    except (AttributeError, TypeError):
        return default

def create_prediction_summary(predictions):
    """
    Create a summary of predictions for display
    
    Args:
        predictions (dict): Predictions data
        
    Returns:
        str: Formatted summary
    """
    try:
        summary_parts = []
        
        for interval, prediction in predictions.items():
            direction = prediction.get('direction', 'unknown')
            confidence = prediction.get('confidence', 0)
            emoji = get_trend_emoji(direction)
            
            summary_parts.append(f"{interval}: {emoji} {direction.upper()} ({confidence:.1f}%)")
        
        return " | ".join(summary_parts)
    except Exception:
        return "No predictions available"

def get_time_until_next_update(last_update, refresh_interval):
    """
    Calculate time until next update
    
    Args:
        last_update (datetime): Last update timestamp
        refresh_interval (int): Refresh interval in seconds
        
    Returns:
        int: Seconds until next update
    """
    try:
        now = datetime.now()
        time_passed = (now - last_update).total_seconds()
        time_remaining = max(0, refresh_interval - time_passed)
        return int(time_remaining)
    except Exception:
        return 0

def format_timestamp(timestamp):
    """
    Format timestamp for display
    
    Args:
        timestamp (datetime): Timestamp to format
        
    Returns:
        str: Formatted timestamp
    """
    try:
        return timestamp.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "Unknown"

def calculate_support_resistance(prices, window=20):
    """
    Calculate basic support and resistance levels
    
    Args:
        prices (list or pandas.Series): Price data
        window (int): Window size for calculation
        
    Returns:
        dict: Support and resistance levels
    """
    try:
        if len(prices) < window:
            return {'support': min(prices), 'resistance': max(prices)}
        
        recent_prices = prices[-window:]
        support = min(recent_prices)
        resistance = max(recent_prices)
        
        return {'support': support, 'resistance': resistance}
    except Exception:
        return {'support': 0, 'resistance': 0}
