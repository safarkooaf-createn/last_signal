import os

# Set TensorFlow environment variables FIRST, before any other imports
# This must be done before TensorFlow is imported anywhere in the process
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress all TensorFlow messages
os.environ['CUDA_VISIBLE_DEVICES'] = ''  # Disable all GPU devices
os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'false'  # Disable GPU memory growth
os.environ['TF_USE_LEGACY_KERAS'] = '1'
os.environ['KERAS_BACKEND'] = 'tensorflow'
# Additional environment variables to prevent CUDA initialization
os.environ['TF_XLA_FLAGS'] = '--tf_xla_enable_xla_devices=false'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import threading
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

# TensorFlow imports with proper type declarations
tf = None
Sequential = None
LSTM = None
Dense = None
Dropout = None
GRU = None

try:
    import tensorflow as tf
    
    # Additional configuration immediately after import
    tf.config.set_visible_devices([], 'GPU')
    tf.compat.v1.disable_eager_execution()  # Disable eager execution to reduce overhead
    tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)  # Suppress warnings
    
    # Import only from tensorflow.keras (no standalone keras)
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense, Dropout, GRU
    TENSORFLOW_AVAILABLE = True
    print("TensorFlow loaded successfully in CPU-only mode")
except ImportError as e:
    TENSORFLOW_AVAILABLE = False
    print(f"TensorFlow not available, using Random Forest only: {e}")
except Exception as e:
    TENSORFLOW_AVAILABLE = False
    print(f"TensorFlow configuration error, using Random Forest only: {e}")

# TA library imports with proper type declarations
ta = None

try:
    import ta
    TA_AVAILABLE = True
except ImportError:
    TA_AVAILABLE = False
    print("TA library not available, using basic indicators")
import warnings
warnings.filterwarnings('ignore')

class AdvancedPredictionEngine:
    """
    Advanced cryptocurrency price prediction using LSTM, Random Forest, and comprehensive technical analysis
    """
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_columns = []
        self.lstm_model = None
        self.rf_model = None
        self.model_trained = False
        self._training_lock = threading.Lock()  # Prevent concurrent model training
        
    def generate_advanced_predictions(self, historical_data, coin_symbol="BTC"):
        """
        Generate advanced predictions using ML models and comprehensive technical analysis
        
        Args:
            historical_data (pandas.DataFrame): Historical price data
            coin_symbol (str): Symbol of the cryptocurrency
            
        Returns:
            dict: Advanced predictions with confidence scores
        """
        try:
            # Comprehensive data validation
            if historical_data is None or historical_data.empty or len(historical_data) < 50:
                return self._default_predictions()
            
            # Check if required columns exist
            if 'price' not in historical_data.columns:
                return self._default_predictions()
            
            # Prepare comprehensive features
            features_df = self._prepare_advanced_features(historical_data)
            
            if features_df is None or features_df.empty or len(features_df) < 20:
                return self._default_predictions()
            
            predictions = {}
            
            # Train models if not already trained (with thread safety)
            if not self.model_trained:
                with self._training_lock:  # Ensure thread-safe model training
                    if not self.model_trained:  # Double-check after acquiring lock
                        try:
                            self._train_models(features_df)
                        except Exception as train_error:
                            print(f"Error training models, using defaults: {train_error}")
                            return self._default_predictions()
            
            # Generate predictions for each interval
            for interval in ['5min', '10min', '30min']:
                try:
                    prediction = self._predict_with_ensemble(features_df, interval)
                    predictions[interval] = prediction
                except Exception:
                    predictions[interval] = {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5}
            
            return predictions
            
        except Exception as e:
            print(f"Error in advanced predictions: {e}")
            return self._default_predictions()
    
    def _prepare_advanced_features(self, df):
        """
        Prepare comprehensive features including all technical indicators
        """
        try:
            features_df = df.copy()
            
            if len(features_df) < 20:
                return pd.DataFrame()
            
            # Basic price features
            features_df['returns'] = features_df['price'].pct_change()
            features_df['log_returns'] = np.log(features_df['price'] / features_df['price'].shift(1))
            
            # Moving averages (multiple periods)
            for period in [5, 10, 20, 50]:
                if len(features_df) >= period:
                    features_df[f'ma_{period}'] = features_df['price'].rolling(window=period).mean()
                    features_df[f'price_to_ma_{period}'] = features_df['price'] / features_df[f'ma_{period}']
            
            # Exponential moving averages
            for period in [12, 26]:
                if len(features_df) >= period:
                    features_df[f'ema_{period}'] = features_df['price'].ewm(span=period).mean()
            
            # MACD
            if len(features_df) >= 26:
                exp1 = features_df['price'].ewm(span=12).mean()
                exp2 = features_df['price'].ewm(span=26).mean()
                features_df['macd'] = exp1 - exp2
                features_df['macd_signal'] = features_df['macd'].ewm(span=9).mean()
                features_df['macd_histogram'] = features_df['macd'] - features_df['macd_signal']
            
            # RSI (multiple periods)
            for period in [14, 21]:
                if len(features_df) >= period:
                    if TA_AVAILABLE and ta is not None:
                        try:
                            features_df[f'rsi_{period}'] = ta.momentum.RSIIndicator(
                                features_df['price'], window=period
                            ).rsi()
                        except:
                            features_df[f'rsi_{period}'] = self._calculate_rsi_manual(features_df['price'], period)
                    else:
                        features_df[f'rsi_{period}'] = self._calculate_rsi_manual(features_df['price'], period)
            
            # Bollinger Bands
            if len(features_df) >= 20:
                if TA_AVAILABLE and ta is not None:
                    try:
                        bb = ta.volatility.BollingerBands(features_df['price'], window=20, window_dev=2)
                        features_df['bb_upper'] = bb.bollinger_hband()
                        features_df['bb_lower'] = bb.bollinger_lband()
                        features_df['bb_middle'] = bb.bollinger_mavg()
                    except:
                        features_df = self._calculate_bollinger_bands_manual(features_df)
                else:
                    features_df = self._calculate_bollinger_bands_manual(features_df)
                
                if 'bb_upper' in features_df.columns and 'bb_lower' in features_df.columns:
                    features_df['bb_width'] = (features_df['bb_upper'] - features_df['bb_lower']) / features_df['bb_middle']
                    features_df['bb_position'] = (features_df['price'] - features_df['bb_lower']) / (features_df['bb_upper'] - features_df['bb_lower'])
            
            # Stochastic Oscillator (simplified manual implementation)
            if len(features_df) >= 14:
                high_14 = features_df['price'].rolling(window=14).max()
                low_14 = features_df['price'].rolling(window=14).min()
                features_df['stoch_k'] = 100 * ((features_df['price'] - low_14) / (high_14 - low_14))
                features_df['stoch_d'] = features_df['stoch_k'].rolling(window=3).mean()
            
            # Williams %R (manual implementation)
            if len(features_df) >= 14:
                high_14 = features_df['price'].rolling(window=14).max()
                low_14 = features_df['price'].rolling(window=14).min()
                features_df['williams_r'] = -100 * ((high_14 - features_df['price']) / (high_14 - low_14))
            
            # Average True Range (ATR) - simplified using price volatility
            if len(features_df) >= 14:
                price_changes = features_df['price'].diff().abs()
                features_df['atr'] = price_changes.rolling(window=14).mean()
            
            # Volume-based indicators (using price as proxy since volume might not be available)
            features_df['volume_proxy'] = features_df['price'].rolling(window=10).std()
            
            # Price momentum indicators
            for period in [1, 3, 5, 10]:
                if len(features_df) > period:
                    features_df[f'momentum_{period}'] = features_df['price'].pct_change(period)
            
            # Volatility indicators
            for period in [10, 20]:
                if len(features_df) >= period:
                    features_df[f'volatility_{period}'] = features_df['returns'].rolling(window=period).std()
            
            # Support and Resistance levels
            if len(features_df) >= 20:
                features_df['resistance'] = features_df['price'].rolling(window=20).max()
                features_df['support'] = features_df['price'].rolling(window=20).min()
                features_df['price_position'] = (features_df['price'] - features_df['support']) / (features_df['resistance'] - features_df['support'] + 1e-8)
            
            # Trend strength
            if len(features_df) >= 10:
                for window in [5, 10, 20]:
                    if len(features_df) >= window:
                        features_df[f'trend_strength_{window}'] = features_df['price'].rolling(window=window).apply(
                            lambda x: np.corrcoef(range(len(x)), x)[0, 1] if len(x) > 1 and not np.isnan(x).any() else 0
                        )
            
            # Fractal patterns (simplified)
            if len(features_df) >= 5:
                features_df['local_high'] = (features_df['price'].shift(2) > features_df['price'].shift(1)) & \
                                           (features_df['price'].shift(2) > features_df['price'].shift(3)) & \
                                           (features_df['price'].shift(2) > features_df['price'].shift(4)) & \
                                           (features_df['price'].shift(2) > features_df['price'])
                features_df['local_low'] = (features_df['price'].shift(2) < features_df['price'].shift(1)) & \
                                          (features_df['price'].shift(2) < features_df['price'].shift(3)) & \
                                          (features_df['price'].shift(2) < features_df['price'].shift(4)) & \
                                          (features_df['price'].shift(2) < features_df['price'])
            
            # Fill NaN values
            features_df = features_df.ffill().fillna(0)
            
            # Replace infinite values
            features_df = features_df.replace([np.inf, -np.inf], 0)
            
            return features_df
            
        except Exception as e:
            print(f"Error preparing advanced features: {e}")
            return pd.DataFrame()
    
    def _train_models(self, features_df):
        """
        Train LSTM and Random Forest models
        """
        try:
            # Validate input data
            if features_df is None or features_df.empty or len(features_df) < 50:
                self.model_trained = False
                return
            
            # Check if price column exists
            if 'price' not in features_df.columns:
                self.model_trained = False
                return
            
            # Select features for training
            feature_cols = [col for col in features_df.columns if col not in ['timestamp', 'price'] and not col.startswith('local_')]
            
            # Remove any remaining non-numeric columns
            numeric_cols = []
            for col in feature_cols:
                if col in features_df.columns and features_df[col].dtype in [np.float64, np.float32, np.int64, np.int32]:
                    # Additional check for empty columns
                    if not features_df[col].empty and not features_df[col].isnull().all():
                        numeric_cols.append(col)
            
            if len(numeric_cols) < 5:
                self.model_trained = False
                return
            
            self.feature_columns = numeric_cols
            X = features_df[numeric_cols].fillna(0).replace([np.inf, -np.inf], 0)
            
            # Create target variable with better error handling
            try:
                if 'price' not in features_df.columns or features_df['price'].empty:
                    self.model_trained = False
                    return
                y = features_df['price'].shift(-1)
                if y.empty or y.isnull().all():
                    self.model_trained = False
                    return
                y = y.ffill()  # Forward fill NaN values
                if y.empty or y.isnull().all():
                    self.model_trained = False
                    return
            except Exception:
                self.model_trained = False
                return
            
            # Validate X and y before proceeding
            if X.empty or y.empty:
                self.model_trained = False
                return
            
            # Remove the last row as it doesn't have a target
            try:
                X = X[:-1]
                y = y[:-1]
            except (IndexError, TypeError):
                self.model_trained = False
                return
            
            if len(X) < 30 or len(y) < 30:
                self.model_trained = False
                return
            
            # Train Random Forest with validation
            try:
                # Convert to numpy arrays to prevent pandas indexing issues
                X_array = X.values if hasattr(X, 'values') else np.array(X)
                y_array = y.values if hasattr(y, 'values') else np.array(y)
                
                # Validate shapes
                if X_array.shape[0] != y_array.shape[0]:
                    print(f"Shape mismatch: X({X_array.shape}) vs y({y_array.shape})")
                    self.model_trained = False
                    return
                
                self.rf_model = RandomForestRegressor(
                    n_estimators=50,  # Reduced for faster training
                    max_depth=8,     # Reduced complexity
                    random_state=42,
                    n_jobs=1        # Single thread to avoid issues
                )
                self.rf_model.fit(X_array, y_array)
            except Exception as e:
                print(f"Error training Random Forest: {e}")
                self.model_trained = False
                return
            
            # Prepare data for LSTM with validation
            try:
                scaler = MinMaxScaler()
                X_scaled = scaler.fit_transform(X)
                self.scalers['features'] = scaler
            except Exception as e:
                print(f"Error scaling data: {e}")
                self.model_trained = True  # RF only
                return
            
            # Create sequences for LSTM with validation
            try:
                sequence_length = min(10, len(X_scaled) // 3)
                if sequence_length < 1:
                    self.model_trained = True  # RF only
                    return
                
                X_lstm, y_lstm = self._create_sequences(X_scaled, y.values, sequence_length)
                
                if X_lstm is None or y_lstm is None or len(X_lstm) < 10:
                    self.model_trained = True  # RF only
                    return
            except Exception as e:
                print(f"Error creating sequences: {e}")
                self.model_trained = True  # RF only
                return
            
            # Build and train LSTM model with comprehensive error handling
            if TENSORFLOW_AVAILABLE:
                try:
                    # Clear any existing TensorFlow/Keras state
                    if tf is not None and hasattr(tf, 'keras'):
                        tf.keras.backend.clear_session()
                    
                    # Create LSTM model with explicit error handling for each layer
                    if Sequential is not None:
                        self.lstm_model = Sequential()
                    
                        # Add layers one by one with individual error handling
                        if LSTM is not None and Dropout is not None and Dense is not None and self.lstm_model is not None:
                            self.lstm_model.add(LSTM(
                                50, 
                                return_sequences=True, 
                                input_shape=(sequence_length, len(numeric_cols)),
                                name='lstm_1'
                            ))
                            self.lstm_model.add(Dropout(0.2, name='dropout_1'))
                            self.lstm_model.add(LSTM(50, return_sequences=False, name='lstm_2'))
                            self.lstm_model.add(Dropout(0.2, name='dropout_2'))
                            self.lstm_model.add(Dense(25, name='dense_1'))
                            self.lstm_model.add(Dense(1, name='dense_output'))
                    
                            # Compile model
                            if self.lstm_model is not None:
                                self.lstm_model.compile(optimizer='adam', loss='mse')
                                
                                # Train LSTM with minimal epochs to avoid long training time
                                self.lstm_model.fit(
                                    X_lstm, y_lstm, 
                                    epochs=5, 
                                    batch_size=32, 
                                    verbose=0, 
                                    validation_split=0.2
                                )
                    
                except Exception as lstm_error:
                    print(f"LSTM model creation/training failed: {lstm_error}")
                    print("Continuing with Random Forest only...")
                    self.lstm_model = None
                    # Clear any partial TensorFlow state
                    try:
                        if tf is not None and hasattr(tf, 'keras'):
                            tf.keras.backend.clear_session()
                    except Exception:
                        pass
            
            self.model_trained = True
            
        except Exception as e:
            import traceback
            print(f"Error training models: {e}")
            print(f"Full traceback: {traceback.format_exc()}")
            # Even if there are errors, we might still have Random Forest trained
            if hasattr(self, 'rf_model') and self.rf_model is not None:
                print("Continuing with Random Forest model only")
                self.model_trained = True
            else:
                self.model_trained = False
    
    def _create_sequences(self, X, y, sequence_length):
        """Create sequences for LSTM training with validation"""
        try:
            if X is None or y is None:
                return None, None
            if len(X) < sequence_length + 1 or len(y) < sequence_length + 1:
                return None, None
            
            X_seq, y_seq = [], []
            for i in range(sequence_length, len(X)):
                try:
                    X_seq.append(X[i-sequence_length:i])
                    y_seq.append(y[i])
                except IndexError:
                    break
            
            if len(X_seq) == 0 or len(y_seq) == 0:
                return None, None
                
            return np.array(X_seq), np.array(y_seq)
        except Exception:
            return None, None
    
    def _predict_with_ensemble(self, features_df, interval):
        """
        Make predictions using ensemble of models
        """
        try:
            if not self.model_trained or len(features_df) < 10:
                return {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5}
            
            # Get latest features
            latest_features = features_df[self.feature_columns].fillna(0).replace([np.inf, -np.inf], 0)
            latest_row = latest_features.iloc[-1:].values
            
            predictions = []
            current_price = features_df['price'].iloc[-1]
            
            # Random Forest prediction
            if self.rf_model is not None:
                try:
                    rf_pred = self.rf_model.predict(latest_row)[0]
                    rf_direction = 1 if rf_pred > current_price else -1 if rf_pred < current_price * 0.99 else 0
                    predictions.append(rf_direction)
                except Exception:
                    pass
            
            # LSTM prediction
            if TENSORFLOW_AVAILABLE and self.lstm_model is not None and 'features' in self.scalers:
                try:
                    sequence_length = min(10, len(latest_features) // 3)
                    if len(latest_features) >= sequence_length:
                        X_scaled = self.scalers['features'].transform(latest_features.tail(sequence_length))
                        X_lstm = X_scaled.reshape(1, sequence_length, len(self.feature_columns))
                        lstm_pred = self.lstm_model.predict(X_lstm, verbose=0)[0][0]
                        lstm_direction = 1 if lstm_pred > current_price else -1 if lstm_pred < current_price * 0.99 else 0
                        predictions.append(lstm_direction)
                except Exception:
                    pass
            
            # Technical analysis prediction
            ta_prediction = self._technical_analysis_prediction(features_df)
            predictions.append(ta_prediction)
            
            # Advanced momentum prediction
            momentum_pred = self._advanced_momentum_prediction(features_df)
            predictions.append(momentum_pred)
            
            # Bollinger Bands prediction
            bb_pred = self._bollinger_bands_prediction(features_df)
            predictions.append(bb_pred)
            
            # RSI prediction
            rsi_pred = self._rsi_prediction(features_df)
            predictions.append(rsi_pred)
            
            # MACD prediction
            macd_pred = self._macd_prediction(features_df)
            predictions.append(macd_pred)
            
            # Combine all predictions
            direction, confidence, probability = self._combine_advanced_predictions(predictions, interval)
            
            return {
                'direction': direction,
                'confidence': confidence,
                'probability': probability
            }
            
        except Exception as e:
            print(f"Error in ensemble prediction: {e}")
            return {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5}
    
    def _technical_analysis_prediction(self, df):
        """Enhanced technical analysis prediction"""
        try:
            latest = df.iloc[-1]
            score = 0
            factors = 0
            
            # Multiple MA analysis
            for period in [10, 20, 50]:
                ma_col = f'price_to_ma_{period}'
                if ma_col in latest and not np.isnan(latest[ma_col]):
                    if latest[ma_col] > 1.01:
                        score += 1
                    elif latest[ma_col] < 0.99:
                        score -= 1
                    factors += 1
            
            # Trend strength analysis
            for window in [5, 10, 20]:
                trend_col = f'trend_strength_{window}'
                if trend_col in latest and not np.isnan(latest[trend_col]):
                    if latest[trend_col] > 0.3:
                        score += 1
                    elif latest[trend_col] < -0.3:
                        score -= 1
                    factors += 1
            
            return score / max(factors, 1)
            
        except Exception:
            return 0
    
    def _advanced_momentum_prediction(self, df):
        """Advanced momentum analysis"""
        try:
            score = 0
            factors = 0
            
            for period in [1, 3, 5, 10]:
                mom_col = f'momentum_{period}'
                if mom_col in df.columns and len(df) > 0:
                    latest_momentum = df[mom_col].iloc[-1]
                    if not np.isnan(latest_momentum):
                        if latest_momentum > 0.01:
                            score += 1
                        elif latest_momentum < -0.01:
                            score -= 1
                        factors += 1
            
            return score / max(factors, 1)
            
        except Exception:
            return 0
    
    def _bollinger_bands_prediction(self, df):
        """Bollinger Bands prediction"""
        try:
            if 'bb_position' not in df.columns:
                return 0
            
            latest_position = df['bb_position'].iloc[-1]
            
            if np.isnan(latest_position):
                return 0
            
            if latest_position < 0.2:  # Near lower band
                return 1  # Potential reversal up
            elif latest_position > 0.8:  # Near upper band
                return -1  # Potential reversal down
            else:
                return 0
                
        except Exception:
            return 0
    
    def _rsi_prediction(self, df):
        """RSI-based prediction"""
        try:
            if 'rsi_14' not in df.columns:
                return 0
            
            latest_rsi = df['rsi_14'].iloc[-1]
            
            if np.isnan(latest_rsi):
                return 0
            
            if latest_rsi < 30:  # Oversold
                return 1
            elif latest_rsi > 70:  # Overbought
                return -1
            else:
                return 0
                
        except Exception:
            return 0
    
    def _macd_prediction(self, df):
        """MACD-based prediction"""
        try:
            if 'macd' not in df.columns or 'macd_signal' not in df.columns:
                return 0
            
            if len(df) < 2:
                return 0
            
            current_macd = df['macd'].iloc[-1]
            current_signal = df['macd_signal'].iloc[-1]
            prev_macd = df['macd'].iloc[-2]
            prev_signal = df['macd_signal'].iloc[-2]
            
            if any(np.isnan([current_macd, current_signal, prev_macd, prev_signal])):
                return 0
            
            # MACD crossover
            if prev_macd <= prev_signal and current_macd > current_signal:
                return 1  # Bullish crossover
            elif prev_macd >= prev_signal and current_macd < current_signal:
                return -1  # Bearish crossover
            else:
                return 0
                
        except Exception:
            return 0
    
    def _combine_advanced_predictions(self, predictions, interval):
        """Combine all predictions with advanced weighting"""
        try:
            if not predictions:
                return 'sideways', 50.0, 0.5
            
            # Weight different prediction sources
            weights = [2.0, 2.0, 1.0, 1.2, 1.1, 1.0, 1.1]  # ML models get higher weight
            
            if len(weights) > len(predictions):
                weights = weights[:len(predictions)]
            elif len(predictions) > len(weights):
                weights.extend([1.0] * (len(predictions) - len(weights)))
            
            # Calculate weighted average
            weighted_sum = sum(p * w for p, w in zip(predictions, weights))
            total_weight = sum(weights)
            
            avg_prediction = weighted_sum / total_weight
            
            # Adjust confidence based on interval (shorter intervals are less predictable)
            interval_multipliers = {'5min': 0.8, '10min': 0.9, '30min': 1.0}
            interval_mult = interval_multipliers.get(interval, 1.0)
            
            # Determine direction and confidence
            if avg_prediction > 0.15:
                direction = 'up'
                confidence = min(90.0, (50.0 + abs(avg_prediction) * 50) * interval_mult)
                probability = min(0.9, 0.5 + abs(avg_prediction) * 0.4)
            elif avg_prediction < -0.15:
                direction = 'down'
                confidence = min(90.0, (50.0 + abs(avg_prediction) * 50) * interval_mult)
                probability = max(0.1, 0.5 - abs(avg_prediction) * 0.4)
            else:
                direction = 'sideways'
                confidence = 50.0 + abs(avg_prediction) * 20 * interval_mult
                probability = 0.5
            
            return direction, confidence, probability
            
        except Exception as e:
            print(f"Error combining predictions: {e}")
            return 'sideways', 50.0, 0.5
    
    def _default_predictions(self):
        """Return default predictions when models can't be used"""
        return {
            '5min': {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5},
            '10min': {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5},
            '30min': {'direction': 'sideways', 'confidence': 50.0, 'probability': 0.5}
        }

    def get_model_performance_metrics(self):
        """Get performance metrics for the trained models"""
        try:
            metrics = {}
            
            if self.rf_model is not None:
                metrics['random_forest'] = {
                    'feature_importance': dict(zip(self.feature_columns, self.rf_model.feature_importances_)) if hasattr(self.rf_model, 'feature_importances_') else {},
                    'model_type': 'Random Forest'
                }
            
            if self.lstm_model is not None:
                metrics['lstm'] = {
                    'model_type': 'LSTM Neural Network',
                    'layers': len(self.lstm_model.layers),
                    'parameters': self.lstm_model.count_params()
                }
            
            metrics['trained'] = self.model_trained
            return metrics
            
        except Exception as e:
            print(f"Error getting model metrics: {e}")
            return {'trained': False}
    
    def _calculate_rsi_manual(self, prices, period=14):
        """Manual RSI calculation"""
        try:
            delta = prices.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            
            return rsi
            
        except Exception:
            return prices * 0
    
    def _calculate_bollinger_bands_manual(self, df, window=20, std_dev=2):
        """Manual Bollinger Bands calculation"""
        try:
            df['bb_middle'] = df['price'].rolling(window=window).mean()
            std = df['price'].rolling(window=window).std()
            df['bb_upper'] = df['bb_middle'] + (std * std_dev)
            df['bb_lower'] = df['bb_middle'] - (std * std_dev)
            return df
        except Exception:
            return df