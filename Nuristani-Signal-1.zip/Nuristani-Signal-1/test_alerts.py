#!/usr/bin/env python3
"""
Test script to verify the alert system is working correctly
"""

from alert_system import AlertSystem
from datetime import datetime
import json

def test_alert_system():
    print("Testing Alert System...")
    
    # Initialize alert system
    alert_system = AlertSystem()
    
    # Check status
    status = alert_system.get_alert_system_status()
    print(f"Alert system status: {json.dumps(status, indent=2)}")
    
    # Test high-confidence predictions that should trigger alerts
    test_predictions = {
        '5min': {
            'direction': 'up',
            'confidence': 85.5,  # High confidence
            'probability': 0.82   # High probability
        },
        '10min': {
            'direction': 'down',
            'confidence': 78.3,  # High confidence
            'probability': 0.25   # Low probability (strong down signal)
        },
        '30min': {
            'direction': 'sideways',
            'confidence': 90.0,   # High confidence but sideways (should not alert)
            'probability': 0.55
        }
    }
    
    print("\nTesting predictions:")
    for interval, pred in test_predictions.items():
        should_alert = alert_system.should_send_alert(pred)
        print(f"{interval}: {pred['direction']} @ {pred['confidence']:.1f}% confidence -> Alert: {should_alert}")
    
    # Test alert processing
    test_alert_settings = {
        'enabled': True,
        'email_enabled': False,  # Will use demo mode
        'email_address': 'test@example.com'
    }
    
    print(f"\nProcessing alerts with settings: {test_alert_settings}")
    
    results = alert_system.process_prediction_alerts(
        crypto_symbol='bitcoin',
        crypto_name='Bitcoin (BTC)',
        predictions=test_predictions,
        current_price=65000.00,
        alert_settings=test_alert_settings
    )
    
    print(f"Alert results: {json.dumps(results, indent=2)}")
    
    # Check recent alerts
    recent_alerts = alert_system.get_recent_alerts(limit=5)
    print(f"\nRecent alerts count: {len(recent_alerts)}")
    
    if recent_alerts:
        print("Most recent alert:")
        latest_alert = recent_alerts[-1]
        print(f"- Crypto: {latest_alert['crypto_name']}")
        print(f"- Interval: {latest_alert['time_interval']}")
        print(f"- Direction: {latest_alert['prediction']['direction']}")
        print(f"- Confidence: {latest_alert['prediction']['confidence']:.1f}%")
        print(f"- Subject: {latest_alert['message']['subject']}")

if __name__ == "__main__":
    test_alert_system()