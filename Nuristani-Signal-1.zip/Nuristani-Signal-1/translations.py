# -*- coding: utf-8 -*-
"""
Multi-language support for Signal Nooristani Platform
Supports: English, Persian (Farsi), and Pashto
"""

# Language configurations
LANGUAGES = {
    'en': {
        'name': 'English',
        'flag': '🇺🇸',
        'rtl': False
    },
    'fa': {
        'name': 'فارسی',
        'flag': '🇮🇷', 
        'rtl': True
    },
    'ps': {
        'name': 'پښتو',
        'flag': '🇦🇫',
        'rtl': True
    }
}

# Translation dictionaries
TRANSLATIONS = {
    # General UI
    'app_title': {
        'en': 'Signal Nooristani - سیگنال نورستانی',
        'fa': 'سیگنال نورستانی - Signal Nooristani',
        'ps': 'سیګنال نورستانی - Signal Nooristani'
    },
    'sidebar_title': {
        'en': '🚀 Signal Nooristani',
        'fa': '🚀 سیگنال نورستانی',
        'ps': '🚀 سیګنال نورستانی'
    },
    'select_crypto': {
        'en': 'Select Cryptocurrency',
        'fa': 'انتخاب رمزارز',
        'ps': 'کریپټو کرنسی وټاکئ'
    },
    'language_selector': {
        'en': 'Language / زبان / ژبه',
        'fa': 'زبان / Language / ژبه', 
        'ps': 'ژبه / Language / زبان'
    },
    
    # Authentication
    'authentication': {
        'en': 'Authentication',
        'fa': 'احراز هویت',
        'ps': 'د پیژندنې تصدیق'
    },
    'login_title': {
        'en': 'Login to Signal Nooristani',
        'fa': 'ورود به سیگنال نورستانی',
        'ps': 'سیګنال نورستانی ته ننوتل'
    },
    'register_title': {
        'en': 'Register for Signal Nooristani',
        'fa': 'ثبت نام در سیگنال نورستانی',
        'ps': 'د سیګنال نورستانی لپاره ثبت نامه'
    },
    'email_label': {
        'en': 'Email Address',
        'fa': 'آدرس ایمیل',
        'ps': 'د بریښنالیک پته'
    },
    'password_label': {
        'en': 'Password',
        'fa': 'رمز عبور',
        'ps': 'پټ نوم'
    },
    'full_name_label': {
        'en': 'Full Name',
        'fa': 'نام کامل',
        'ps': 'بشپړ نوم'
    },
    'confirm_password_label': {
        'en': 'Confirm Password',
        'fa': 'تایید رمز عبور',
        'ps': 'د پټ نوم تاییدول'
    },
    'preferred_language_label': {
        'en': 'Preferred Language',
        'fa': 'زبان ترجیحی',
        'ps': 'غوره ژبه'
    },
    'login_button': {
        'en': '🔑 Login',
        'fa': '🔑 ورود',
        'ps': '🔑 ننوتل'
    },
    'register_button': {
        'en': '📝 Register',
        'fa': '📝 ثبت نام',
        'ps': '📝 ثبت نامه'
    },
    'logout_button': {
        'en': '🔓 Logout',
        'fa': '🔓 خروج',
        'ps': '🔓 وتل'
    },
    'register_link': {
        'en': 'Need an account?',
        'fa': 'نیاز به حساب کاربری؟',
        'ps': 'حساب ته اړتیا لرئ؟'
    },
    'back_to_login': {
        'en': 'Back to Login',
        'fa': 'بازگشت به ورود',
        'ps': 'ورود ته بیرته'
    },
    'password_placeholder': {
        'en': 'Enter your password',
        'fa': 'رمز عبور خود را وارد کنید',
        'ps': 'خپل پټ نوم وليکئ'
    },
    'full_name_placeholder': {
        'en': 'Enter your full name',
        'fa': 'نام کامل خود را وارد کنید',
        'ps': 'خپل بشپړ نوم وليکئ'
    },
    'confirm_password_placeholder': {
        'en': 'Confirm your password',
        'fa': 'رمز عبور را تایید کنید',
        'ps': 'خپل پټ نوم تاییدول وکړئ'
    },
    'password_requirements': {
        'en': 'At least 8 characters, with letters and numbers',
        'fa': 'حداقل ۸ کاراکتر، شامل حروف و اعداد',
        'ps': 'لږترلږه ۸ کارکترونه، د حروفو او شمیرو سره'
    },
    'login_success': {
        'en': '✅ Login successful! Welcome to Signal Nooristani',
        'fa': '✅ ورود موفقیت آمیز! به سیگنال نورستانی خوش آمدید',
        'ps': '✅ بریالۍ ننوتل! سیګنال نورستانی ته ښه راغلاست'
    },
    'login_error': {
        'en': 'Login failed',
        'fa': 'ورود ناموفق',
        'ps': 'ننوتل ناکامه'
    },
    'registration_success': {
        'en': '✅ Registration successful! You can now login',
        'fa': '✅ ثبت نام موفقیت آمیز! اکنون می‌توانید وارد شوید',
        'ps': '✅ بریالۍ ثبت نامه! اوس تاسو کولی شئ ننوزئ'
    },
    'registration_error': {
        'en': 'Registration failed',
        'fa': 'ثبت نام ناموفق',
        'ps': 'ثبت نامه ناکامه'
    },
    'logout_success': {
        'en': '✅ Logged out successfully',
        'fa': '✅ خروج موفقیت آمیز',
        'ps': '✅ بریالۍ وتل'
    },
    'logout_error': {
        'en': 'Logout failed',
        'fa': 'خروج ناموفق',
        'ps': 'وتل ناکامه'
    },
    'fill_all_fields': {
        'en': 'Please fill in all required fields',
        'fa': 'لطفاً تمام فیلدهای ضروری را پر کنید',
        'ps': 'مهرباني وکړئ ټول اړین ساحې ډک کړئ'
    },
    'password_mismatch': {
        'en': 'Passwords do not match',
        'fa': 'رمزهای عبور مطابقت ندارند',
        'ps': 'پټ نومونه سره نه ورته کیږي'
    },
    'authentication_required': {
        'en': 'Authentication Required',
        'fa': 'احراز هویت ضروری',
        'ps': 'د پیژندنې تصدیق اړین'
    },
    'login_to_continue': {
        'en': 'Please login to continue using Signal Nooristani',
        'fa': 'لطفاً برای ادامه استفاده از سیگنال نورستانی وارد شوید',
        'ps': 'مهرباني وکړئ د سیګنال نورستانی د کارولو دوام لپاره ننوزئ'
    },
    'login_tab': {
        'en': 'Login',
        'fa': 'ورود',
        'ps': 'ننوتل'
    },
    'register_tab': {
        'en': 'Register',
        'fa': 'ثبت نام',
        'ps': 'ثبت نامه'
    },
    'user_dashboard': {
        'en': 'User Dashboard',
        'fa': 'داشبورد کاربر',
        'ps': 'د کاروونکي ډیشبورډ'
    },
    'welcome_message': {
        'en': 'Welcome,',
        'fa': 'خوش آمدید،',
        'ps': 'ښه راغلاست،'
    },
    'logged_in_as': {
        'en': 'Logged in as',
        'fa': 'وارد شده به عنوان',
        'ps': 'ننوتل د'
    },
    'user_preferences': {
        'en': 'User Preferences',
        'fa': 'تنظیمات کاربر',
        'ps': 'د کاروونکي تنظیمات'
    },
    'email_notifications_label': {
        'en': 'Email Notifications',
        'fa': 'اطلاع‌رسانی ایمیل',
        'ps': 'د بریښنالیک خبرتیاوې'
    },
    'save_preferences': {
        'en': 'Save Preferences',
        'fa': 'ذخیره تنظیمات',
        'ps': 'تنظیمات خوندي کړئ'
    },
    'preferences_saved': {
        'en': '✅ Preferences saved successfully',
        'fa': '✅ تنظیمات با موفقیت ذخیره شد',
        'ps': '✅ تنظیمات بریالۍ خوندي شول'
    },
    'preferences_error': {
        'en': 'Error saving preferences',
        'fa': 'خطا در ذخیره تنظیمات',
        'ps': 'د تنظیماتو خوندي کولو کې ستونزه'
    },
    'login_required_message': {
        'en': 'Please login to access all features of Signal Nooristani',
        'fa': 'لطفاً برای دسترسی به همه امکانات سیگنال نورستانی وارد شوید',
        'ps': 'مهرباني وکړئ د سیګنال نورستانی ټولو ځانګړتیاوو ته د لاسرسي لپاره ننوزئ'
    },
    
    # Controls and Settings
    'auto_refresh': {
        'en': 'Auto Refresh (30s)',
        'fa': 'بروزرسانی خودکار (۳۰ثانیه)',
        'ps': 'اتومات تازه کول (۳۰ ثانیه)'
    },
    'refresh_data': {
        'en': '🔄 Refresh Data',
        'fa': '🔄 بروزرسانی داده‌ها',
        'ps': '🔄 معلومات تازه کړئ'
    },
    'refresh_interval': {
        'en': 'Refresh Interval (seconds)',
        'fa': 'فاصله بروزرسانی (ثانیه)',
        'ps': 'د تازه کولو موده (ثانیه)'
    },
    'use_advanced_ml': {
        'en': '🤖 Use Advanced ML Predictions',
        'fa': '🤖 استفاده از پیش‌بینی ML پیشرفته',
        'ps': '🤖 د پرمختللي ML وړاندوینې کارول'
    },
    'advanced_ml_help': {
        'en': 'Use LSTM and Random Forest models for enhanced predictions',
        'fa': 'استفاده از مدل‌های LSTM و Random Forest برای پیش‌بینی بهتر',
        'ps': 'د ښه وړاندوینو لپاره د LSTM او Random Forest ماډلونه کاروئ'
    },
    'show_portfolio': {
        'en': '📊 Show Portfolio & Analytics',
        'fa': '📊 نمایش پرتفوی و تحلیل‌ها',
        'ps': '📊 د پورټفولیو او تحلیلاتو ښودنه'
    },
    'portfolio_help': {
        'en': 'Track predictions and portfolio performance',
        'fa': 'رهگیری پیش‌بینی‌ها و عملکرد پرتفوی',
        'ps': 'د وړاندوینو او پورټفولیو فعالیت تعقیبول'
    },
    
    # Alert Settings
    'alert_settings': {
        'en': '🚨 Alert Settings',
        'fa': '🚨 تنظیمات هشدار',
        'ps': '🚨 د خبرداری تنظیمات'
    },
    'enable_alerts': {
        'en': 'Enable High-Confidence Alerts',
        'fa': 'فعال‌سازی هشدارهای با اطمینان بالا',
        'ps': 'د لوړ اعتماد وړ خبرداری فعالول'
    },
    'alerts_help': {
        'en': 'Get notified when predictions have >75% confidence',
        'fa': 'زمانی که پیش‌بینی‌ها بیش از ۷۵٪ اطمینان دارند، آگاه شوید',
        'ps': 'کله چې وړاندوینې د ۷۵٪ څخه زیاته اعتماد لري خبر شئ'
    },
    'email_alerts': {
        'en': '📧 Email Alerts',
        'fa': '📧 هشدارهای ایمیل',
        'ps': '📧 د بریښنالیک خبرداری'
    },
    'email_address': {
        'en': 'Email Address',
        'fa': 'آدرس ایمیل',
        'ps': 'د بریښنالیک پته'
    },
    'email_placeholder': {
        'en': 'your@email.com',
        'fa': 'your@email.com',
        'ps': 'your@email.com'
    },
    
    # Platform Features
    'platform_features': {
        'en': '📊 Platform Features',
        'fa': '📊 ویژگی‌های پلتفرم',
        'ps': '📊 د پلیټفارم ځانګړتیاوې'
    },
    'realtime_data': {
        'en': '- Real-time price data',
        'fa': '- داده‌های قیمت در زمان واقعی',
        'ps': '- د حقیقي وخت د قیمتونو معلومات'
    },
    'advanced_predictions': {
        'en': '- Advanced ML predictions (LSTM, Random Forest)',
        'fa': '- پیش‌بینی‌های ML پیشرفته (LSTM، Random Forest)',
        'ps': '- پرمختللي ML وړاندوینې (LSTM، Random Forest)'
    },
    'technical_analysis': {
        'en': '- Comprehensive technical analysis',
        'fa': '- تحلیل فنی جامع',
        'ps': '- د بشپړ تخنیکي تحلیل'
    },
    'interactive_charts': {
        'en': '- Interactive charts',
        'fa': '- نمودارهای تعاملی',
        'ps': '- متقابل چارټونه'
    },
    'confidence_scores': {
        'en': '- Confidence scores & probabilities',
        'fa': '- امتیازات اطمینان و احتمالات',
        'ps': '- د اعتماد نمرې او احتمالات'
    },
    
    # Price Overview
    'current_price': {
        'en': '💰 Current Price',
        'fa': '💰 قیمت فعلی',
        'ps': '💰 اوسنی قیمت'
    },
    '24h_change': {
        'en': '📊 24h Change',
        'fa': '📊 تغییر ۲۴ ساعته',
        'ps': '📊 د ۲۴ ساعتونو بدلون'
    },
    'market_cap': {
        'en': '🏦 Market Cap',
        'fa': '🏦 ارزش بازار',
        'ps': '🏦 د بازار ارزښت'
    },
    '24h_volume': {
        'en': '📈 24h Volume',
        'fa': '📈 حجم ۲۴ ساعته',
        'ps': '📈 د ۲۴ ساعتونو حجم'
    },
    'not_available': {
        'en': 'N/A',
        'fa': 'موجود نیست',
        'ps': 'نشته'
    },
    
    # Cryptocurrency Names
    'crypto_names': {
        'bitcoin': {
            'en': 'Bitcoin (BTC)',
            'fa': 'بیت کوین (BTC)',
            'ps': 'بیټکوین (BTC)'
        },
        'ethereum': {
            'en': 'Ethereum (ETH)',
            'fa': 'اتریوم (ETH)',
            'ps': 'ایتریوم (ETH)'
        },
        'binancecoin': {
            'en': 'Binance Coin (BNB)',
            'fa': 'بایننس کوین (BNB)',
            'ps': 'بایننس کوین (BNB)'
        },
        'cardano': {
            'en': 'Cardano (ADA)',
            'fa': 'کاردانو (ADA)',
            'ps': 'کارډانو (ADA)'
        },
        'solana': {
            'en': 'Solana (SOL)',
            'fa': 'سولانا (SOL)',
            'ps': 'سولانا (SOL)'
        },
        'polkadot': {
            'en': 'Polkadot (DOT)',
            'fa': 'پولکادات (DOT)',
            'ps': 'پولکاډاټ (DOT)'
        },
        'chainlink': {
            'en': 'Chainlink (LINK)',
            'fa': 'چین لینک (LINK)',
            'ps': 'چینلینک (LINK)'
        },
        'litecoin': {
            'en': 'Litecoin (LTC)',
            'fa': 'لایت کوین (LTC)',
            'ps': 'لایټکوین (LTC)'
        },
        'polygon-matic-network': {
            'en': 'Polygon (MATIC)',
            'fa': 'پولیگان (MATIC)',
            'ps': 'پولیګون (MATIC)'
        },
        'avalanche-2': {
            'en': 'Avalanche (AVAX)',
            'fa': 'آولانچ (AVAX)',
            'ps': 'اولانچ (AVAX)'
        }
    },
    
    # Predictions
    'price_predictions': {
        'en': '🔮 Price Predictions',
        'fa': '🔮 پیش‌بینی قیمت',
        'ps': '🔮 د قیمتونو وړاندوینې'
    },
    '5min_prediction': {
        'en': '5 Minute Prediction',
        'fa': 'پیش‌بینی ۵ دقیقه‌ای',
        'ps': 'د ۵ دقیقو وړاندوینه'
    },
    '10min_prediction': {
        'en': '10 Minute Prediction',
        'fa': 'پیش‌بینی ۱۰ دقیقه‌ای',
        'ps': 'د ۱۰ دقیقو وړاندوینه'
    },
    '30min_prediction': {
        'en': '30 Minute Prediction',
        'fa': 'پیش‌بینی ۳۰ دقیقه‌ای',
        'ps': 'د ۳۰ دقیقو وړاندوینه'
    },
    'confidence': {
        'en': 'Confidence',
        'fa': 'اطمینان',
        'ps': 'اعتماد'
    },
    'probability': {
        'en': 'Probability',
        'fa': 'احتمال',
        'ps': 'احتمال'
    },
    
    # Prediction Directions
    'directions': {
        'up': {
            'en': 'UP',
            'fa': 'صعودی',
            'ps': 'پورته'
        },
        'down': {
            'en': 'DOWN',
            'fa': 'نزولی',
            'ps': 'ښکته'
        },
        'sideways': {
            'en': 'SIDEWAYS',
            'fa': 'بغلی',
            'ps': 'څنګه'
        },
        'unknown': {
            'en': 'Unknown',
            'fa': 'نامعلوم',
            'ps': 'نامعلوم'
        }
    },
    
    # Advanced ML Information
    'advanced_ml_info': {
        'en': '🤖 Advanced ML Model Information',
        'fa': '🤖 اطلاعات مدل ML پیشرفته',
        'ps': '🤖 د پرمختللي ML ماډل معلومات'
    },
    'random_forest_model': {
        'en': '🌲 **Random Forest Model**',
        'fa': '🌲 **مدل Random Forest**',
        'ps': '🌲 **د Random Forest ماډل**'
    },
    'lstm_neural_network': {
        'en': '🧠 **LSTM Neural Network**',
        'fa': '🧠 **شبکه عصبی LSTM**',
        'ps': '🧠 **د LSTM عصبي شبکه**'
    },
    'active_predictions': {
        'en': 'Active and providing predictions',
        'fa': 'فعال و ارائه پیش‌بینی',
        'ps': 'فعال او د وړاندوینو چمتو کول'
    },
    'top_features': {
        'en': '**Top Features:**',
        'fa': '**ویژگی‌های برتر:**',
        'ps': '**غوره ځانګړتیاوې:**'
    },
    'layers': {
        'en': 'Layers',
        'fa': 'لایه‌ها',
        'ps': 'پرتونه'
    },
    'parameters': {
        'en': 'Parameters',
        'fa': 'پارامترها',
        'ps': 'پیرامیټرونه'
    },
    'using_rf_only': {
        'en': 'Using Random Forest only',
        'fa': 'فقط از Random Forest استفاده می‌کند',
        'ps': 'یوازې د Random Forest کارول'
    },
    'models_training': {
        'en': '📊 Models are training with current data. Predictions will improve over time.',
        'fa': '📊 مدل‌ها با داده‌های فعلی آموزش می‌بینند. پیش‌بینی‌ها با گذشت زمان بهتر می‌شوند.',
        'ps': '📊 ماډلونه د اوسنیو معلوماتو سره روزل کیږي. وړاندوینې به د وخت په تیریدو سره ښه شي.'
    },
    
    # Alert History
    'alert_history_status': {
        'en': '🚨 Alert History & Status',
        'fa': '🚨 تاریخچه و وضعیت هشدارها',
        'ps': '🚨 د خبرداری تاریخ او حالت'
    },
    'email_configured': {
        'en': '📧 Email alerts configured',
        'fa': '📧 هشدارهای ایمیل پیکربندی شده',
        'ps': '📧 د بریښنالیک خبرداری تنظیم شوي'
    },
    'smtp_server': {
        'en': 'SMTP Server',
        'fa': 'سرور SMTP',
        'ps': 'SMTP سرور'
    },
    'email_demo_mode': {
        'en': '📧 Email alerts in demo mode',
        'fa': '📧 هشدارهای ایمیل در حالت نمایشی',
        'ps': '📧 د بریښنالیک خبرداری په ډمو حالت کې'
    },
    'email_config_help': {
        'en': 'Configure EMAIL_USERNAME and EMAIL_PASSWORD environment variables for real email alerts',
        'fa': 'برای هشدارهای ایمیل واقعی متغیرهای محیطی EMAIL_USERNAME و EMAIL_PASSWORD را پیکربندی کنید',
        'ps': 'د ریښتینو بریښنالیک خبرداریو لپاره د EMAIL_USERNAME او EMAIL_PASSWORD د چاپیریال متغیرات تنظیم کړئ'
    },
    'high_confidence_threshold': {
        'en': '🎯 High-confidence threshold',
        'fa': '🎯 آستانه اطمینان بالا',
        'ps': '🎯 د لوړ اعتماد کچه'
    },
    'alerts_enabled': {
        'en': '🟢 Alerts enabled',
        'fa': '🟢 هشدارها فعال',
        'ps': '🟢 خبرداری فعال'
    },
    'alerts_disabled': {
        'en': '🔴 Alerts disabled',
        'fa': '🔴 هشدارها غیرفعال',
        'ps': '🔴 خبرداری غیر فعال'
    },
    'email_disabled': {
        'en': '📧 Email alerts: Disabled',
        'fa': '📧 هشدارهای ایمیل: غیرفعال',
        'ps': '📧 د بریښنالیک خبرداری: غیر فعال'
    },
    'enable_sidebar_alerts': {
        'en': 'Enable alerts in the sidebar to get notifications',
        'fa': 'برای دریافت اعلان‌ها، هشدارها را در نوار کناری فعال کنید',
        'ps': 'د خبرداریو د ترلاسه کولو لپاره په څنګ پټه کې خبرداری فعال کړئ'
    },
    
    # Recent Alerts
    'recent_alerts': {
        'en': '📋 Recent Alerts (Last 5)',
        'fa': '📋 هشدارهای اخیر (۵ تای آخر)',
        'ps': '📋 وروستي خبرداری (وروستي ۵)'
    },
    'alert_number': {
        'en': '🔔 Alert',
        'fa': '🔔 هشدار',
        'ps': '🔔 خبرداری'
    },
    'prediction_label': {
        'en': 'Prediction',
        'fa': 'پیش‌بینی',
        'ps': 'وړاندوینه'
    },
    'price_at_time': {
        'en': 'Price at time',
        'fa': 'قیمت در آن زمان',
        'ps': 'په هغه وخت کې قیمت'
    },
    'time_label': {
        'en': 'Time',
        'fa': 'زمان',
        'ps': 'وخت'
    },
    'alert_subject': {
        'en': 'Alert Subject',
        'fa': 'موضوع هشدار',
        'ps': 'د خبرداری موضوع'
    },
    'no_recent_alerts': {
        'en': '📭 No recent alerts. High-confidence predictions (>75% confidence) will appear here when detected.',
        'fa': '📭 هشدار اخیری وجود ندارد. پیش‌بینی‌های با اطمینان بالا (>۷۵٪ اطمینان) هنگام شناسایی در اینجا ظاهر می‌شوند.',
        'ps': '📭 کوم وروستي خبرداری نشته. د لوړ اعتماد وړاندوینې (> ۷۵٪ اعتماد) به دلته څرګندې شي کله چې وموندل شي.'
    },
    'alert_triggers': {
        'en': '**Alert triggers:**',
        'fa': '**محرک‌های هشدار:**',
        'ps': '**د خبرداری پیل کونکي:**'
    },
    'confidence_gt_75': {
        'en': '• Confidence > 75%',
        'fa': '• اطمینان > ۷۵٪',
        'ps': '• اعتماد > ۷۵٪'
    },
    'direction_up_down': {
        'en': '• Direction: UP or DOWN (not sideways)',
        'fa': '• جهت: صعودی یا نزولی (نه بغلی)',
        'ps': '• لور: پورته یا ښکته (نه څنګه)'
    },
    'probability_range': {
        'en': '• Probability > 70% or < 30%',
        'fa': '• احتمال > ۷۰٪ یا < ۳۰٪',
        'ps': '• احتمال > ۷۰٪ یا < ۳۰٪'
    },
    
    # Charts and Technical Analysis
    'price_chart_7d': {
        'en': '📊 Price Chart (7 Days)',
        'fa': '📊 نمودار قیمت (۷ روز)',
        'ps': '📊 د قیمتونو چارټ (۷ ورځې)'
    },
    'price_history': {
        'en': 'Price History',
        'fa': 'تاریخچه قیمت',
        'ps': 'د قیمتونو تاریخ'
    },
    'time': {
        'en': 'Time',
        'fa': 'زمان',
        'ps': 'وخت'
    },
    'price_usd': {
        'en': 'Price (USD)',
        'fa': 'قیمت (دلار)',
        'ps': 'قیمت (دالر)'
    },
    'price': {
        'en': 'Price',
        'fa': 'قیمت',
        'ps': 'قیمت'
    },
    
    # Technical Indicators
    'technical_indicators': {
        'en': '🔧 Technical Indicators',
        'fa': '🔧 شاخص‌های فنی',
        'ps': '🔧 تخنیکي شاخصونه'
    },
    'moving_averages': {
        'en': '### Moving Averages',
        'fa': '### میانگین‌های متحرک',
        'ps': '### د حرکت میانګین'
    },
    'price_momentum': {
        'en': '### Price Momentum',
        'fa': '### حرکت قیمت',
        'ps': '### د قیمت حرکت'
    },
    'short_momentum': {
        'en': 'Short Momentum',
        'fa': 'حرکت کوتاه‌مدت',
        'ps': 'لنډ مهاله حرکت'
    },
    'medium_momentum': {
        'en': 'Medium Momentum',
        'fa': 'حرکت میان‌مدت',
        'ps': 'منځنۍ مودې حرکت'
    },
    
    # Data Loading and Status Messages
    'fetching_data': {
        'en': 'Fetching latest data for {crypto}...',
        'fa': 'دریافت آخرین داده‌ها برای {crypto}...',
        'ps': 'د {crypto} لپاره وروستي معلومات راوړل...'
    },
    'alerts_detected_demo': {
        'en': '🚨 {count} high-confidence alerts detected! (Demo mode - alerts saved locally)',
        'fa': '🚨 {count} هشدار با اطمینان بالا شناسایی شد! (حالت نمایشی - هشدارها محلی ذخیره شده)',
        'ps': '🚨 {count} د لوړ اعتماد خبرداری وموندل شو! (د ډمو حالت - خبرداری محلي ساتل شوي)'
    },
    'prediction_with_confidence': {
        'en': '{direction_emoji} **{interval}** prediction: {direction} with {confidence:.1f}% confidence',
        'fa': '{direction_emoji} **{interval}** پیش‌بینی: {direction} با {confidence:.1f}٪ اطمینان',
        'ps': '{direction_emoji} **{interval}** وړاندوینه: {direction} د {confidence:.1f}٪ اعتماد سره'
    },
    'email_alerts_sent': {
        'en': '📧 Sent {count} email alerts for high-confidence predictions!',
        'fa': '📧 {count} هشدار ایمیل برای پیش‌بینی‌های با اطمینان بالا ارسال شد!',
        'ps': '📧 د لوړ اعتماد وړاندوینو لپاره {count} بریښنالیک خبرداری واستول شو!'
    },
    'sms_alerts_sent': {
        'en': '📱 Sent {count} SMS alerts!',
        'fa': '📱 {count} هشدار پیامک ارسال شد!',
        'ps': '📱 {count} د پیغام خبرداری واستول شو!'
    },
    'alerts_triggered_for': {
        'en': '🎯 Alerts triggered for: {intervals}',
        'fa': '🎯 هشدارها برای فعال شده: {intervals}',
        'ps': '🎯 د دغو لپاره خبرداری فعال شو: {intervals}'
    },
    'high_confidence_detected': {
        'en': '🔔 High-confidence predictions detected! Enable alerts in the sidebar to get notified.',
        'fa': '🔔 پیش‌بینی‌های با اطمینان بالا شناسایی شد! برای اطلاع‌رسانی، هشدارها را در نوار کناری فعال کنید.',
        'ps': '🔔 د لوړ اعتماد وړاندوینې وموندل شوې! د خبرداری لپاره په څنګ پټه کې خبرداری فعال کړئ.'
    },
    'predictions_saved': {
        'en': '💾 Saved {count} predictions to database for tracking',
        'fa': '💾 {count} پیش‌بینی برای رهگیری در پایگاه داده ذخیره شد',
        'ps': '💾 د تعقیبولو لپاره {count} وړاندوینې په ډیټابیس کې خوندي شوې'
    },
    'could_not_save_predictions': {
        'en': '⚠️ Could not save predictions to database: {error}',
        'fa': '⚠️ نتوانست پیش‌بینی‌ها را در پایگاه داده ذخیره کند: {error}',
        'ps': '⚠️ په ډیټابیس کې وړاندوینې نشي خوندي کولی: {error}'
    },
    'fetch_data_failed': {
        'en': 'Failed to fetch cryptocurrency data. Please check your internet connection.',
        'fa': 'دریافت داده‌های رمزارز ناموفق بود. لطفاً اتصال اینترنت خود را بررسی کنید.',
        'ps': 'د کریپټو کرنسۍ معلومات نشي راوړلی. مهرباني وکړئ خپل د انټرنیټ اړیکه وګورئ.'
    },
    'last_updated': {
        'en': 'Last updated: {time}',
        'fa': 'آخرین بروزرسانی: {time}',
        'ps': 'وروستی ځل تازه شوي: {time}'
    },
    
    # Portfolio Analytics (if available)
    'portfolio_analytics': {
        'en': '📊 Portfolio & Prediction Analytics Dashboard',
        'fa': '📊 داشبورد تحلیلات پرتفوی و پیش‌بینی',
        'ps': '📊 د پورټفولیو او وړاندوینو تحلیلاتو ډشبورډ'
    },
    'performance_overview': {
        'en': '📈 Performance Overview',
        'fa': '📈 نمای کلی عملکرد',
        'ps': '📈 د فعالیت عمومي کتنه'
    },
    'overall_accuracy': {
        'en': '🎯 Overall Accuracy (30d)',
        'fa': '🎯 دقت کلی (۳۰ روز)',
        'ps': '🎯 ټولیز دقت (۳۰ ورځې)'
    },
    'best_interval': {
        'en': '🔥 Best Interval',
        'fa': '🔥 بهترین بازه',
        'ps': '🔥 غوره موده'
    },
    'accurate': {
        'en': 'accurate',
        'fa': 'دقیق',
        'ps': 'دقیق'
    },
    'predictions': {
        'en': 'predictions',
        'fa': 'پیش‌بینی‌ها',
        'ps': 'وړاندوینې'
    },
    
    # Error Messages
    'error_loading_analytics': {
        'en': '⚠️ Error loading portfolio analytics: {error}',
        'fa': '⚠️ خطا در بارگذاری تحلیلات پرتفوی: {error}',
        'ps': '⚠️ د پورټفولیو تحلیلاتو په لوډولو کې تېروتنه: {error}'
    },
    'troubleshooting': {
        'en': '📝 **Troubleshooting:**',
        'fa': '📝 **عیب‌یابی:**',
        'ps': '📝 **د ستونزو حل:**'
    },
    'database_unavailable': {
        'en': '• Database connection may be unavailable',
        'fa': '• اتصال پایگاه داده ممکن است در دسترس نباشد',
        'ps': '• د ډیټابیس اړیکه کولی شي چې شتون ونلري'
    },
    'refresh_page': {
        'en': '• Try refreshing the page or waiting a moment',
        'fa': '• صفحه را تازه‌سازی کنید یا کمی صبر کنید',
        'ps': '• د پاڼې تازه کول یا یو شیبه انتظار وکړئ'
    },
    'check_database_url': {
        'en': '• Check if DATABASE_URL environment variable is set',
        'fa': '• بررسی کنید که متغیر محیطی DATABASE_URL تنظیم شده باشد',
        'ps': '• وګورئ چې ایا د DATABASE_URL د چاپیریال متغیر ټاکل شوی دی'
    }
}


def get_translation(key, lang='en', **kwargs):
    """
    Get translation for a key in specified language
    
    Args:
        key (str): Translation key
        lang (str): Language code ('en', 'fa', 'ps')
        **kwargs: Format parameters for the translation string
    
    Returns:
        str: Translated string
    """
    if key not in TRANSLATIONS:
        return f"[{key}]"  # Return key in brackets if not found
    
    if lang not in TRANSLATIONS[key]:
        lang = 'en'  # Fallback to English
    
    translation = TRANSLATIONS[key][lang]
    
    # Handle formatting
    if kwargs:
        try:
            translation = translation.format(**kwargs)
        except (KeyError, ValueError):
            pass  # If formatting fails, return unformatted string
    
    return translation


def get_crypto_name(crypto_id, lang='en'):
    """Get cryptocurrency name in specified language"""
    if crypto_id in TRANSLATIONS['crypto_names']:
        return TRANSLATIONS['crypto_names'][crypto_id][lang]
    return crypto_id


def get_direction_text(direction, lang='en'):
    """Get direction text in specified language"""
    direction_lower = direction.lower()
    if direction_lower in TRANSLATIONS['directions']:
        return TRANSLATIONS['directions'][direction_lower][lang]
    return direction


def is_rtl_language(lang):
    """Check if language is right-to-left"""
    return LANGUAGES.get(lang, {}).get('rtl', False)


def get_language_info(lang):
    """Get language information including name and flag"""
    return LANGUAGES.get(lang, LANGUAGES['en'])


def get_supported_languages():
    """Get list of supported language codes"""
    return list(LANGUAGES.keys())


def apply_rtl_style(lang):
    """Apply RTL styling if language requires it"""
    if is_rtl_language(lang):
        return """
        <style>
        .stApp > div {
            direction: rtl;
            text-align: right;
        }
        .stSelectbox > div > div {
            text-align: right;
        }
        .stTextInput > div > div > input {
            text-align: right;
        }
        .metric-container {
            text-align: center;
        }
        .stMarkdown {
            text-align: right;
        }
        .stMarkdown h1, .stMarkdown h2, .stMarkdown h3, .stMarkdown h4 {
            text-align: right;
        }
        </style>
        """
    else:
        return """
        <style>
        .stApp > div {
            direction: ltr;
            text-align: left;
        }
        </style>
        """